#!/usr/bin/env bash
# VERIFY.sh — one-shot empirical reproduction for the wave-2 bundle.
#
#     bash proofs/VERIFY.sh
#
# Paths are resolved relative to this file, so it can be run from anywhere.
# Requires: bash + python3 with numpy and scipy. Runtime ~1-2 min single core.
# Exit code 0 iff all four checks pass.

set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
cd "$ROOT"

PY=""
for cand in python3 python3.12 python3.11 /usr/bin/python3.12 /usr/bin/python3; do
  if command -v "$cand" >/dev/null 2>&1 && "$cand" -c "import numpy, scipy" >/dev/null 2>&1; then
    PY="$cand"; break
  fi
done
if [ -z "$PY" ]; then
  echo "FATAL: no python3 with numpy+scipy found. Try: pip install numpy scipy" >&2
  exit 2
fi

FAIL=0
note() { printf '\n=== %s\n' "$1"; }
ok()   { printf '  [PASS] %s\n' "$1"; }
bad()  { printf '  [FAIL] %s\n' "$1"; FAIL=$((FAIL+1)); }

printf 'VERIFY.sh  bundle root: %s\n' "$ROOT"
printf 'interpreter: %s  (%s)\n' "$PY" \
  "$("$PY" -c 'import sys,numpy,scipy;print("python "+sys.version.split()[0]+", numpy "+numpy.__version__+", scipy "+scipy.__version__)')"

# ------------------------------------------------------------ CHECK 1
note "CHECK 1 — curved-corpus-create selftest"
if ( cd "$ROOT/skills/curved-corpus-create" && "$PY" scripts/create_corpus.py --selftest ) \
     > "$ROOT/proofs/selftest.out" 2>&1; then
  tail -n 2 "$ROOT/proofs/selftest.out" | sed 's/^/    /'
  ok "skill selftest GREEN  (full log: proofs/selftest.out)"
else
  tail -n 25 "$ROOT/proofs/selftest.out" | sed 's/^/    /'
  bad "skill selftest did not exit 0  (log: proofs/selftest.out)"
fi

# ------------------------------------------------------------ CHECK 2 + 3
note "CHECK 2 — V2 of the real 2286x9 matrix   |   CHECK 3 — 20-rep curveball null"
"$PY" - "$ROOT" <<'PYEOF'
import sys, os, json
root = sys.argv[1]
sys.path.insert(0, os.path.join(root, "scripts"))
import numpy as np
import common

X, prim, raw = common.load_real_matrix(
    os.path.join(root, "data", "real", "per_row_coverage_v3.json"))
print("    matrix %d x %d  <- data/real/per_row_coverage_v3.json" % X.shape)

V2 = common.v2(X)
print("    V2(real)      = %.6f   target 0.723529   |diff| = %.2e  (tol 1e-4)"
      % (V2, abs(V2 - 0.723529)))
c2 = abs(V2 - 0.723529) < 1e-4

reps, mult = 20, 10
vals = np.array([common.v2(common.curveball_fast(X, seed=1000 + r,
                                                 n_trades=mult * X.shape[0]))
                 for r in range(reps)])
m, s = float(vals.mean()), float(vals.std(ddof=1))
print("    curveball null (%d reps, %dN trades): mean = %.6f  sd = %.6f  min %.6f  max %.6f"
      % (reps, mult, m, s, vals.min(), vals.max()))
print("    dV2 = %+.6f   z = %+.2f   band [0.700, 0.718] -> %s"
      % (V2 - m, (V2 - m) / s, "inside" if 0.700 <= m <= 0.718 else "OUTSIDE"))
c3 = 0.700 <= m <= 0.718

json.dump({"V2_real": V2, "curveball_reps": reps, "curveball_trades_mult": mult,
           "curveball_mean": m, "curveball_sd": s, "dV2": V2 - m,
           "z": (V2 - m) / s, "check2_pass": bool(c2), "check3_pass": bool(c3)},
          open(os.path.join(root, "proofs", "verify-recompute.json"), "w"), indent=2)
sys.exit(0 if (c2 and c3) else 1)
PYEOF
if [ $? -eq 0 ]; then
  ok "V2 = 0.723529 reproduced (tol 1e-4) AND curveball mean inside [0.700, 0.718]"
  ok "artifact written: proofs/verify-recompute.json"
else
  bad "V2 recomputation and/or curveball null band assertion failed"
fi

# ------------------------------------------------------------ CHECK 4
note "CHECK 4 — Hodge decomposition: import + control"
"$PY" - "$ROOT" <<'PYEOF'
import sys, os
root = sys.argv[1]
sys.path.insert(0, os.path.join(root, "scripts"))
import numpy as np
import hodge_decompose as hd

names = ("hexagon_control", "control_hexagon", "_hexagon", "selftest")
found = [n for n in names if hasattr(hd, n)]
print("    imported scripts/hodge_decompose.py ; built-in hexagon control: %s"
      % (found[0] if found else "not exposed"))

if found:
    res = getattr(hd, found[0])()
    print("    hexagon control ->", res)
    okc = (isinstance(res, dict) and res.get("beta1") == 1)
    print("    beta1 == 1 -> %s" % okc)
else:
    print("    fallback: tiny 20-node smoke decomposition (knn k=4, seed 20260812)")
    rng = np.random.default_rng(20260812)
    M = (rng.random((20, 9)) < 0.5).astype(np.int8)
    res, arrays, edges, tris = hd.run_full(M, graph="knn", k=4, seed=20260812)
    o = res["orthogonality"]
    worst = max(abs(o["grad_curl"]), abs(o["grad_harm"]),
                abs(o["curl_harm"]), abs(o["sum_rho_minus_1"]))
    print("    nodes = 20  edges = %d  triangles = %d" % (len(edges), len(tris)))
    print("    fractions: rho_grad = %.6f  rho_curl = %.6f  rho_harm = %.6f  (sum = %.12f)"
          % (res["rho_grad"], res["rho_curl"], res["rho_harm"],
             res["rho_grad"] + res["rho_curl"] + res["rho_harm"]))
    print("    betti: beta0 = %s  beta1 = %s  beta2 = %s"
          % (res["betti"]["beta0"], res["betti"]["beta1"], res["betti"]["beta2"]))
    print("    orthogonality: grad.curl = %.3e  grad.harm = %.3e  curl.harm = %.3e  sum-1 = %.3e"
          % (o["grad_curl"], o["grad_harm"], o["curl_harm"], o["sum_rho_minus_1"]))
    print("    worst |residual| = %.3e   tolerance 1e-8" % worst)
    okc = worst < 1e-8

sys.exit(0 if okc else 1)
PYEOF
if [ $? -eq 0 ]; then
  ok "Hodge module imports and its control passes (orthogonality < 1e-8)"
else
  bad "Hodge control failed"
fi

# ------------------------------------------------------------ tally
note "RESULT"
if [ "$FAIL" -eq 0 ]; then
  echo "  ALL CHECKS PASSED"
  exit 0
fi
echo "  $FAIL CHECK(S) FAILED"
exit 1
