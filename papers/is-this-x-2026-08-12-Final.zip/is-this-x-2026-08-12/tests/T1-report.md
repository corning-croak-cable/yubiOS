# T1 — Two untested items closed empirically

Script: `tests/t1_winding_ordering.py` (python3.12, argparse, all seeds logged)
Raw output: `tests/T1-results.json`
Run: 2026-08-12, numpy 2.5.1 / scipy 1.18.0, elapsed 126 s.
Seeds: master seed `20260812`; real kNN graph seed `20260812` (matches `B-hodge-yubios.json`);
T1 nulls = 50 curveball draws (graph seed re-drawn per draw from the master RNG);
T2 = 500 index permutations per statistic block (seeds 20260812 / +1 / +2 / +3).

Inputs (unmodified, as shipped):
`data/real/per_row_coverage_v3.json` (2286×9), `data/real/real-gwtc-matrix.csv` (269×9),
`skills/curved-corpus-create/scripts/create_corpus.py`, `scripts/hodge_decompose.py`.

---

## ITEM 1 — P-H3 clause (ii): quantized azimuthal S² winding

### Construction actually executed
z-score(2286×9) → PCA top-2 → RMS-1 rescale → `stereographic_lift` → per-row (θᵢ, φᵢ).
PC1+PC2 variance share of the z-scored matrix = **0.7235**.
θ range [1.2096, 2.9808]; φ range [0.0340, 6.2831] (full azimuthal cover).
Graph: kNN k=8 on Jaccard, seed 20260812 → **N=2286, |E|=16438, |T|=13799** — identical to
`B-hodge-yubios.json`. Hodge (Construction A1): ρ_grad=0.99961, ρ_curl=1.306e-4,
**ρ_harm=2.5575e-4**; orthogonality residuals ≤1e-11; β₀=6, **β₁=6756**, β₂=6397, Euler identity OK.
Cycle basis: BFS spanning forest + chords → **14158 fundamental cycles** (chord count; note this
exceeds β₁=6756 because β₁ is computed against the clique complex, i.e. 7402 of the independent
graph cycles are filled by triangles).

### (b)/(c) Measured — all 14158 cycles

| quantity | value |
|---|---|
| mean cycle length (edges) | 26.28 |
| winding W = Σ wrap(Δφ): mean / sd | 0.1012 / 2.3237 |
| mean \|W\| | 0.8574 |
| winding-number histogram (round W/2π) | −2:1, −1:850, **0:12230**, 1:1074, 2:3 |
| max deviation of W from an exact multiple of 2π | **4.44e-16** |
| harmonic circulation C = ∮h: mean / sd | −1.296e-3 / 3.560e-2 |
| mean \|C\| / max \|C\| | 1.3153e-2 / 1.0095e-1 |
| \|C\| quantiles (50/90/99/100 %) | 4.07e-25, 0.100954, 0.100954, 0.100954 |
| circulation-number histogram (round C/2π) | **0 : 14158 (all of them)** |
| mean distance of C/2π to nearest integer | 2.0933e-3 |
| Rayleigh on frac(C/2π) | R̄=0.99937, Z=14140.1, p≈0 (mean angle 6.2819 rad ≈ 0) |
| KS vs uniform on frac(C/2π) | D=0.7154, p≈0 |
| Pearson r(\|C\|,\|W\|) | **+0.9509** (n=14158, p≈0) |
| Spearman ρ(\|C\|,\|W\|) | +0.3107 (p≈0) |
| Pearson r(C,W) signed | **−0.9570** |

Top-20 harmonic-energy cycles (largest \|∮h\|): every one has \|C\| = 0.10095401687936895 exactly
and winding number ±1 (11× −1, 9× +1); C and W are exactly anti-proportional there (r=−1.0000).
Cycles touching the top-1 % harmonic-energy edges (165 edges, 2354 cycles): mean \|C\|=0.0791,
r(\|C\|,\|W\|)=+0.8576.

### (d) Null — 50 curveball matrices, embedding+graph+Hodge recomputed each

| statistic | real | null mean ± sd | z | p (2-sided, empirical) |
|---|---|---|---|---|
| Rayleigh Z of frac(C/2π) | 14140.08 | 13945.59 ± 53.00 | +3.67 | 0.0196 |
| mean dist of C/2π to integer | 2.0933e-3 | 2.287e-4 ± 1.246e-4 | **+14.97** | 0.0196 |
| r(\|C\|,\|W\|) | 0.9509 | 0.5525 ± 0.1863 | +2.14 | 0.0392 |
| mean \|C\| | 1.3153e-2 | 1.437e-3 ± 7.83e-4 | **+14.97** | 0.0196 |
| mean \|W\| | 0.8574 | 0.1838 ± 0.1153 | +5.84 | 0.0196 |
| ρ_harm | 2.5575e-4 | 1.884e-4 ± 4.66e-5 | +1.45 | 0.1569 |
| n cycles | 14158 | 13946.5 ± 52.9 | +4.00 | 0.0196 |

(p floor is 1/51 = 0.0196 at 50 draws.)

### Verdict — ITEM 1: **NOT quantized. Clause (ii) fails.**

Three things must be separated, and two of them are traps:

1. **Azimuthal winding is exactly 2π-quantized — but this is a tautology, not evidence.** The
   max deviation of Σ wrap(Δφ) from an integer multiple of 2π is 4.4e-16 (machine epsilon).
   Summing wrapped increments around any closed loop of any angle-valued field is *always*
   2π×integer. This number tests nothing about the corpus. It is reported so the trap is visible.
   What is non-trivial is that the winding numbers are mostly zero (12230/14158 = 86.4 % have
   W=0) and never exceed ±2 — the embedding's cycles almost all fail to enclose the pole.
2. **Harmonic circulation is not quantized in units of 2π.** Every one of the 14158 cycles has
   round(∮h/2π) = 0. The largest circulation in the whole complex is \|∮h\| = 0.1010 = **1.6 % of
   2π**. There is no ladder of integer multiples; there is a single blob near zero. Concentration
   near zero mod 2π (Rayleigh Z=14140) is a magnitude artifact — everything is ≪2π, so everything
   sits near the 0 residue. The honest reading of the null is the opposite of quantization: the
   real corpus's mean distance to the nearest 2π multiple is **15σ larger** than the curveball
   null's, because real harmonic circulations are ~9× bigger than null ones (1.32e-2 vs 1.44e-3),
   i.e. real data is *further* from the quantized lattice than the shuffle is.
3. **Circulation and winding are correlated, but not in the way clause (ii) predicts.** r(\|C\|,\|W\|)
   = +0.95 vs null 0.55 ± 0.19 (z=+2.14, p=0.039) — weakly significant only. And the correlation
   is an artifact of degeneracy: \|C\| takes exactly **two** values across the whole complex
   (0 for the median cycle, 0.100954 for the tail — the 90th, 99th and 100th percentiles are the
   same number to 15 digits), and \|W\| takes essentially two values (0 or 2π). Two near-binary
   variables that co-occur give r≈0.95 mechanically; the rank correlation, which is not fooled by
   this, is only ρ=0.31. Signed r(C,W) = −0.957: where circulation is non-zero it runs *against*
   the winding, which is not a "1-cocycle ↔ +2π phase advance" correspondence.

The harmonic subspace here is one-dimensional in magnitude (a single ±0.100954 mode threaded
through 1928 cycles out of 14158) and carries 0.026 % of the flow energy — consistent with
ρ_harm being statistically indistinguishable from curveball (z=+1.45, p=0.157). Clause (ii) of
P-H3 is **falsified on the same corpus and construction as clause (i)**: harmonic 1-cocycles do
not correspond to ~2π-quantized azimuthal phase windings.

---

## ITEM 2 — Ordering-permutation null (Remark 1) on the real corpora

Regime: row i placed at Fibonacci lattice point rank[i] where rank = PC1 rank of the z-scored
matrix (identical to `sphere_fit`). Null = 500 shuffles of *which row gets which lattice point*
(the matrix and the lattice are untouched; only the index map is randomized).

Statistics per assignment:
- **Y₃³ probe** = Σ wᵢ K sin³θᵢ cos(3φᵢ) / Σ\|wᵢ\|, K = √(70/64π) (the corrected constant).
- **Y₃³ Parseval energy share** = ‖C₁₅‖² / Σⱼ‖Cⱼ‖² from the L=3, λ=1e-3 ridge fit of the 9
  z-scored columns on the lattice SH basis. (m=3 both-signs share = (‖C₉‖²+‖C₁₅‖²)/Σ also given.)
- **P₃** = \|Σ wᵢ e^{3iφᵢ}\|² / Σ wᵢ². Weight choice is stated per block: `coverage_sum` (row
  mass 0..9) and signed PC1 score for the master matrix; `network_matched_filter_snr` and signed
  PC1 score for GWTC. Uniform weights are excluded on purpose — with the lattice fixed they make
  P₃ permutation-invariant and the null degenerate.

### Master corpus, 2286×9 (PC1 var 0.643, PC1+PC2 0.724)

| statistic | weight | real | null mean ± sd | z | p (empirical, 2-sided) |
|---|---|---|---|---|---|
| Y₃³ probe | coverage_sum | −3.758e-5 | −2.197e-4 ± 3.73e-3 | +0.05 | 0.960 |
| Y₃³ Parseval share | — | 9.588e-5 | 0.06510 ± 0.0519 | −1.25 | 0.120 |
| m=3 share (both signs) | — | 2.006e-4 | 0.12993 ± 0.0746 | −1.74 | 0.068 |
| P₃ | coverage_sum | 1.046e-3 | 0.27761 ± 0.287 | −0.96 | 0.142 |
| Y₃³ probe | PC1 score | 2.207e-5 | 5.809e-5 ± 6.05e-3 | −0.01 | 0.990 |
| P₃ | PC1 score | 1.573e-4 | 1.00024 ± 1.02 | −0.98 | 0.148 |

### GWTC, 269×9, `luminosity_distance` log-transformed then all 9 z-scored (PC1 var 0.664, PC1+PC2 0.835)

| statistic | weight | real | null mean ± sd | z | p (empirical, 2-sided) |
|---|---|---|---|---|---|
| Y₃³ probe | SNR | −1.350e-3 | 3.654e-4 ± 9.14e-3 | −0.19 | 0.850 |
| Y₃³ Parseval share | — | 7.897e-4 | 0.06845 ± 0.0634 | −1.07 | 0.128 |
| m=3 share (both signs) | — | 8.927e-3 | 0.13318 ± 0.0798 | −1.56 | 0.088 |
| P₃ | SNR | **0.65389** | 0.20310 ± 0.192 | **+2.35** | **0.038** |
| Y₃³ probe | PC1 score | 1.013e-4 | 1.263e-3 ± 2.11e-2 | −0.06 | 0.946 |
| P₃ | PC1 score | 0.06454 | 1.04327 ± 1.02 | −0.96 | 0.204 |

### Verdict — ITEM 2: **azimuthal claims are NOT supported.**

- The Y₃³ probe is dead on both corpora under both weightings: \|z\| ≤ 0.19, p ≥ 0.85. The real
  value sits within a twentieth of a null sd of the shuffled mean. Whatever the regime reads off
  Y₃³ is a property of the index map, exactly as Remark 1 warns.
- The Y₃³ Parseval energy share and the m=3 share are *below* their nulls on both corpora
  (z ≈ −1.1 to −1.7, p ≥ 0.068 two-sided; p = 1.000 for the one-sided-in-magnitude test). Real
  PC1 ordering makes the fit **smoother in azimuth**, not more 3-fold: sorting by PC1 puts nearby
  rows at nearby lattice indices, which loads the low-m harmonics and starves m=3. A shuffled
  order scatters power into high-m, so the null is the one with the "3-fold structure". The
  direction of the effect is the opposite of the claim.
- The single nominally significant result in the whole of Item 2 is GWTC P₃ under SNR weighting,
  z=+2.35, p=0.038 — one hit out of 10 tests reported here, not surviving any multiplicity
  correction (Bonferroni across the 10 → p_adj = 0.38), and it flips to z=−0.96 the moment the
  weight is changed to PC1 score on the same data. It is a weight-choice artifact, not a signal.

---

## Files

- `session/subagent/tests/t1_winding_ordering.py` — standalone script (argparse; `--t1-nulls`,
  `--t2-perms`, `--k`, `--graph-seed`, `--seed`, `--skip-item1/2`)
- `session/subagent/tests/T1-results.json` — every number above, plus the full run log
- `session/subagent/tests/T1-report.md` — this file
