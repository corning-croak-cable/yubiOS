# T3 — DYNAMICS: detailed-balance test on the yubiOS atom edit log

Harness: `tests/t3_dynamics.py` (python3.12, stdlib only, argparse).
Run: `python3.12 t3_dynamics.py --data-dir <papers/data> --out-dir tests/`
Artifacts: `tests/T3-results.json`, `tests/dynamics-series.json`, this report.

Data (rsi-85 excluded as a known relabel of the 79):

| corpus | files | cycles | dispatches |
|---|---:|---:|---:|
| skills79 | 79 | 6 | 474 |
| docs21 | 21 | 6 | 126 |
| refs113 | 113 | 7 | 791 |
| **pooled** | **213** | — | **1391** |

Plus `single-action-curve-rsi-cycles-2026-08-05.json` (20 cycles) as an auxiliary Δ-series.

State variable: `k = 9 − len(missing_primitives)` ∈ {0..9} per file per cycle
(`k_pre`, i.e. the state the dispatch was measured at). 1,178 file-level
cycle→cycle transitions.

---

## 1. State-space reconstruction — the stated expectation is FALSE

Pooled transition census (1,178 transitions):

| class | count | share |
|---|---:|---:|
| stay (k→k), of which 580 are the absorbing k=9 | 580 | 49.2% |
| single step (k→k+1) | 423 | 35.9% |
| **multi-step (k→k+m, m≥2)** | **175** | **14.9%** |
| **regression (k→k′<k)** | **0** | **0.0%** |

Jump-size histogram by starting k (pooled, `m: count`):

```
k=0: {4:14}            k=5: {1:46, 2:35, 3:2}
k=1: {3:8, 4:19}       k=6: {1:49, 2:38}
k=2: {1:2, 2:2, 3:13, 4:10}   k=7: {1:104, 2:8}
k=3: {1:7, 2:3, 3:6, 4:1}     k=8: {1:180}
k=4: {1:35, 2:14, 3:2}        k=9: {0:580}  (absorbed)
```

**The brief's expectation `k′ ∈ {k, k+1}` does not hold.** Every transition out
of k=0 is +4 (14/14); every transition out of k=1 is +3 or +4 (27/27). Multi-step
share by corpus: skills79 4.1%, docs21 11.4%, refs113 21.7%.

This is not noise, it is a category error in how the log has been read elsewhere.
The 1,391 "atom dispatches" record **one counterfactual best flip per file per
cycle** (`winner_primitive`, and Δ = the ladder value at `k_pre`). The **applied**
edit between cycles adds up to four primitives at once. Dispatch count ≠ state
update. Any claim of the form "the atom policy flips one missing primitive per
cycle" is contradicted by the log's own k-trajectories.

---

## 2. Detailed-balance test — VIOLATED, maximally

Backward counts on the birth–death restriction:

| k | T(k→k+1) | T(k+1→k) | J(k) |
|---:|---:|---:|---:|
| 0 | 0 | 0 | 0 |
| 1 | 0 | 0 | 0 |
| 2 | 2 | 0 | +2 |
| 3 | 7 | 0 | +7 |
| 4 | 35 | 0 | +35 |
| 5 | 46 | 0 | +46 |
| 6 | 49 | 0 | +49 |
| 7 | 104 | 0 | +104 |
| 8 | 180 | 0 | +180 |

`T(k+1→k) = 0` for **every** k, in **every** corpus, over all 1,178 transitions.
Counting the multi-step edges too, total upward mass = 598, total downward mass = 0.
The empirical current equals the full forward flux at every level: **J(k) = T(k→k+1)**.

Entropy-production proxy `Σ J(k)·log[T(k→k+1)/max(T(k+1→k), ε)]`, ε-sensitivity:

| ε | 1.0 | 0.5 | 0.1 | 0.01 | 1e-6 |
|---|---:|---:|---:|---:|---:|
| Σ | 1924.01 | 2217.21 | 2898.00 | 3872.00 | 7767.97 |

The proxy grows as `−423·log ε` (slope ≈ 423 per e-fold, exactly the single-step
count). It **diverges** as ε→0: the true entropy production is **+∞**, not a large
finite number. Reporting any single ε-value as "the" entropy production would be
an artifact of the regulariser.

Kolmogorov cycle criterion: with all backward edges at weight 0, the transition
graph minus self-loops is a **DAG** on {0..9}. No non-trivial directed cycle
exists, so the criterion is **vacuously satisfied** — and therefore uninformative
here. The correct statement is the stronger one: reversibility requires
`π(k)T(k,k+1) = π(k+1)T(k+1,k)`; the left side is positive for k=2..8 and the
right side is identically zero, so the ratio diverges and **no positive π makes
this chain reversible**. The unique stationary distribution is `δ_{k=9}` (580
absorbed self-loops confirm the absorbing state is reached and never left).

**Verdict: detailed balance is violated at every level with non-zero flux
(k = 2..8), with zero counterexamples in 1,178 transitions. No equilibrium
free-energy description applies.**

### 2b. But there IS a potential — the paper's dichotomy is malformed

A separate, independent finding that the brief's framing ("separate potential
from non-potential dynamics") conflates two different things. Define
`Φ(k) := d_pre(k)`, which the data confirms is a function of k alone:

```
Φ = [2.0000, 1.9758, 1.9080, 1.8091, 1.6933, 1.5727, 1.4552, 1.3454, 1.2451, (0.0 sentinel)]
δ = [0.0242, 0.0678, 0.0989, 0.1158, 0.1206, 0.1175, 0.1098, 0.1003, 0.0904]
```

Test `d_post(k) − Φ(k+1)`: **exactly 0.0 for all k = 0..7** (max abs residual
0.00000000, all three corpora). So `δ(k) = Φ(k) − Φ(k+1)` — the Δ-ladder is
*exactly* the discrete gradient of a potential, and per-file cumulative Δ is
path-independent and telescoping. The only break is bookkeeping: at k=8 the
post-state distance is 1.1547 but `Φ(9)` is recorded as the sentinel `0.0`.

So the system is **simultaneously** a pure potential (gradient) flow and
**maximally irreversible**. "Potential dynamics" in the gradient-descent sense is
not the same as "reversible / equilibrium / detailed-balance" dynamics, and a
detailed-balance test cannot distinguish them — it can only reject equilibrium.
This one *is* a potential flow: deterministic descent of Φ with no back-flux.
The paper's proposed test is the right test for the wrong dichotomy.

---

## 3. Absorbing-chain model fit

Model family: from state k, each of the `9−k` missing primitives flips
independently with probability `p(k)` per cycle (so jumps are Binomial(9−k, p(k)),
which correctly admits the observed multi-step jumps). Fitted by MLE on the jump
histogram; trajectories obtained by propagating the cycle-1 k-histogram forward
and scoring the *observed* per-cycle positives and Δ (Δ is a deterministic
function of the k-histogram, since Δ = Σ_files δ(k_pre)).

| model | params | pooled logL | pooled AIC |
|---|---:|---:|---:|
| **A — per-k p(k)** | 9 | **−430.07** | **878.15** |
| G — global p (p̂ = 0.4732) | 1 | −600.05 | 1202.10 |
| B — two-param `p0·(1−k/9)^s` | 2 | −600.05 | 1204.10 |

Model B's MLE is `p0 = 0.473, s = 0.000` — the saturation exponent collapses to
zero, so B **degenerates exactly onto G** and is penalised 2 AIC for the wasted
parameter. Likelihood-ratio A vs G: `2Δ logL = 339.96` on 8 df (χ²₈ 0.1% crit.
= 26.1) → **p ≪ 1e-60**. The flip rate is decisively k-dependent; a global-p +
saturation account is rejected.

Per-corpus trajectory reproduction (χ² of observed vs predicted):

| corpus | model | χ²(positives) | χ²(Δ) | predicted positives |
|---|---|---:|---:|---|
| skills79 | A per-k | **4.24** | **0.374** | 59, 24.5, 13.3, 8.6, 5.1, 2.7 |
| | G global p | 9.59 | 0.697 | 59, 37.7, 22.1, 11.8, 5.9, 2.8 |
| | S single-flip det. | 9.96 | 1.205 | 59, 30, 12, 11, 10, 8 |
| | *observed* | — | — | *59, 30, 12, 9, 6, 0* |
| docs21 | A per-k | **2.33** | **0.208** | 20, 14.8, 9.8, 5.4, 2.5, 1.1 |
| | G global p | 3.89 | 0.361 | 20, 16.4, 11.5, 7.1, 4.0, 2.1 |
| | *observed* | — | — | *20, 16, 13, 5, 2, 0* |
| refs113 | A per-k | **18.55** | **1.640** | 109, 103.8, 89.4, 59.9, 30.8, 12.8, 4.6 |
| | G global p | 43.30 | 4.113 | 109, 105.3, 92.2, 69.2, 45.6, 27.6, 15.9 |
| | S single-flip det. | 161.78 | 18.28 | 109, 106, 102, 97, 87, 71, 58 |
| | *observed* | — | — | *109, 106, 98, 78, 32, 3, 0* |

Reading:

- **The Δ-per-cycle decay is reproduced well** (χ²(Δ) = 0.37 / 0.21 / 1.64 across
  6–7 cycles). Once the k-histogram flow is right, the Δ curve follows for free —
  Δ is not independent information.
- **The positives sequence is reproduced only roughly**, and **no model in this
  family reproduces the hard fixpoint.** Every stochastic model predicts a
  geometric tail (2.7 / 1.1 / 4.6 files still open at the last cycle) where the
  data shows exactly **0**. The observed terminations (0 at cycle 6/6/7) are
  sharper than any independent-flip process; the last stragglers are cleaned up
  deterministically rather than sampled.
- The literal "one flip per cycle" model (S) is the worst of all on refs113
  (χ² = 161.8) — it cannot generate the fast early descent.

**Fit quality verdict: the absorbing-drift skeleton is right (monotone,
absorbing at k=9, Δ slaved to the k-histogram), but the minimal
independent-flip parameterisation is not sufficient — p(k) is strongly
k-dependent and the terminal cycle is sharper than any such model allows.**

`p̂(k)` pooled: `0.444, 0.463, 0.450, 0.343, 0.271, 0.367, 0.479, 0.536, 1.000`
(k = 0..8) — U-shaped, minimum at **k=4**, which is exactly where the Δ-ladder is
**maximal** (δ = 0.1206). Confound check: p̂ also rises with cycle index
(0.446, 0.364, 0.557, 0.691, 0.930, 1.000), so k and cycle are entangled.
Restricting to cycle 1 alone (where all k are populated) the U-shape survives but
shallower: `0.444, 0.463, 0.450, 0.344, 0.320, 0.404, 0.364, 0.500, 1.000`.
So there is a real k-dependence, and it runs *against* payoff: the state where a
flip is worth most is the state where flips are least likely.

---

## 4. Verdict on the proposed restatement

**Is "emergence over cycles" = "append-only policy saturating a bounded coverage
space"? — Yes, substantially; with two corrections to the wording.**

Evidence for:
- 0 regressions in 1,178 transitions across three corpora → strictly append-only.
- Absorbing at k=9 in every corpus (580 absorbed self-loops); mean k rises
  monotonically in every corpus and every cycle (skills 7.22→9.00,
  docs 5.48→9.00, refs 3.01→9.00).
- The space is bounded (9 primitives) and every corpus saturates it completely.
- Δ carries no independent information: `Δ = Σ_f δ(k_f)` with δ a fixed
  9-entry lookup, and δ is the exact gradient of Φ(k). Cumulative Δ is a
  telescoping sum of a bounded potential — it *must* decay to 0 and stop.

Corrections required:
1. **"append-only" ≠ "one-primitive-at-a-time".** 14.9% of transitions add 2–4
   primitives at once; at k≤1 *every* transition adds 3–4. The saturation is
   append-only but coarse-grained and front-loaded.
2. **"potential vs non-potential" is the wrong axis** (§2b). The detailed-balance
   test rejects *equilibrium*, but the dynamics *is* a potential flow — an exact
   discrete gradient descent on Φ(k) = d_pre(k). The correct restatement is
   "deterministic gradient descent on a 1-D potential of coverage count,
   absorbing at full coverage", which is strictly stronger than the paper's
   proposed wording and is directly verified here (residual 0.0).

**Evidence of non-trivial dynamics (oscillation, regression, non-monotone k):
NONE in the three multi-cycle corpora.** Zero regressions, zero non-monotone
per-file k-paths, zero oscillations, a single absorbing state.

One caveat, from the auxiliary 20-cycle file: its Δ-series is **non-monotone**
(7 increases out of 19 steps: 0.0862, 0.3092, 0.0718, …) and, twice, a Δ = 0
cycle is followed by a **positive** cycle (cycle 7 → 0.281, cycle 12 → 0.2705).
Zero-Δ is *not* absorbing there. But `d_pre` is renormalised to 1.0 every cycle
in that file and k is not recoverable, and the run mixes 12 sweep cycles with 8
post-edit re-fits — so this is a re-fit artifact (the curve is refit, re-opening
headroom), not evidence of state regression. It is the only place in the dataset
where anything reopens, and it should not be cited as "emergence" without the
per-file coverage vectors, which this file does not carry.

### The refs cycle-2 Δ peak (+11.9840): STATE-driven, not policy-driven

Exact decomposition of the cycle-1 → cycle-2 change (Δ = positives ×
mean-Δ-per-positive):

| term | value |
|---|---:|
| policy term (Δpositives × prev mean-Δ): 109→106 dispatches | **−0.274** |
| state term (prev positives × Δ mean-Δ): 0.09134→0.11306 | **+2.368** |
| net | +2.029 (9.956 → 11.984) |

**Fewer** flips were dispatched at cycle 2, not more. The rise is 100%+
state-driven: refs starts at mean k = 3.01, far below the ladder maximum, and
cycle 1 pushes the population to mean k = 5.57 — straight into the k=4–5 peak of
the Δ-ladder (0.1206 / 0.1175). The corpus climbs *onto* the hump. skills79
(mean k = 7.22 at cycle 1) starts past the hump and therefore never shows a rise.
Corollary 1's "per-cycle increment unconstrained" licence is not needed as an
excuse; the rise is a fully determined consequence of the initial k-histogram
and the fixed ladder, and is predictable in advance.

---

## 5. Artifact

`tests/dynamics-series.json` — per corpus per cycle: `{cycle, n_files, mean_k,
k_hist, positives, delta_sum, transitions:{forward,backward,stay}, J,
entropy_production_proxy_eps1}`.

## Reproduction notes

- `python3.12` explicitly; no numpy/scipy dependency (stdlib `math` only).
- rsi-85 excluded by construction (not in `CORPORA`).
- Per-cycle Δ sums recomputed from records reproduce the published
  `cumulative_delta_per_cycle` to ≤6e-4 (rounding in the published table):
  skills 5.5792/3.0093/1.2833/0.8829/0.5424/0 vs published
  5.5787/3.0091/1.2833/0.8829/0.5423/0.
