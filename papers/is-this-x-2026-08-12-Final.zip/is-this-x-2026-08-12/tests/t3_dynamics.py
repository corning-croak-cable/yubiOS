#!/usr/bin/env python3.12
"""
T3 DYNAMICS — detailed-balance / absorbing-chain test on the yubiOS atom edit log.

State: k = coverage count in {0..9} per file per cycle (k = 9 - len(missing_primitives)).
Tests:
  1. State-space reconstruction: empirical T(k -> k') across consecutive cycles.
  2. Detailed-balance test: backward counts, current J(k), entropy-production proxy
     (with epsilon sensitivity), Kolmogorov cycle criterion on the k-chain.
  3. Absorbing-chain model fit: per-k flip probability p(k) vs a 2-parameter
     (global p, saturation exponent) alternative; reproduce positives, per-cycle
     delta, fixpoint. chi-square + log-likelihood + AIC.
  4. Verdict inputs: monotonicity / regression / oscillation scan; refs cycle-2
     delta-peak decomposition (policy-driven vs state-driven).
  5. Time-series artifact: dynamics-series.json.

Usage:
  python3.12 t3_dynamics.py --data-dir <papers/data> --out-dir <tests/>
"""

import argparse
import json
import math
import os
from collections import Counter, defaultdict

K_MAX = 9

CORPORA = {
    "skills79": "rsi-79-corpus-multi-cycle-2026-08-06.json",
    "docs21": "rsi-docs-21-corpus-2026-08-06.json",
    "refs113": "rsi-refs-113-corpus-2026-08-06.json",
}
AUX_20CYCLE = "single-action-curve-rsi-cycles-2026-08-05.json"


# ---------------------------------------------------------------- loading

def load_corpus(path):
    with open(path) as fh:
        d = json.load(fh)
    recs = d["all_cycles"]
    idkey = "slug" if "slug" in recs[0] else "file"
    out = []
    for r in recs:
        miss = r["missing_primitives"]
        out.append({
            "file": r[idkey],
            "cycle": int(r["cycle"]),
            "k_pre": K_MAX - len(miss),
            "n_missing": len(miss),
            "d_pre": float(r["d_pre"]),
            "d_post": float(r["d_post"]),
            "delta": float(r["delta_d"]),
            "winner": r["winner_primitive"],
        })
    meta = {
        "corpus_size": d.get("corpus_size"),
        "cycles_total": d.get("cycles_total"),
        "cumulative_delta_per_cycle": d.get("cumulative_delta_per_cycle"),
        "primitive_coverage_per_cycle": d.get("primitive_coverage_per_cycle"),
        "primitives": d.get("primitives"),
        "fixpoint_reached": d.get("fixpoint_reached"),
    }
    return out, meta


# ------------------------------------------------- 1. state reconstruction

def transitions(recs):
    """T[(k,k')] over consecutive cycles, per file, using k_pre of each cycle."""
    by_file = defaultdict(dict)
    for r in recs:
        by_file[r["file"]][r["cycle"]] = r
    T = Counter()
    intra = Counter()          # k_pre -> k_post within a dispatch
    anomalies = []
    for f, cyc in by_file.items():
        cs = sorted(cyc)
        for a, b in zip(cs, cs[1:]):
            ka, kb = cyc[a]["k_pre"], cyc[b]["k_pre"]
            T[(ka, kb)] += 1
            if kb < ka:
                anomalies.append({"file": f, "cycle_from": a, "cycle_to": b,
                                  "k_from": ka, "k_to": kb, "type": "regression"})
            elif kb > ka + 1:
                anomalies.append({"file": f, "cycle_from": a, "cycle_to": b,
                                  "k_from": ka, "k_to": kb, "type": "multi_step_jump"})
        for c in cs:
            r = cyc[c]
            kpost = r["k_pre"] + (1 if r["winner"] is not None else 0)
            intra[(r["k_pre"], kpost)] += 1
    return T, intra, anomalies, by_file


# ------------------------------------------------- 2. detailed balance

def detailed_balance(T, eps_list=(1.0, 0.5, 0.1, 0.01, 1e-6)):
    fwd = {k: T.get((k, k + 1), 0) for k in range(K_MAX)}
    bwd = {k: T.get((k + 1, k), 0) for k in range(K_MAX)}
    stay = {k: T.get((k, k), 0) for k in range(K_MAX + 1)}
    J = {k: fwd[k] - bwd[k] for k in range(K_MAX)}
    total_bwd = sum(bwd.values())
    total_fwd = sum(fwd.values())

    ep = {}
    for eps in eps_list:
        s = 0.0
        for k in range(K_MAX):
            if fwd[k] == 0 and bwd[k] == 0:
                continue
            num = max(fwd[k], eps if fwd[k] == 0 else fwd[k])
            den = max(bwd[k], eps)
            s += J[k] * math.log(num / den)
        ep[str(eps)] = s

    # Kolmogorov cycle criterion on the k-chain.
    # Any closed directed cycle on a birth-death graph must traverse at least one
    # backward edge k+1 -> k. With all backward edges of weight 0, the transition
    # graph (minus self-loops) is a DAG: no non-trivial cycles exist, so the
    # criterion is VACUOUSLY satisfied while reversibility still fails, because
    # the ratio pi(k)T(k,k+1) / pi(k+1)T(k+1,k) is +inf for every k with fwd>0.
    cycles_found = []
    for k in range(K_MAX):
        if fwd[k] > 0 and bwd[k] > 0:
            cycles_found.append({
                "cycle": f"{k}->{k+1}->{k}",
                "forward_product": fwd[k] * bwd[k],
                "reverse_product": bwd[k] * fwd[k],
                "ratio": 1.0,
            })
    return {
        "forward_counts": fwd,
        "backward_counts": bwd,
        "self_loop_counts": stay,
        "current_J": J,
        "total_forward": total_fwd,
        "total_backward": total_bwd,
        "any_regression": total_bwd > 0,
        "entropy_production_proxy_by_eps": ep,
        "kolmogorov": {
            "nontrivial_directed_cycles": len(cycles_found),
            "detail": cycles_found,
            "vacuous": len(cycles_found) == 0,
            "note": ("all backward edges have weight 0 -> transition graph is a DAG "
                     "plus self-loops; Kolmogorov criterion is vacuously satisfied, "
                     "but detailed balance fails identically because the reversibility "
                     "ratio pi(k)T(k,k+1)/(pi(k+1)T(k+1,k)) diverges wherever T(k,k+1)>0."),
        },
        "detailed_balance_holds": total_bwd > 0 and all(
            abs(J[k]) < 1e-9 for k in range(K_MAX)),
    }


# ------------------------------------------------- 3. absorbing model fit

def jump_stats(by_file):
    """Empirical per-cycle jump sizes m = k(c+1)-k(c), bucketed by k."""
    jumps = defaultdict(Counter)      # k -> Counter(m)
    tot_missing = Counter()           # k -> sum of (9-k) over transitions
    tot_gained = Counter()            # k -> sum of m
    for f, cyc in by_file.items():
        cs = sorted(cyc)
        for a_, b_ in zip(cs, cs[1:]):
            ka, kb = cyc[a_]["k_pre"], cyc[b_]["k_pre"]
            m = kb - ka
            jumps[ka][m] += 1
            tot_missing[ka] += (K_MAX - ka)
            tot_gained[ka] += m
    return jumps, tot_missing, tot_gained


def binom_pmf(n, p, m):
    if m < 0 or m > n:
        return 0.0
    p = min(max(p, 1e-12), 1 - 1e-12)
    return math.comb(n, m) * p ** m * (1 - p) ** (n - m)


def loglik_binomial(jumps, p_of_k):
    ll = 0.0
    for k, cnt in jumps.items():
        n = K_MAX - k
        if n <= 0:
            continue
        p = p_of_k(k)
        for m, c in cnt.items():
            ll += c * math.log(max(binom_pmf(n, p, m), 1e-300))
    return ll


def fit_two_param(jumps):
    """p(k) = clamp(p0 * (1 - k/9)**s, 1e-9, 1-1e-9); MLE by grid + refine."""
    def pk_of(p0, s):
        def f(k):
            v = p0 * (1.0 - k / K_MAX) ** s if k < K_MAX else 0.0
            return min(max(v, 1e-9), 1 - 1e-9)
        return f
    best = (-1e300, None, None)
    for i in range(1, 201):
        p0 = i / 200
        for j in range(0, 61):
            s = j / 20
            v = loglik_binomial(jumps, pk_of(p0, s))
            if v > best[0]:
                best = (v, p0, s)
    # refine
    p0b, sb = best[1], best[2]
    for i in range(-20, 21):
        for j in range(-20, 21):
            p0 = p0b + i / 2000
            s = sb + j / 200
            if not (0 < p0 <= 1) or s < 0:
                continue
            v = loglik_binomial(jumps, pk_of(p0, s))
            if v > best[0]:
                best = (v, p0, s)
    return {"loglik": best[0], "p0": best[1], "s": best[2]}


def fit_global_p(jumps):
    num = sum(m * c for k, cnt in jumps.items() for m, c in cnt.items())
    den = sum((K_MAX - k) * c for k, cnt in jumps.items() for m, c in cnt.items())
    p = num / den if den else 0.0
    return {"p": p, "loglik": loglik_binomial(jumps, lambda k: p)}


def propagate(hist0, p_of_k, n_cycles, ladder, single_flip=False):
    """Propagate the k-histogram; per cycle report expected positives and delta."""
    state = {k: float(v) for k, v in hist0.items()}
    out = []
    for c in range(1, n_cycles + 1):
        pos = sum(m for k, m in state.items() if k < K_MAX)
        dlt = sum(m * ladder.get(k, 0.0) for k, m in state.items() if k < K_MAX)
        out.append({"cycle": c, "exp_positives": pos, "exp_delta": dlt,
                    "mean_k": sum(k * m for k, m in state.items()) / max(sum(state.values()), 1e-12)})
        nxt = defaultdict(float)
        for k, m in state.items():
            if k >= K_MAX:
                nxt[K_MAX] += m
                continue
            n = K_MAX - k
            p = p_of_k(k)
            if single_flip:
                nxt[k + 1] += m * min(p, 1.0)
                nxt[k] += m * (1 - min(p, 1.0))
            else:
                for j in range(n + 1):
                    nxt[k + j] += m * binom_pmf(n, p, j)
        state = dict(nxt)
    return out


def chisq(obs, exp):
    s = 0.0
    for o, e in zip(obs, exp):
        e = max(e, 1e-9)
        s += (o - e) ** 2 / e
    return s


def potential_test(recs):
    """Is delta(k) the discrete gradient of a potential Phi(k) = d_pre(k)?"""
    phi = {}
    dpost = {}
    dlt = {}
    for r in recs:
        phi.setdefault(r["k_pre"], r["d_pre"])
        dpost.setdefault(r["k_pre"], r["d_post"])
        dlt.setdefault(r["k_pre"], r["delta"])
    resid = {}
    for k in sorted(phi):
        if k + 1 in phi and k + 1 < K_MAX:
            resid[f"d_post({k}) - Phi({k+1})"] = round(dpost[k] - phi[k + 1], 8)
    return {
        "Phi_k_eq_d_pre": {str(k): phi[k] for k in sorted(phi)},
        "delta_k": {str(k): dlt[k] for k in sorted(dlt)},
        "gradient_residuals": resid,
        "max_abs_residual": max((abs(v) for v in resid.values()), default=0.0),
        "terminal_sentinel": {
            "d_post_at_k8": dpost.get(8),
            "d_pre_at_k9_recorded": phi.get(9),
            "note": ("Phi(9) is recorded as the sentinel 0.0 rather than the ladder "
                     "continuation 1.1547; the potential identity holds on k=0..8 and "
                     "is broken only by that bookkeeping sentinel."),
        },
    }


# ------------------------------------------------- per-cycle observables

def cycle_table(recs):
    by_cycle = defaultdict(list)
    for r in recs:
        by_cycle[r["cycle"]].append(r)
    rows = []
    for c in sorted(by_cycle):
        rs = by_cycle[c]
        ks = [r["k_pre"] for r in rs]
        pos = sum(1 for r in rs if r["delta"] > 0)
        rows.append({
            "cycle": c,
            "n_files": len(rs),
            "mean_k": sum(ks) / len(ks),
            "k_hist": {str(k): v for k, v in sorted(Counter(ks).items())},
            "positives": pos,
            "zeros": len(rs) - pos,
            "delta_sum": round(sum(r["delta"] for r in rs), 6),
            "mean_delta_per_file": round(sum(r["delta"] for r in rs) / len(rs), 6),
            "mean_delta_per_positive": round(
                (sum(r["delta"] for r in rs) / pos) if pos else 0.0, 6),
        })
    return rows


def ladder_from_data(recs):
    lad = {}
    for r in recs:
        if r["winner"] is not None:
            lad.setdefault(r["k_pre"], r["delta"])
    return lad


# ------------------------------------------------- main

def analyze(name, path):
    recs, meta = load_corpus(path)
    T, intra, anomalies, by_file = transitions(recs)
    db = detailed_balance(T)
    rows = cycle_table(recs)
    lad = ladder_from_data(recs)
    jumps, tot_missing, tot_gained = jump_stats(by_file)
    jump_hist = {str(k): {str(m): c for m, c in sorted(cnt.items())} for k, cnt in sorted(jumps.items())}
    multi = sum(c for k, cnt in jumps.items() for m, c in cnt.items() if m > 1)
    n_trans = sum(c for k, cnt in jumps.items() for m, c in cnt.items())

    pA = {k: (tot_gained[k] / tot_missing[k]) for k in tot_missing if tot_missing[k]}
    llA = loglik_binomial(jumps, lambda k: pA.get(k, 1e-9))
    kA = len(pA)
    fitB = fit_two_param(jumps)
    fitG = fit_global_p(jumps)
    llC = loglik_binomial(jumps, lambda k: 1.0 / max(K_MAX - k, 1))

    ladder_full = {k: lad.get(k, 0.0) for k in range(K_MAX + 1)}
    c0 = min(r["cycle"] for r in recs)
    k0 = Counter(r["k_pre"] for r in recs if r["cycle"] == c0)
    ncyc = len(rows)

    simA = propagate(k0, lambda k: pA.get(k, 0.0), ncyc, ladder_full)
    simB = propagate(k0, lambda k: min(max(fitB["p0"] * (1 - k / K_MAX) ** fitB["s"], 0.0), 1.0), ncyc, ladder_full)
    simG = propagate(k0, lambda k: fitG["p"], ncyc, ladder_full)
    simS = propagate(k0, lambda k: 1.0, ncyc, ladder_full, single_flip=True)

    obs_pos = [r["positives"] for r in rows]
    obs_del = [r["delta_sum"] for r in rows]

    fit = {}
    for label, sim, npar, ll in (("A_per_k_binomial", simA, kA, llA),
                                 ("B_two_param_p0_sat", simB, 2, fitB["loglik"]),
                                 ("G_global_p", simG, 1, fitG["loglik"]),
                                 ("S_single_flip_deterministic", simS, 0, llC)):
        fit[label] = {
            "n_params": npar,
            "loglik": round(ll, 4),
            "AIC": round(2 * npar - 2 * ll, 4),
            "exp_positives": [round(x["exp_positives"], 3) for x in sim],
            "exp_delta": [round(x["exp_delta"], 4) for x in sim],
            "exp_mean_k": [round(x["mean_k"], 4) for x in sim],
            "chisq_positives": round(chisq(obs_pos, [x["exp_positives"] for x in sim]), 4),
            "chisq_delta": round(chisq(obs_del, [x["exp_delta"] for x in sim]), 4),
            "fixpoint_cycle_pred": next((x["cycle"] for x in sim if x["exp_positives"] < 0.5), None),
        }
    fit["B_two_param_p0_sat"].update(p0=fitB["p0"], saturation_exponent_s=fitB["s"])
    fit["G_global_p"].update(p=round(fitG["p"], 6))
    fit["A_per_k_binomial"].update(
        p_hat={str(k): round(v, 6) for k, v in sorted(pA.items())},
        missing_slots_at_k={str(k): tot_missing[k] for k in sorted(tot_missing)},
        gained_at_k={str(k): tot_gained[k] for k in sorted(tot_gained)})
    fit["observed_positives"] = obs_pos
    fit["observed_delta"] = obs_del
    fit["jump_size_histogram_by_k"] = jump_hist
    fit["n_transitions"] = n_trans
    fit["n_multi_step"] = multi
    fit["frac_multi_step"] = round(multi / max(n_trans, 1), 4)

    # delta-peak decomposition: delta_c = positives_c * mean_delta_per_positive_c
    decomp = []
    for i, r in enumerate(rows):
        prev = rows[i - 1] if i else None
        decomp.append({
            "cycle": r["cycle"],
            "positives": r["positives"],
            "mean_delta_per_positive": r["mean_delta_per_positive"],
            "delta_sum": r["delta_sum"],
            "d_positives_vs_prev": (r["positives"] - prev["positives"]) if prev else None,
            "d_mean_delta_vs_prev": (round(r["mean_delta_per_positive"] - prev["mean_delta_per_positive"], 6)
                                     if prev else None),
            "policy_term": (round((r["positives"] - prev["positives"]) * prev["mean_delta_per_positive"], 6)
                            if prev else None),
            "state_term": (round(prev["positives"] * (r["mean_delta_per_positive"] - prev["mean_delta_per_positive"]), 6)
                           if prev else None),
        })

    series = []
    for r in rows:
        c = r["cycle"]
        tr = {f"{k}->{k+1}": T.get((k, k + 1), 0) for k in range(K_MAX)}
        series.append({
            "cycle": c,
            "n_files": r["n_files"],
            "mean_k": round(r["mean_k"], 6),
            "k_hist": r["k_hist"],
            "positives": r["positives"],
            "delta_sum": r["delta_sum"],
        })
    # per-cycle transitions (cycle c -> c+1)
    per_cycle_T = {}
    for f, cyc in by_file.items():
        cs = sorted(cyc)
        for a_, b_ in zip(cs, cs[1:]):
            key = f"c{a_}->c{b_}"
            per_cycle_T.setdefault(key, Counter())[(cyc[a_]["k_pre"], cyc[b_]["k_pre"])] += 1
    for key, cnt in per_cycle_T.items():
        fwd = {f"{k}->{k+1}": cnt.get((k, k + 1), 0) for k in range(K_MAX) if cnt.get((k, k + 1), 0)}
        bwd = {f"{k+1}->{k}": cnt.get((k + 1, k), 0) for k in range(K_MAX) if cnt.get((k + 1, k), 0)}
        stay = {f"{k}->{k}": cnt.get((k, k), 0) for k in range(K_MAX + 1) if cnt.get((k, k), 0)}
        Jc = {str(k): cnt.get((k, k + 1), 0) - cnt.get((k + 1, k), 0) for k in range(K_MAX)}
        epc = 0.0
        for k in range(K_MAX):
            f_ = cnt.get((k, k + 1), 0)
            b_ = cnt.get((k + 1, k), 0)
            if f_ or b_:
                epc += (f_ - b_) * math.log(max(f_, 1e-9) / max(b_, 1.0))
        ci = int(key.split("->")[0][1:])
        for s in series:
            if s["cycle"] == ci:
                s["transitions"] = {"forward": fwd, "backward": bwd, "stay": stay}
                s["J"] = Jc
                s["entropy_production_proxy_eps1"] = round(epc, 6)
    for s in series:
        s.setdefault("transitions", {"forward": {}, "backward": {}, "stay": {}})
        s.setdefault("J", {})
        s.setdefault("entropy_production_proxy_eps1", 0.0)

    return {
        "corpus": name,
        "file": os.path.basename(path),
        "meta": meta,
        "n_dispatches": len(recs),
        "n_files": len(by_file),
        "n_cycles": ncyc,
        "cycle_table": rows,
        "delta_ladder_by_k_covered": {str(k): v for k, v in sorted(ladder_full.items())},
        "transitions_pooled": {f"{a_}->{b_}": c for (a_, b_), c in sorted(T.items())},
        "intra_dispatch_transitions": {f"{a_}->{b_}": c for (a_, b_), c in sorted(intra.items())},
        "anomalies": anomalies,
        "detailed_balance": db,
        "model_fit": fit,
        "potential_test": potential_test(recs),
        "delta_decomposition": decomp,
        "series": series,
    }


def analyze_aux(path):
    with open(path) as fh:
        d = json.load(fh)
    cy = d["cycles"]
    deltas = [c["delta_d"] for c in cy]
    zero_then_positive = [
        {"zero_at_cycle": cy[i]["cycle"], "next_delta": deltas[i + 1]}
        for i in range(len(deltas) - 1) if deltas[i] == 0 and deltas[i + 1] > 0
    ]
    incr = sum(1 for a_, b_ in zip(deltas, deltas[1:]) if b_ > a_)
    return {
        "file": os.path.basename(path),
        "n_cycles": len(cy),
        "deltas": deltas,
        "monotone_nonincreasing": incr == 0,
        "n_increases": incr,
        "zero_delta_followed_by_positive": zero_then_positive,
        "d_pre_constant_1.0": all(abs(c["d_pre"] - 1.0) < 1e-12 for c in cy),
        "note": ("d_pre is renormalised to 1.0 every cycle in this file, so k is not "
                 "recoverable; this is a delta-series, not a state trajectory."),
    }


def main():
    ap = argparse.ArgumentParser(description="T3 DYNAMICS: detailed-balance test on the atom edit log")
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--out-dir", required=True)
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    results = {"test": "T3-DYNAMICS", "corpora": {}}
    all_recs = []
    for name, fn in CORPORA.items():
        p = os.path.join(args.data_dir, fn)
        results["corpora"][name] = analyze(name, p)
        recs, _ = load_corpus(p)
        for r in recs:
            r["file"] = f"{name}::{r['file']}"
        all_recs.extend(recs)

    # pooled
    T, intra, anom, by_file = transitions(all_recs)
    db = detailed_balance(T)
    jumps, tot_missing, tot_gained = jump_stats(by_file)
    pA = {k: tot_gained[k] / tot_missing[k] for k in tot_missing if tot_missing[k]}
    llA = loglik_binomial(jumps, lambda k: pA.get(k, 1e-9))
    fitB = fit_two_param(jumps)
    fitG = fit_global_p(jumps)
    jump_hist = {str(k): {str(m): c for m, c in sorted(cnt.items())} for k, cnt in sorted(jumps.items())}
    n_trans = sum(c for k, cnt in jumps.items() for m, c in cnt.items())
    multi = sum(c for k, cnt in jumps.items() for m, c in cnt.items() if m > 1)
    results["pooled"] = {
        "n_dispatches": len(all_recs),
        "n_files": len(by_file),
        "n_transitions": n_trans,
        "n_multi_step": multi,
        "frac_multi_step": round(multi / max(n_trans, 1), 4),
        "jump_size_histogram_by_k": jump_hist,
        "transitions": {f"{x}->{y}": c for (x, y), c in sorted(T.items())},
        "intra_dispatch_transitions": {f"{x}->{y}": c for (x, y), c in sorted(intra.items())},
        "n_anomalies_multi_step": len(anom),
        "n_anomalies_regression": sum(1 for a_ in anom if a_["type"] == "regression"),
        "detailed_balance": db,
        "p_hat_per_k": {str(k): round(v, 6) for k, v in sorted(pA.items())},
        "loglik_per_k": round(llA, 4),
        "AIC_per_k": round(2 * len(pA) - 2 * llA, 4),
        "two_param": {"p0": fitB["p0"], "s": fitB["s"], "loglik": round(fitB["loglik"], 4),
                      "AIC": round(4 - 2 * fitB["loglik"], 4)},
        "global_p": {"p": round(fitG["p"], 6), "loglik": round(fitG["loglik"], 4),
                     "AIC": round(2 - 2 * fitG["loglik"], 4)},
        "potential_test": potential_test(all_recs),
    }

    aux = os.path.join(args.data_dir, AUX_20CYCLE)
    if os.path.exists(aux):
        results["aux_20cycle"] = analyze_aux(aux)

    with open(os.path.join(args.out_dir, "T3-results.json"), "w") as fh:
        json.dump(results, fh, indent=2)

    series = {c: results["corpora"][c]["series"] for c in results["corpora"]}
    with open(os.path.join(args.out_dir, "dynamics-series.json"), "w") as fh:
        json.dump(series, fh, indent=2)

    # console summary
    print(f"pooled dispatches: {results['pooled']['n_dispatches']}, files: {results['pooled']['n_files']}")
    print("pooled forward:", db["forward_counts"])
    print("pooled backward:", db["backward_counts"])
    print("pooled J:", db["current_J"])
    print("EP proxy:", db["entropy_production_proxy_by_eps"])
    print("multi-step jumps:", results["pooled"]["n_multi_step"], "/", results["pooled"]["n_transitions"],
          "regressions:", results["pooled"]["n_anomalies_regression"])
    print("jump hist:", json.dumps(results["pooled"]["jump_size_histogram_by_k"]))
    print("potential max resid:", results["pooled"]["potential_test"]["max_abs_residual"])
    print("pooled AICs: per_k", results["pooled"]["AIC_per_k"], "two", results["pooled"]["two_param"]["AIC"], "global", results["pooled"]["global_p"]["AIC"])
    for name, r in results["corpora"].items():
        print(f"\n== {name}: {r['n_dispatches']} dispatches, {r['n_cycles']} cycles")
        for row in r["cycle_table"]:
            print("  ", row["cycle"], "n=", row["n_files"], "mean_k=", round(row["mean_k"], 4),
                  "pos=", row["positives"], "delta=", row["delta_sum"],
                  "delta/pos=", row["mean_delta_per_positive"])
        for lbl, f in r["model_fit"].items():
            if not (isinstance(f, dict) and "AIC" in f):
                continue
            print("   fit", lbl, "AIC=", f["AIC"], "chisq_pos=", f["chisq_positives"],
                  "chisq_delta=", f["chisq_delta"], "exp_pos=", f["exp_positives"])
        print("   decomposition:", json.dumps(r["delta_decomposition"]))
        print("   obs_pos:", r["model_fit"]["observed_positives"], "obs_delta:", r["model_fit"]["observed_delta"])
    if "aux_20cycle" in results:
        print("\naux 20-cycle:", json.dumps(results["aux_20cycle"]))


if __name__ == "__main__":
    main()
