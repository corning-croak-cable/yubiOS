# T2 — three named untested items, closed empirically

Script: `tests/t2_24d_gl.py` (standalone, argparse, explicit seeds)
Results: `tests/T2-results.json`
Runtime: 221 s (python3.12, numpy 2.5.1 / scipy 1.18.0)
Master matrix: `data/real/per_row_coverage_v3.json`, 2286 × 9, V₂(9-D) = 0.723529

All three items are computed on the **null-standardized** statistic where the
paper requires it: ΔV₂ = V₂ − mean(V₂ under the fixed-margin curveball null),
10·N trades per draw, using the bundle's own `common.curveball_fast`.

---

## ITEM 1 — P-H2's 24-D clause

**Prediction.** Spearman(1 − V₂, Hodge curl fraction ρ_c) ≥ +0.6 across corpora.
The 9-D test gave ρ = −0.4545 (p = 0.160, n = 11) → falsified. The 24-D clause
was untested for lack of a 24-D matrix.

### Construction

The 24-D feature space is built by `build_24d()`, which reproduces
`ladder_correlations.build_ladder`'s 24-D branch exactly — same RNG draw order,
same seed (11, the real-corpus seed in that script), so the full-corpus numbers
are directly comparable to `ladder_VD.json`'s "24 (+12 indep NSS +3 meta)" and
"24 (mass-correlated NSS)" rows:

- cols 0–8: the 9 coverage primitives
- cols 9–20: 12 NSS-like columns — `indep` variant `p ~ U(0.15,0.6)` per column;
  `masscorr` variant `p = 0.15 + 0.70·mass_n` per row
- cols 21–23: 3 meta — `0.6·mass_n + N(0,0.8)`, `N(0,1)`, `Bernoulli(0.2)`

**Binarization rule for the Hodge item graph (stated as required).** The 9
primitive and 12 NSS columns are already 0/1 and are used as-is; the 3 meta
columns are binarized at their column median **computed once on the full
2286-row corpus and applied globally to every sub-corpus** (value > median → 1).
Graph: kNN, k = 8, Jaccard distance on the binarized 24-D codes, `seed=20260812`,
Betti computation disabled (only ρ_c is needed).

Sub-corpora (8). The eligible/deferred/refused bands reproduce the
N = 1322 / 760 / 204 split of `B-hodge-yubios.json`: eligible = coverage_sum ≥ 5,
deferred = 1 ≤ coverage_sum ≤ 4, refused = coverage_sum = 0.

### Results — variant A, independent NSS (global build, seed 11)

| sub-corpus | N | V₂(24-D) | 1 − V₂ | ρ_c | edges | triangles |
|---|---|---|---|---|---|---|
| full_2286 | 2286 | 0.2940 | 0.7060 | 6.372e-04 | 13506 | 8819 |
| skills | 474 | 0.2253 | 0.7747 | 8.457e-04 | 2721 | 2012 |
| docs | 126 | 0.2521 | 0.7479 | 1.497e-03 | 730 | 700 |
| refs | 791 | 0.2512 | 0.7488 | 8.078e-04 | 4738 | 3375 |
| self | 895 | 0.1609 | 0.8391 | 1.144e-03 | 4998 | 2911 |
| eligible | 1322 | 0.1638 | 0.8362 | 3.451e-04 | 8027 | 6019 |
| deferred | 760 | 0.1229 | 0.8771 | 8.485e-04 | 4267 | 2450 |
| refused | 204 | 0.2010 | 0.7990 | 3.573e-03 | 1074 | 840 |

### Results — variant B, mass-correlated NSS (global build, seed 11)

| sub-corpus | N | V₂(24-D) | 1 − V₂ | ρ_c | edges | triangles |
|---|---|---|---|---|---|---|
| full_2286 | 2286 | 0.4473 | 0.5527 | 6.246e-04 | 14719 | 16256 |
| skills | 474 | 0.2713 | 0.7287 | 1.007e-03 | 3393 | 5294 |
| docs | 126 | 0.3043 | 0.6957 | 2.321e-03 | 889 | 1698 |
| refs | 791 | 0.3449 | 0.6551 | 1.164e-03 | 5567 | 6980 |
| self | 895 | 0.2080 | 0.7920 | 1.244e-03 | 4793 | 3472 |
| eligible | 1322 | 0.2100 | 0.7900 | 2.122e-04 | 9416 | 13018 |
| deferred | 760 | 0.1342 | 0.8658 | 9.542e-04 | 4025 | 2303 |
| refused | 204 | 0.1858 | 0.8142 | 1.905e-03 | 1058 | 1275 |

### Spearman(1 − V₂, ρ_c)

Global build, seed 11 (primary):

| variant | set | n | ρ_s | p | ≥ +0.6? |
|---|---|---|---|---|---|
| indep NSS | all 8 | 8 | **+0.1667** | 0.693 | no |
| indep NSS | drop refused | 7 | +0.1786 | 0.702 | no |
| indep NSS | sub-corpora only (drop full) | 7 | −0.0714 | 0.879 | no |
| masscorr NSS | all 8 | 8 | **+0.0952** | 0.823 | no |
| masscorr NSS | drop refused | 7 | −0.0357 | 0.939 | no |
| masscorr NSS | sub-corpora only | 7 | −0.2143 | 0.645 | no |

Per-sub-corpus rebuild (sensitivity, each sub-corpus draws its own NSS/meta):
indep +0.000 (p = 1.000, n = 8), masscorr +0.357 (p = 0.385, n = 8); dropping
refused gives 0.000 and +0.036. No configuration reaches +0.6, and none is
significant at any conventional level.

**VERDICT — the 24-D clause does NOT survive.** All six primary correlations lie
between −0.21 and +0.17 with p ≥ 0.64; the +0.6 threshold is far outside every
confidence range at n = 7–8. Direction differs from the 9-D result (which was
negative, −0.4545) but magnitude is indistinguishable from zero either way. The
clause fails not by sign reversal but by the absence of any relationship.

Caveat worth recording: in 24-D the Jaccard neighbour graph is dominated by the
12 random NSS columns, which carry no coverage signal — the graph is 12–15 bits
of noise against 9 bits of structure. This *weakens* rather than rescues the
prediction, since P-H2 asserted the correlation should hold in the 24-D space
the paper itself defined.

---

## ITEM 2a — GL P4, fluctuation peak (§4.4)

Protocol: N ∈ {40, 79, 160, 320, 640, 1280, 2286}, 40 reps each; each rep
subsamples rows, computes V₂, subtracts the mean of its **own** 20-rep curveball
null. Var[ΔV₂] taken across the 40 reps, with a 4000-draw bootstrap 95 % CI so an
apparent peak can be tested rather than eyeballed.

| N | reps | mean ΔV₂ | Var[ΔV₂] | bootstrap CI95 | Var/\|ΔV₂\| |
|---|---|---|---|---|---|
| 40 | 40 | +0.01432 | 1.394e-04 | [8.011e-05, 1.982e-04] | 9.737e-03 |
| 79 | 40 | +0.01193 | 1.422e-04 | [8.545e-05, 1.948e-04] | 1.192e-02 |
| 160 | 40 | +0.01623 | 5.679e-05 | [3.290e-05, 8.206e-05] | 3.499e-03 |
| 320 | 40 | +0.01497 | 3.189e-05 | [1.925e-05, 4.600e-05] | 2.130e-03 |
| 640 | 40 | +0.01556 | 1.516e-05 | [8.621e-06, 2.210e-05] | 9.743e-04 |
| 1280 | 40 | +0.01476 | 8.215e-06 | [5.513e-06, 1.057e-05] | 5.566e-04 |
| 2286 | 10 | +0.01424 | 3.818e-08 | [6.588e-09, 7.095e-08] | 2.682e-06 |

The raw argmax of both Var[ΔV₂] and Var/|ΔV₂| falls at N = 79, which is nominally
interior. It is **not significant**: Var(79) = 1.422e-04 vs Var(40) = 1.394e-04,
a 2 % difference against bootstrap CIs that overlap almost completely
(`beats_left_neighbour: false`). The curve is a flat plateau over N = 40–79
followed by strictly monotone decay to N = 2286 (`monotone_decreasing_after_argmax:
true`), consistent with the ordinary 1/reps shrinkage of a sampling variance.

Mean ΔV₂ is essentially N-independent at +0.012 to +0.016 — the real matrix sits
consistently *above* its fixed-margin null by a fixed amount, with no anomaly at
any N.

**VERDICT — no fluctuation peak. P4 is not supported; the paper's prediction of
monotone decay holds.** The one nominal interior argmax is a noise artifact at
the small-N edge of the grid and disappears under its own bootstrap CI.

---

## ITEM 2b — GL P5, susceptibility divergence (§4.5)

χ(N) = mean |d(ΔV₂)/dh| under single-row perturbation; leave-one-out over up to
200 random rows per N (all N rows when N < 200), same grid. Each LOO set gets its
own curveball null.

| N | LOO rows | ΔV₂ base | mean \|ΔΔV₂\| | SEM | χ (h = 1/N) |
|---|---|---|---|---|---|
| 40 | 40 | +0.03141 | 4.9860e-03 | 5.30e-04 | 0.1994 |
| 79 | 79 | +0.00657 | 2.8666e-03 | 2.67e-04 | 0.2265 |
| 160 | 160 | +0.01146 | 1.8114e-03 | 1.10e-04 | 0.2898 |
| 320 | 200 | +0.01231 | 1.3781e-03 | 7.38e-05 | 0.4410 |
| 640 | 200 | +0.01726 | 8.0537e-04 | 4.24e-05 | 0.5154 |
| 1280 | 200 | +0.01595 | 5.9177e-04 | 3.14e-05 | 0.7575 |
| 2286 | 200 | +0.01448 | 4.5493e-04 | 2.57e-05 | 1.0400 |

χ is definitionally sensitive to the units of h, so both conventions are fitted
and reported:

- **h = 1/N** (one row as a fraction of corpus mass):
  χ = 0.0386 · N^**+0.4155**, 95 % CI [+0.3523, +0.4786], R² = 0.983
- **h = 1 row** (absolute): per-row response = 0.0386 · N^**−0.5845**,
  95 % CI [−0.6477, −0.5214], R² = 0.991

Both are smooth, monotone, well-fitted power laws over the full 57× range in N.
Neither shows an interior peak nor a blow-up at any finite N_c
(`interior_peak_in_chi: false`, `divergence_at_finite_Nc: false`).

**VERDICT — no divergence. P5 is not supported.** But the paper's specific claim
of "~1/N scaling" is **also not confirmed**: the absolute-h exponent is
−0.585 ± 0.032, and −1 lies far outside its 95 % CI
(`absolute_h_b_consistent_with_minus1: false`). The honest reading is that P5's
divergence is falsified while the paper's replacement scaling law is itself
mis-stated — the response decays as roughly N^−0.58, closer to 1/√N than 1/N.

---

## ITEM 3 — GL P7, critical slowing-down (§4.7)

Remove 5 % of rows at random, then restore a random f ∈ {0, .25, .5, .75, 1} of
the removed rows; recovery = |ΔV₂(perturbed) − ΔV₂(full)|. 20 reps × 5 restore
levels, 20-rep curveball null per point, at N = 2286 and N = 320. Models fitted
on all 100 rep-level points per N:

- linear (append-only saturation): R = a + b·(1 − f), k = 3
- critical exponent (GL): R = a + A·|1 − f|^ν, ν free, k = 4
- AIC = n·ln(RSS/n) + 2k

### N = 2286 (ΔV₂ full = +0.014001)

mean recovery: f=0 → 7.337e-04, .25 → 5.411e-04, .5 → 5.387e-04,
.75 → 4.104e-04, 1.0 → 3.023e-04

| model | params | RSS | AIC |
|---|---|---|---|
| linear | a = 3.065e-04, b = 3.974e-04 | 1.3726e-05 | **−1574.14** |
| critical | a = 3.076e-04, A = 3.971e-04, ν = 1.0134 ± 0.6201 | 1.3726e-05 | −1572.14 |

ΔAIC (linear − critical) = **−2.00**. ν 95 % CI = [−0.202, +2.229] — includes 1,
so ν is not distinguishable from linear.

### N = 320 (ΔV₂ full = +0.017599)

mean recovery: f=0 → 1.541e-03, .25 → 1.528e-03, .5 → 9.292e-04,
.75 → 1.091e-03, 1.0 → 4.554e-04

| model | params | RSS | AIC |
|---|---|---|---|
| linear | a = 5.875e-04, b = 1.043e-03 | 6.3648e-05 | **−1420.73** |
| critical | a = 4.678e-04, A = 1.082e-03, ν = 0.5801 ± 0.3008 | 6.2996e-05 | −1419.76 |

ΔAIC (linear − critical) = **−0.97**. ν 95 % CI = [−0.009, +1.170] — again
includes 1.

**VERDICT — the linear (append-only saturation) model wins by AIC at both N.**
The critical-exponent model buys essentially nothing in RSS (0.0004 % at
N = 2286, 1.0 % at N = 320) and is penalized for its extra parameter. ν is
statistically indistinguishable from 1 at both scales. P7 is not supported;
recovery is linear in restored mass.

---

## Trims (runtime budget)

Two, both logged in `T2-results.json` under `trims`:

1. **P4 at N = 2286**: reps 40 → 10. Subsampling 2286 of 2286 rows is degenerate
   (a single deterministic subset), so the remaining spread is null-estimator
   noise only and does not measure corpus fluctuation. This point should be read
   as a lower bound, not a measurement of Var[ΔV₂] at full N.
2. **P5**: per-LOO curveball null uses 5 reps (the base-set null uses the full
   20). 200 LOO rows per N were retained as specified. The resulting per-N SEMs
   (2.6e-05 to 5.3e-04, i.e. 5–11 % of the mean) are small relative to the 11×
   spread of the fitted power law, so the exponent is not trim-limited.

Nothing else was reduced: Item 1 ran all 8 sub-corpora × 2 variants × 2 build
rules; P4 ran 40 reps × 20 null reps at every other N; P7 ran the full 20 reps ×
5 restore levels × 20 null reps at both N.

## Summary

| item | prediction | result | verdict |
|---|---|---|---|
| P-H2 24-D clause | Spearman ≥ +0.6 | +0.167 (indep, p = 0.69), +0.095 (masscorr, p = 0.82), n = 8 | **does not survive** |
| GL P4 fluctuation peak | interior peak in Var[ΔV₂] | argmax at N = 79 not significant vs bootstrap CI; monotone decay after | **no peak** |
| GL P5 susceptibility | divergence near N_c | smooth power law, b = +0.416 (h=1/N) / −0.585 (h=1 row), no peak | **no divergence** (and not 1/N either) |
| GL P7 slowing-down | critical exponent ν ≠ 1 | linear wins AIC by 2.00 (N=2286) and 0.97 (N=320); ν CI includes 1 | **linear / append-only saturation** |
