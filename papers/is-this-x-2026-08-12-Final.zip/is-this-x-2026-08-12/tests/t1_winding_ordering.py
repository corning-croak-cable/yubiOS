#!/usr/bin/env python3.12
"""t1_winding_ordering.py

Two empirical tests, both run against the shipped real corpora.

ITEM 1 -- P-H3 clause (ii): quantized azimuthal S^2 winding.
    z-score 2286x9 -> PCA top-2 -> RMS-1 scale -> stereographic_lift
    -> per-row (theta_i, phi_i).  kNN(k=8, Jaccard) item graph, Construction A1
    flow, Hodge decomposition -> harmonic component h.  Fundamental cycle basis
    (BFS spanning forest + chords).  Per cycle: azimuthal winding
    W = sum wrap(dphi) and harmonic circulation C = oint h.  Tests whether C is
    concentrated near integer multiples of 2*pi and whether |C| tracks |W|.
    Null: curveball matrices, embedding + graph + Hodge recomputed per draw.

ITEM 2 -- Ordering-permutation null (Remark 1) on the real corpora.
    Rows placed on the Fibonacci golden-angle lattice by PC1 rank; three
    azimuthal statistics (weighted Y_3^3 probe, Parseval Y_3^3 energy share of
    the L=3 ridge SH fit, azimuthal power at m=3) compared against an ensemble
    of shuffled index assignments.  Run on per_row_coverage_v3.json (2286x9)
    and on real-gwtc-matrix.csv (269x9, luminosity_distance log-transformed).

Every number printed is measured.  Nothing is asserted that was not computed.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import os
import sys
import time

import numpy as np
import scipy.sparse as sp
from scipy.sparse.csgraph import connected_components

TWO_PI = 2.0 * math.pi

BUNDLE = "/var/workspace/session/final/bundle"
CORPUS_PY = os.path.join(BUNDLE, "skills/curved-corpus-create/scripts/create_corpus.py")
HODGE_PY = os.path.join(BUNDLE, "scripts/hodge_decompose.py")
MASTER = os.path.join(BUNDLE, "data/real/per_row_coverage_v3.json")
GWTC = os.path.join(BUNDLE, "data/real/real-gwtc-matrix.csv")


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


cc = _load("create_corpus", CORPUS_PY)
hd = _load("hodge_decompose", HODGE_PY)


# ---------------------------------------------------------------- embedding

def zscore(x):
    x = np.asarray(x, dtype=float)
    mu = x.mean(0)
    sd = x.std(0)
    sd = np.where(sd > 1e-12, sd, 1.0)
    return (x - mu) / sd


def pca_top2(z):
    zc = z - z.mean(0)
    u, s, vt = np.linalg.svd(zc, full_matrices=False)
    scores = u[:, :2] * s[:2]
    tot = float((s ** 2).sum())
    pc12 = float((s[:2] ** 2).sum() / tot) if tot > 0 else 0.0
    return scores, pc12, s


def rms1(scores):
    r = math.sqrt(float(np.mean(np.sum(scores ** 2, axis=1))))
    return scores / r if r > 1e-12 else scores


def s2_coords(M):
    """z-score -> PCA top2 -> RMS-1 -> stereographic lift -> (theta, phi, xyz, scores)."""
    z = zscore(M)
    scores, pc12, sv = pca_top2(z)
    scores = rms1(scores)
    xyz = cc.stereographic_lift(scores)
    nrm = np.linalg.norm(xyz, axis=1, keepdims=True)
    xyz = xyz / np.maximum(nrm, 1e-15)
    theta = np.arccos(np.clip(xyz[:, 2], -1.0, 1.0))
    phi = np.mod(np.arctan2(xyz[:, 1], xyz[:, 0]), TWO_PI)
    return theta, phi, xyz, scores, pc12


# ---------------------------------------------------------------- cycles

def spanning_forest(edges, N):
    """BFS forest. Returns parent, parent_edge (signed edge index), depth, root."""
    adj = [[] for _ in range(N)]
    for e, (i, j) in enumerate(edges):
        adj[int(i)].append((int(j), e, +1))   # traversing i->j uses +h[e]
        adj[int(j)].append((int(i), e, -1))
    parent = np.full(N, -1, dtype=np.int64)
    pedge = np.full(N, -1, dtype=np.int64)
    psign = np.zeros(N, dtype=np.int8)
    depth = np.full(N, -1, dtype=np.int64)
    root = np.full(N, -1, dtype=np.int64)
    tree_edges = set()
    for src in range(N):
        if depth[src] >= 0:
            continue
        depth[src] = 0
        root[src] = src
        stack = [src]
        while stack:
            u = stack.pop()
            for v, e, sgn in adj[u]:
                if depth[v] < 0:
                    depth[v] = depth[u] + 1
                    parent[v] = u
                    pedge[v] = e
                    psign[v] = sgn      # sign for traversing u->v
                    root[v] = src
                    tree_edges.add(e)
                    stack.append(v)
    return parent, pedge, psign, depth, root, tree_edges


def path_to_root(v, parent, pedge, psign):
    """List of (edge, sign) traversing v -> root (i.e. child->parent steps)."""
    out = []
    while parent[v] >= 0:
        out.append((int(pedge[v]), -int(psign[v])))  # reverse of parent->child
        v = int(parent[v])
    return out, v


def fundamental_cycles(edges, N, max_cycles=None, rng=None):
    """Chord-induced fundamental cycles as ordered node lists + signed edges."""
    parent, pedge, psign, depth, root, tree_edges = spanning_forest(edges, N)
    chords = [e for e in range(len(edges)) if e not in tree_edges]
    if max_cycles is not None and len(chords) > max_cycles:
        idx = rng.choice(len(chords), size=max_cycles, replace=False)
        chords = [chords[i] for i in np.sort(idx)]
    # ancestor chain caches
    cycles = []
    for e in chords:
        i, j = int(edges[e][0]), int(edges[e][1])
        if root[i] != root[j]:
            continue
        # walk up to LCA
        a, b = i, j
        pa, pb = [], []
        da, db = int(depth[a]), int(depth[b])
        while da > db:
            pa.append(a)
            a = int(parent[a]); da -= 1
        while db > da:
            pb.append(b)
            b = int(parent[b]); db -= 1
        while a != b:
            pa.append(a); pb.append(b)
            a = int(parent[a]); b = int(parent[b])
        lca = a
        # explicit node sequence: i -> ... -> lca -> ... -> j -> (chord back to i)
        up_i = pa + [lca]
        up_j = pb + [lca]
        node_seq = up_i + list(reversed(up_j[:-1]))
        # signed edge list along node_seq then chord j->i
        signed = []
        ok = True
        for a_, b_ in zip(node_seq[:-1], node_seq[1:]):
            if parent[b_] == a_:
                signed.append((int(pedge[b_]), int(psign[b_])))
            elif parent[a_] == b_:
                signed.append((int(pedge[a_]), -int(psign[a_])))
            else:
                ok = False
                break
        if not ok:
            continue
        # chord: from j back to i. edge e is (i<j) oriented i->j with +1
        signed.append((e, -1))   # traversing j -> i
        cycles.append((node_seq, signed))
    return cycles, len(chords)


def wrap(d):
    return (d + math.pi) % TWO_PI - math.pi


def cycle_stats(cycles, phi, harm):
    W = np.zeros(len(cycles))
    C = np.zeros(len(cycles))
    L = np.zeros(len(cycles), dtype=np.int64)
    for n, (node_seq, signed) in enumerate(cycles):
        seq = node_seq + [node_seq[0]]
        p = phi[np.array(seq)]
        W[n] = float(np.sum(wrap(np.diff(p))))
        C[n] = float(sum(s * harm[e] for e, s in signed))
        L[n] = len(signed)
    return W, C, L


# ---------------------------------------------------------------- tests

def rayleigh(frac):
    """Rayleigh test of uniformity for fractional parts in [0,1)."""
    a = TWO_PI * np.asarray(frac, dtype=float)
    n = len(a)
    if n == 0:
        return {"n": 0}
    Cbar = np.cos(a).mean()
    Sbar = np.sin(a).mean()
    R = math.hypot(Cbar, Sbar)
    Z = n * R * R
    p = math.exp(-Z) * (1 + (2 * Z - Z * Z) / (4 * n)) if n > 0 else 1.0
    p = min(max(p, 0.0), 1.0)
    return {"n": int(n), "Rbar": float(R), "Z": float(Z), "p": float(p),
            "mean_angle": float(math.atan2(Sbar, Cbar) % TWO_PI)}


def ks_uniform(frac):
    x = np.sort(np.asarray(frac, dtype=float))
    n = len(x)
    if n == 0:
        return {"n": 0}
    i = np.arange(1, n + 1)
    d = max(float(np.max(i / n - x)), float(np.max(x - (i - 1) / n)))
    lam = (math.sqrt(n) + 0.12 + 0.11 / math.sqrt(n)) * d
    s = 0.0
    for k in range(1, 101):
        s += ((-1) ** (k - 1)) * math.exp(-2 * k * k * lam * lam)
    p = min(max(2 * s, 0.0), 1.0)
    return {"n": int(n), "D": float(d), "p": float(p)}


def pearson(a, b):
    a = np.asarray(a, float); b = np.asarray(b, float)
    if len(a) < 3 or a.std() < 1e-15 or b.std() < 1e-15:
        return {"r": None, "p": None, "n": int(len(a))}
    r = float(np.corrcoef(a, b)[0, 1])
    n = len(a)
    if abs(r) >= 1.0:
        return {"r": r, "p": 0.0, "n": n}
    t = r * math.sqrt((n - 2) / (1 - r * r))
    # normal approximation for large n
    p = math.erfc(abs(t) / math.sqrt(2))
    return {"r": r, "t": float(t), "p": float(p), "n": int(n)}


def spearman(a, b):
    ra = np.argsort(np.argsort(np.asarray(a, float))).astype(float)
    rb = np.argsort(np.argsort(np.asarray(b, float))).astype(float)
    return pearson(ra, rb)


# ---------------------------------------------------------------- ITEM 1

def item1_once(M, seed, k=8, compute_betti=False, max_cycles=None, rng=None):
    theta, phi, xyz, scores, pc12 = s2_coords(M)
    edges, ginfo = hd.build_graph(M, "knn", k=k, seed=seed)
    tris, trunc = hd.enumerate_triangles(edges, M.shape[0], seed=seed)
    res, arr = hd.hodge_decompose(M, edges, tris, compute_betti=compute_betti)
    harm = arr["harm"]
    w = arr["w"]
    if rng is None:
        rng = np.random.default_rng(seed)
    cycles, n_chords = fundamental_cycles(edges, M.shape[0], max_cycles=max_cycles, rng=rng)
    W, C, L = cycle_stats(cycles, phi, harm)
    return dict(theta=theta, phi=phi, edges=edges, harm=harm, w=w, res=res,
                ginfo=ginfo, cycles=cycles, W=W, C=C, L=L, n_chords=n_chords,
                pc12=pc12, scores=scores)


def item1_summary(W, C, L):
    wn = W / TWO_PI
    cn = C / TWO_PI
    frac_w = np.mod(wn, 1.0)
    frac_c = np.mod(cn, 1.0)
    # distance to nearest integer (0 = perfectly quantized, 0.5 = anti)
    dw = np.abs(frac_w - np.round(frac_w))
    dc = np.abs(frac_c - np.round(frac_c))
    out = {
        "n_cycles": int(len(W)),
        "cycle_len_mean": float(L.mean()) if len(L) else None,
        "winding": {
            "mean": float(W.mean()), "sd": float(W.std(ddof=1)) if len(W) > 1 else 0.0,
            "abs_mean": float(np.abs(W).mean()),
            "n_number_hist": {str(int(v)): int(c) for v, c in
                              zip(*np.unique(np.round(wn).astype(int), return_counts=True))},
            "max_abs_dev_from_integer_multiple": float(np.max(dw)) if len(W) else None,
            "frac_rayleigh": rayleigh(frac_w),
            "frac_ks_uniform": ks_uniform(frac_w),
        },
        "circulation": {
            "mean": float(C.mean()), "sd": float(C.std(ddof=1)) if len(C) > 1 else 0.0,
            "abs_mean": float(np.abs(C).mean()),
            "abs_max": float(np.abs(C).max()) if len(C) else None,
            "over_2pi_abs_mean": float(np.abs(cn).mean()),
            "n_number_hist": {str(int(v)): int(c) for v, c in
                              zip(*np.unique(np.round(cn).astype(int), return_counts=True))},
            "quantiles_abs": [float(q) for q in np.quantile(np.abs(C), [0.5, 0.9, 0.99, 1.0])] if len(C) else None,
            "mean_dist_to_integer_multiple_of_2pi": float(dc.mean()) if len(C) else None,
            "frac_rayleigh": rayleigh(frac_c),
            "frac_ks_uniform": ks_uniform(frac_c),
        },
        "corr_absC_absW_pearson": pearson(np.abs(C), np.abs(W)),
        "corr_absC_absW_spearman": spearman(np.abs(C), np.abs(W)),
        "corr_C_W_pearson": pearson(C, W),
    }
    return out


def run_item1(args, log):
    M, meta, prim = hd.load_coverage_json(MASTER)
    log(f"[T1] loaded master matrix {M.shape}")
    t0 = time.time()
    real = item1_once(M, args.graph_seed, k=args.k, compute_betti=True)
    log(f"[T1] real hodge done in {time.time()-t0:.1f}s  "
        f"E={real['ginfo']['n_edges']} chords={real['n_chords']} "
        f"cycles={len(real['cycles'])} rho_h={real['res']['rho_harm']:.3e}")
    W, C, L = real["W"], real["C"], real["L"]
    summ = item1_summary(W, C, L)

    # top-20 harmonic-energy cycles
    order = np.argsort(-np.abs(C))[:20]
    top20 = [{"rank": int(r + 1), "cycle_len": int(L[i]),
              "circulation": float(C[i]), "circ_over_2pi": float(C[i] / TWO_PI),
              "winding": float(W[i]), "winding_number": int(round(W[i] / TWO_PI))}
             for r, i in enumerate(order)]
    summ_top20 = item1_summary(W[order], C[order], L[order])

    # significant harmonic support restriction: cycles whose edges carry
    # above-median harmonic energy density
    he = real["w"] * real["harm"] ** 2
    thr = float(np.quantile(he, 0.99))
    sig_edges = set(np.flatnonzero(he >= thr).tolist())
    sig_idx = [n for n, (_, signed) in enumerate(real["cycles"])
               if any(e in sig_edges for e, _ in signed)]
    sig_idx = np.array(sig_idx, dtype=int)
    summ_sig = item1_summary(W[sig_idx], C[sig_idx], L[sig_idx]) if len(sig_idx) else None

    out = {
        "construction": {"graph": "knn", "k": args.k, "graph_seed": args.graph_seed,
                         "flow": "Construction A1", "embedding":
                         "zscore -> PCA top2 -> RMS-1 scale -> stereographic_lift"},
        "hodge": {kk: real["res"][kk] for kk in
                  ("N", "n_edges", "n_triangles", "rho_grad", "rho_curl", "rho_harm")},
        "betti": real["res"].get("betti"),
        "orthogonality": real["res"]["orthogonality"],
        "pc12_of_zscored_matrix": real["pc12"],
        "embedding_theta_range": [float(real["theta"].min()), float(real["theta"].max())],
        "embedding_phi_range": [float(real["phi"].min()), float(real["phi"].max())],
        "n_chords_beta1": real["n_chords"],
        "all_cycles": summ,
        "top20_harmonic_energy_cycles": summ_top20,
        "top20_table": top20,
        "high_harmonic_support_cycles": {
            "edge_energy_quantile": 0.99,
            "n_significant_edges": int(len(sig_edges)),
            "n_cycles_touching": int(len(sig_idx)),
            "summary": summ_sig,
        },
    }

    # -------- null: curveball matrices, full recompute
    log(f"[T1] running {args.t1_nulls} curveball nulls (full recompute each)")
    rng = np.random.default_rng(args.seed)
    keys = ["circ_frac_rayleigh_Z", "circ_mean_dist_int", "corr_absC_absW_r",
            "abs_circ_mean", "abs_winding_mean", "rho_harm", "n_cycles"]
    nullvals = {kk: [] for kk in keys}
    for b in range(args.t1_nulls):
        t1 = time.time()
        Mb = cc.null_curveball(M, rng)
        gseed = int(rng.integers(1, 2 ** 31 - 1))
        try:
            r = item1_once(Mb, gseed, k=args.k, compute_betti=False, rng=rng)
        except Exception as exc:  # noqa: BLE001
            log(f"[T1][null {b}] FAILED: {exc!r}")
            continue
        s = item1_summary(r["W"], r["C"], r["L"])
        nullvals["circ_frac_rayleigh_Z"].append(s["circulation"]["frac_rayleigh"]["Z"])
        nullvals["circ_mean_dist_int"].append(s["circulation"]["mean_dist_to_integer_multiple_of_2pi"])
        rr = s["corr_absC_absW_pearson"]["r"]
        nullvals["corr_absC_absW_r"].append(rr if rr is not None else float("nan"))
        nullvals["abs_circ_mean"].append(s["circulation"]["abs_mean"])
        nullvals["abs_winding_mean"].append(s["winding"]["abs_mean"])
        nullvals["rho_harm"].append(r["res"]["rho_harm"])
        nullvals["n_cycles"].append(s["n_cycles"])
        log(f"[T1][null {b+1}/{args.t1_nulls}] {time.time()-t1:.1f}s "
            f"Z={nullvals['circ_frac_rayleigh_Z'][-1]:.2f} r={rr}")

    realvals = {
        "circ_frac_rayleigh_Z": summ["circulation"]["frac_rayleigh"]["Z"],
        "circ_mean_dist_int": summ["circulation"]["mean_dist_to_integer_multiple_of_2pi"],
        "corr_absC_absW_r": summ["corr_absC_absW_pearson"]["r"],
        "abs_circ_mean": summ["circulation"]["abs_mean"],
        "abs_winding_mean": summ["winding"]["abs_mean"],
        "rho_harm": real["res"]["rho_harm"],
        "n_cycles": summ["n_cycles"],
    }
    out["null_curveball"] = {"n_draws": args.t1_nulls,
                             "stats": {kk: null_compare(realvals[kk], nullvals[kk])
                                       for kk in keys}}
    return out


def null_compare(real, nulls):
    a = np.asarray([v for v in nulls if v is not None and np.isfinite(v)], dtype=float)
    if a.size == 0 or real is None:
        return {"real": real, "n": int(a.size), "note": "no usable null draws"}
    mu = float(a.mean()); sd = float(a.std(ddof=1)) if a.size > 1 else 0.0
    z = float((real - mu) / sd) if sd > 1e-15 else None
    # two-sided empirical p with +1 correction
    p = float((np.sum(np.abs(a - mu) >= abs(real - mu)) + 1) / (a.size + 1))
    return {"real": float(real), "null_mean": mu, "null_sd": sd, "z": z,
            "p_two_sided_empirical": p, "n": int(a.size),
            "null_min": float(a.min()), "null_max": float(a.max())}


# ---------------------------------------------------------------- ITEM 2

def lattice_by_pc1(Z):
    """Return (theta_i, phi_i, xyz_i, rank) with row i placed at lattice point rank[i]."""
    n = Z.shape[0]
    zc = Z - Z.mean(0)
    u, s, vt = np.linalg.svd(zc, full_matrices=False)
    t_raw = (u[:, 0] * s[0])
    rank = np.argsort(np.argsort(t_raw))
    xyz, theta, phi = cc.fibonacci_sphere(n)
    return theta[rank], phi[rank], xyz[rank], rank, t_raw, s


def stats_for_assignment(Z, xyz_l, theta_l, phi_l, wgt):
    """Three azimuthal statistics for a given lattice assignment."""
    # (1) weighted Y33 probe
    y33 = cc.y33_probe(theta_l, phi_l)
    wsum = float(np.sum(np.abs(wgt)))
    probe = float(np.sum(wgt * y33) / wsum) if wsum > 0 else 0.0
    # (2) Parseval Y33 energy share of the ridge SH fit of the 9 z-scored cols
    B = cc.real_sh_basis(xyz_l)
    A = B.T @ B + cc.RIDGE_LAMBDA * np.eye(cc.SH_NFUNCS)
    Cf = np.linalg.solve(A, B.T @ Z)
    en = np.sum(Cf ** 2, axis=1)
    share = float(en[15] / en.sum()) if en.sum() > 0 else 0.0
    share_m3 = float((en[9] + en[15]) / en.sum()) if en.sum() > 0 else 0.0
    # (3) azimuthal power at m=3
    num = np.abs(np.sum(wgt * np.exp(3j * phi_l))) ** 2
    den = float(np.sum(wgt ** 2))
    p3 = float(num / den) if den > 0 else 0.0
    return {"y33_probe_weighted_mean": probe,
            "y33_parseval_energy_share": share,
            "m3_parseval_energy_share_both_signs": share_m3,
            "P3_azimuthal_power": p3}


def run_item2(name, Z, wgt, wgt_name, nperm, seed, log):
    n = Z.shape[0]
    theta_l, phi_l, xyz_l, rank, t_raw, sv = lattice_by_pc1(Z)
    real = stats_for_assignment(Z, xyz_l, theta_l, phi_l, wgt)
    log(f"[T2:{name}] N={n} real: {real}")
    rng = np.random.default_rng(seed)
    xyz0, theta0, phi0 = cc.fibonacci_sphere(n)
    keys = list(real.keys())
    nulls = {kk: np.empty(nperm) for kk in keys}
    for b in range(nperm):
        perm = rng.permutation(n)      # row i -> lattice point perm[i]
        s = stats_for_assignment(Z, xyz0[perm], theta0[perm], phi0[perm], wgt)
        for kk in keys:
            nulls[kk][b] = s[kk]
    out = {"N": int(n), "n_permutations": int(nperm), "weight": wgt_name,
           "pc1_var_share": float(sv[0] ** 2 / (sv ** 2).sum()),
           "pc12_var_share": float((sv[:2] ** 2).sum() / (sv ** 2).sum()),
           "stats": {}}
    for kk in keys:
        out["stats"][kk] = null_compare(real[kk], nulls[kk].tolist())
        out["stats"][kk]["p_two_sided_abs"] = float(
            (np.sum(np.abs(nulls[kk]) >= abs(real[kk])) + 1) / (nperm + 1))
    return out


def load_gwtc(path):
    import csv
    with open(path) as fh:
        rd = csv.reader(fh)
        header = next(rd)
        rows = [[float(v) for v in r] for r in rd if r]
    X = np.array(rows, dtype=float)
    j = header.index("luminosity_distance")
    X[:, j] = np.log(X[:, j])
    return X, header, j


# ---------------------------------------------------------------- main

def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out-json", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "T1-results.json"))
    ap.add_argument("--k", type=int, default=8)
    ap.add_argument("--graph-seed", type=int, default=20260812,
                    help="seed for the real kNN graph (matches B-hodge-yubios.json)")
    ap.add_argument("--seed", type=int, default=20260812, help="master seed for nulls")
    ap.add_argument("--t1-nulls", type=int, default=50)
    ap.add_argument("--t2-perms", type=int, default=500)
    ap.add_argument("--skip-item1", action="store_true")
    ap.add_argument("--skip-item2", action="store_true")
    a = ap.parse_args(argv)

    logs = []

    def log(msg):
        print(msg, flush=True)
        logs.append(msg)

    t_start = time.time()
    result = {"generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
              "python": sys.version.split()[0],
              "numpy": np.__version__,
              "seeds": {"master_seed": a.seed, "graph_seed": a.graph_seed,
                        "t1_null_draws": a.t1_nulls, "t2_permutations": a.t2_perms},
              "inputs": {"master": MASTER, "gwtc": GWTC,
                         "create_corpus": CORPUS_PY, "hodge": HODGE_PY}}

    if not a.skip_item1:
        result["item1_p_h3_clause_ii"] = run_item1(a, log)

    if not a.skip_item2:
        M, meta, prim = hd.load_coverage_json(MASTER)
        Zm = zscore(M)
        cov = M.sum(1).astype(float)
        item2 = {}
        item2["master_coverage_weight"] = run_item2(
            "master/coverage_sum", Zm, cov, "coverage_sum (row mass, 0..9)",
            a.t2_perms, a.seed, log)
        # PC1-score weighting
        _, _, _, _, t_raw_m, _ = lattice_by_pc1(Zm)
        item2["master_pc1_weight"] = run_item2(
            "master/pc1", Zm, t_raw_m, "PC1 score (signed)", a.t2_perms, a.seed + 1, log)

        X, header, j = load_gwtc(GWTC)
        Zg = zscore(X)
        _, _, _, _, t_raw_g, _ = lattice_by_pc1(Zg)
        snr = X[:, header.index("network_matched_filter_snr")]
        item2["gwtc_snr_weight"] = run_item2(
            "gwtc/snr", Zg, snr, "network_matched_filter_snr", a.t2_perms, a.seed + 2, log)
        item2["gwtc_pc1_weight"] = run_item2(
            "gwtc/pc1", Zg, t_raw_g, "PC1 score (signed)", a.t2_perms, a.seed + 3, log)
        item2["gwtc_columns"] = header
        item2["gwtc_log_column"] = header[j]
        result["item2_ordering_permutation_null"] = item2

    result["elapsed_seconds"] = time.time() - t_start
    result["log"] = logs
    with open(a.out_json, "w") as fh:
        json.dump(result, fh, indent=2)
    print(f"\nwrote {a.out_json}  ({time.time()-t_start:.1f}s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
