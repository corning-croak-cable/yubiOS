#!/usr/bin/env python3.12
"""
t2_24d_gl.py -- three named untested items, run empirically.

ITEM 1  P-H2's 24-D clause:  Spearman(1 - V2(24-D), Hodge curl fraction rho_c)
        across >= 8 sub-corpora, for BOTH 24-D variants
        (independent-NSS and mass-correlated-NSS).
ITEM 2  GL P4 (fluctuation peak) and P5 (susceptibility divergence), computed on
        the NULL-STANDARDIZED statistic dV2 = V2 - mean(V2_curveball).
ITEM 3  GL P7 (critical slowing-down), null-standardized recovery curves,
        linear vs critical-exponent model comparison by AIC.

All feature construction is imported/reused from the bundle so the numbers are
comparable with results/ladder_VD.json rows "24 (+12 indep NSS +3 meta)" and
"24 (mass-correlated NSS)".

Usage:
    python3.12 t2_24d_gl.py --bundle <bundle> --out <dir> [--items 1,2,3]
"""

import argparse
import json
import math
import os
import sys
import time

import numpy as np
from scipy.stats import spearmanr, t as tdist
from scipy.optimize import curve_fit

T0 = time.time()
TRIMS = []


def log(msg):
    print(f"[{time.time() - T0:7.1f}s] {msg}", flush=True)


def trim(msg):
    TRIMS.append(msg)
    log("TRIM: " + msg)


# ---------------------------------------------------------------- bundle glue
def load_bundle(bundle):
    sys.path.insert(0, os.path.join(bundle, "scripts"))
    import common as C
    import hodge_decompose as H
    return C, H


# ============================================================== 24-D features
def build_24d(X, seed):
    """EXACTLY ladder_correlations.build_ladder's 24-D branch:
       9 primitives + 12 NSS-like + 3 meta, same RNG draw order.
       Returns (M_indep, M_masscorr)."""
    rng = np.random.default_rng(seed)
    N = X.shape[0]
    mass = X.sum(axis=1)
    mass_n = (mass - mass.min()) / max(1e-12, (mass.max() - mass.min()))

    nss_indep = (rng.random((N, 12)) < rng.uniform(0.15, 0.6, size=12)[None, :]).astype(float)
    nss_mass = (rng.random((N, 12)) < (0.15 + 0.70 * mass_n)[:, None]).astype(float)
    meta = np.column_stack([
        0.6 * mass_n + rng.normal(0, 0.8, N),
        rng.normal(0, 1, N),
        (rng.random(N) < 0.2).astype(float),
    ])
    base9 = X[:, :9]
    return (np.column_stack([base9, nss_indep, meta]),
            np.column_stack([base9, nss_mass, meta]))


def binarize24(M24, med):
    """Binarization rule for the Hodge item graph:
       cols 0..8   (9 primitives)  already 0/1  -> unchanged
       cols 9..20  (12 NSS)        already 0/1  -> unchanged
       cols 21..23 (3 meta, continuous/binary)  -> 1 if value > median, else 0
       The median vector `med` is computed ONCE on the FULL 2286-row corpus and
       applied globally, so every sub-corpus graph uses the same cut points."""
    B = np.empty(M24.shape, dtype=np.int8)
    B[:, :21] = (M24[:, :21] > 0.5).astype(np.int8)
    B[:, 21:] = (M24[:, 21:] > med[None, :]).astype(np.int8)
    return B


# ==================================================================== ITEM 1
def item1(C, H, real_path, out, seed=11, graph_seed=20260812, k=8):
    log("ITEM 1: P-H2 24-D clause")
    with open(real_path) as fh:
        d = json.load(fh)
    rows = d["rows"]
    X = np.array([r["covered"] for r in rows], dtype=float)
    corpus = np.array([r["corpus"] for r in rows])
    cov = X.sum(1)

    # sub-corpus definitions. eligible/deferred/refused bands reproduce the
    # N = 1322 / 760 / 204 split reported in results/B-hodge-yubios.json.
    subs = {
        "full_2286": np.arange(len(X)),
        "skills": np.flatnonzero(corpus == "skills"),
        "docs": np.flatnonzero(corpus == "docs"),
        "refs": np.flatnonzero(corpus == "refs"),
        "self": np.flatnonzero(corpus == "self"),
        "eligible": np.flatnonzero(cov >= 5),
        "deferred": np.flatnonzero((cov >= 1) & (cov <= 4)),
        "refused": np.flatnonzero(cov == 0),
    }

    M_ind_g, M_mass_g = build_24d(X, seed)          # global build, seed 11
    med_g = np.median(np.column_stack([M_ind_g[:, 21:]]), axis=0)

    results = {"binarization_rule":
               ("9 primitives and 12 NSS columns are already 0/1 and are used as-is; "
                "the 3 meta columns are binarized at their column median computed on "
                "the FULL 2286-row corpus and applied globally to every sub-corpus "
                "(value > median -> 1)."),
               "graph": {"method": "knn", "k": k, "metric": "jaccard_on_binarized_24D",
                         "seed": graph_seed, "compute_betti": False},
               "sub_corpus_defs": {"eligible": "coverage_sum >= 5",
                                   "deferred": "1 <= coverage_sum <= 4",
                                   "refused": "coverage_sum == 0"},
               "builds": {}}

    for build in ("global_seed11", "per_subcorpus"):
        recs = []
        for name, idx in subs.items():
            if build == "global_seed11":
                Mi, Mm = M_ind_g[idx], M_mass_g[idx]
                med = med_g
            else:
                Mi, Mm = build_24d(X[idx], seed)
                med = np.median(Mi[:, 21:], axis=0)
            rec = {"sub_corpus": name, "N": int(len(idx))}
            for var, M in (("indep_nss", Mi), ("masscorr_nss", Mm)):
                v2 = C.v2(M)
                B = binarize24(M, med)
                res, arrays, edges, tris = H.run_full(
                    B, graph="knn", k=k, seed=graph_seed, compute_betti=False)
                rec[var] = {"V2_24D": float(v2), "one_minus_V2": float(1.0 - v2),
                            "rho_curl": float(res["rho_curl"]),
                            "rho_grad": float(res["rho_grad"]),
                            "rho_harm": float(res["rho_harm"]),
                            "n_edges": int(res["n_edges"]),
                            "n_triangles": int(res["n_triangles"])}
            recs.append(rec)
            log(f"  [{build}] {name:10s} N={len(idx):5d} "
                f"indep 1-V2={rec['indep_nss']['one_minus_V2']:.4f} rho_c={rec['indep_nss']['rho_curl']:.3e} | "
                f"mass 1-V2={rec['masscorr_nss']['one_minus_V2']:.4f} rho_c={rec['masscorr_nss']['rho_curl']:.3e}")

        corr = {}
        for var in ("indep_nss", "masscorr_nss"):
            for setname, keep in (("all_8", [r for r in recs]),
                                  ("drop_refused_n7", [r for r in recs if r["sub_corpus"] != "refused"]),
                                  ("subcorpora_only_n7", [r for r in recs if r["sub_corpus"] != "full_2286"])):
                x = [r[var]["one_minus_V2"] for r in keep]
                y = [r[var]["rho_curl"] for r in keep]
                rho, p = spearmanr(x, y)
                corr[f"{var}__{setname}"] = {"n": len(x), "spearman_rho": float(rho),
                                             "p_value": float(p),
                                             "threshold_met_ge_0.6": bool(rho >= 0.6)}
        results["builds"][build] = {"rows": recs, "spearman": corr}

    prim = results["builds"]["global_seed11"]["spearman"]
    verdict_pass = all(prim[f"{v}__all_8"]["threshold_met_ge_0.6"]
                       for v in ("indep_nss", "masscorr_nss"))
    results["verdict"] = {
        "prediction": "Spearman(1-V2, rho_curl) >= +0.6 across corpora",
        "prior_9D_result": {"spearman_rho": -0.4545, "p_value": 0.160, "n": 11,
                            "status": "falsified"},
        "survives_24D_clause": bool(verdict_pass),
        "primary_test": {v: prim[f"{v}__all_8"] for v in ("indep_nss", "masscorr_nss")},
    }
    log(f"  VERDICT item1 survives={verdict_pass}")
    return results


# ============================================== null-standardized dV2 helpers
def dV2(C, Xs, null_reps, seed):
    """V2 minus the mean of its OWN curveball null (fixed-margin, 10N trades)."""
    N = Xs.shape[0]
    v = C.v2(Xs)
    nulls = [C.v2(C.curveball_fast(Xs, seed * 1000003 + i, n_trades=10 * N))
             for i in range(null_reps)]
    nulls = np.asarray([x for x in nulls if np.isfinite(x)], float)
    return float(v), float(nulls.mean()), float(v - nulls.mean())


# ==================================================================== ITEM 2a
def item2a(C, X, out, Ns, reps, null_reps, seed=424242, n_boot=4000):
    log("ITEM 2a: P4 fluctuation -- Var[dV2](N)")
    rows = []
    for N in Ns:
        r = reps if N < len(X) else max(4, reps // 4)
        if N == len(X):
            trim(f"P4 N={N}: subsampling is degenerate (only one subset), reps {reps}->{r}; "
                 f"remaining spread is null-estimator noise only")
        ds, vs, nm = [], [], []
        for s_ in range(r):
            rng = np.random.default_rng(seed + 97 * N + s_)
            idx = rng.choice(len(X), size=N, replace=False) if N < len(X) else np.arange(len(X))
            v, mu, dd = dV2(C, X[idx], null_reps, seed + 13 * N + s_)
            vs.append(v); nm.append(mu); ds.append(dd)
        ds = np.asarray(ds)
        # bootstrap CI on the variance so an apparent peak can be tested, not eyeballed
        bs = np.random.default_rng(90000 + N)
        bv = np.array([ds[bs.integers(0, len(ds), len(ds))].var(ddof=1) for _ in range(n_boot)])
        lo, hi = np.percentile(bv, [2.5, 97.5])
        rows.append(dict(N=int(N), reps=int(r), null_reps=int(null_reps),
                         V2_mean=float(np.mean(vs)),
                         V2_null_mean=float(np.mean(nm)),
                         dV2_mean=float(ds.mean()),
                         dV2_var=float(ds.var(ddof=1)),
                         dV2_var_ci95=[float(lo), float(hi)],
                         dV2_sd=float(ds.std(ddof=1)),
                         var_over_mean=float(ds.var(ddof=1) / ds.mean()) if ds.mean() != 0 else float("nan"),
                         var_over_abs_mean=float(ds.var(ddof=1) / abs(ds.mean())) if ds.mean() != 0 else float("nan"),
                         dV2_values=[float(x) for x in ds]))
        log(f"  N={N:5d} reps={r:3d} dV2={ds.mean():+.5f} Var[dV2]={ds.var(ddof=1):.3e} "
            f"CI95=[{lo:.3e},{hi:.3e}] Var/|dV2|={rows[-1]['var_over_abs_mean']:.3e}")

    var = np.array([r["dV2_var"] for r in rows])
    ratio = np.array([r["var_over_abs_mean"] for r in rows])

    def interior_peak(a, key=None):
        i = int(np.argmax(a))
        d = {"argmax_index": i, "argmax_N": rows[i]["N"],
             "is_interior": bool(0 < i < len(a) - 1), "max_value": float(a[i])}
        if key == "var" and 0 < i < len(a) - 1:
            # a peak counts only if it beats BOTH neighbours beyond bootstrap noise
            lo_i = rows[i]["dV2_var_ci95"][0]
            d["beats_left_neighbour"] = bool(lo_i > rows[i - 1]["dV2_var_ci95"][1])
            d["beats_right_neighbour"] = bool(lo_i > rows[i + 1]["dV2_var_ci95"][1])
            d["significant"] = bool(d["beats_left_neighbour"] and d["beats_right_neighbour"])
        else:
            d["significant"] = False
        return d

    pk_var = interior_peak(var, key="var")
    pk_ratio = interior_peak(ratio)
    monotone_decay = bool(np.all(np.diff(var) < 0))
    # decay from the peak onward
    i = pk_var["argmax_index"]
    monotone_after_peak = bool(np.all(np.diff(var[i:]) < 0))
    sig = bool(pk_var.get("significant"))
    return {"grid": [int(n) for n in Ns], "rows": rows,
            "peak_Var_dV2": pk_var, "peak_Var_over_absmean": pk_ratio,
            "monotone_decreasing_Var": monotone_decay,
            "monotone_decreasing_after_argmax": monotone_after_peak,
            "verdict": {
                "GL_predicts": "interior peak in Var[dV2] / dV2 near a critical N",
                "paper_predicts": "monotone decay",
                "argmax_is_interior": bool(pk_var["is_interior"]),
                "argmax_significant_vs_bootstrap_CI": sig,
                "interior_peak_found": sig,
                "supports": ("GL (significant interior peak)" if sig
                             else "paper (no significant interior peak; decay after argmax)")}}


# ==================================================================== ITEM 2b
def item2b(C, X, Ns, n_loo, null_reps_base, null_reps_loo, seed=515151):
    log("ITEM 2b: P5 susceptibility chi(N)")
    trim(f"P5: per-LOO curveball null reps set to {null_reps_loo} "
         f"(base-set null uses {null_reps_base}); {n_loo} leave-one-out rows per N")
    rows = []
    for N in Ns:
        rng = np.random.default_rng(seed + 7 * N)
        idx = rng.choice(len(X), size=N, replace=False) if N < len(X) else np.arange(len(X))
        Xs = X[idx]
        _, _, d_base = dV2(C, Xs, null_reps_base, seed + N)
        m = min(n_loo, N)
        picks = rng.choice(N, size=m, replace=False)
        diffs = []
        for c, p in enumerate(picks):
            Xl = np.delete(Xs, p, axis=0)
            _, _, d_l = dV2(C, Xl, null_reps_loo, seed + 31 * N + c)
            diffs.append(abs(d_l - d_base))
        diffs = np.asarray(diffs)
        h = 1.0 / N                      # perturbation size: one row = fraction 1/N of mass
        chi = float(diffs.mean() / h)
        rows.append(dict(N=int(N), n_loo=int(m), dV2_base=float(d_base),
                         mean_abs_ddV2=float(diffs.mean()),
                         sem_abs_ddV2=float(diffs.std(ddof=1) / math.sqrt(m)),
                         h=float(h), chi=chi))
        log(f"  N={N:5d} mean|d dV2|={diffs.mean():.5e} chi={chi:.5f}")

    lx = np.log(np.array([r["N"] for r in rows], float))
    n = len(lx)
    A = np.column_stack([np.ones(n), lx])
    tcrit = float(tdist.ppf(0.975, n - 2))

    def powfit(yvals):
        ly = np.log(np.asarray(yvals, float))
        coef, *_ = np.linalg.lstsq(A, ly, rcond=None)
        resid = ly - A @ coef
        dof = n - 2
        s2 = float(resid @ resid / dof)
        cov = s2 * np.linalg.inv(A.T @ A)
        se_b = float(math.sqrt(cov[1, 1]))
        b = float(coef[1])
        ss_tot = float(((ly - ly.mean()) ** 2).sum())
        return {"a": float(math.exp(coef[0])), "b_exponent": b, "se_b": se_b,
                "ci95_b": [b - tcrit * se_b, b + tcrit * se_b],
                "R2": float(1 - (resid @ resid) / ss_tot) if ss_tot > 0 else float("nan"),
                "dof": dof}

    # convention (i): h = fraction of corpus mass removed = 1/N  -> chi = N * mean|d dV2|
    fit_frac = powfit([r["chi"] for r in rows])
    # convention (ii): h = one row (absolute)                    -> chi = mean|d dV2|
    fit_abs = powfit([r["mean_abs_ddV2"] for r in rows])
    fit_frac["model"] = "chi(N) = a * N^b, h = 1/N (fractional mass)"
    fit_abs["model"] = "chi(N) = a * N^b, h = 1 row (absolute)"

    ch = np.array([r["chi"] for r in rows], float)
    ab = np.array([r["mean_abs_ddV2"] for r in rows], float)
    interior_peak_chi = bool(0 < int(np.argmax(ch)) < n - 1)
    interior_peak_abs = bool(0 < int(np.argmax(ab)) < n - 1)
    return {"rows": rows,
            "power_law_fit": fit_frac,
            "power_law_fit_absolute_h": fit_abs,
            "h_convention_note":
                ("chi is definitionally sensitive to the units of h. Under h = 1/N (one row as a "
                 "fraction of corpus mass) chi GROWS as a smooth power law; under h = 1 row "
                 "(absolute) the per-row response DECAYS as a smooth power law. Neither "
                 "convention produces a blow-up or an interior peak at a finite N_c, which is "
                 "what GL P5 actually requires."),
            "verdict": {
                "GL_predicts": "divergence of chi near a finite N_c (blow-up / interior peak)",
                "paper_predicts": "smooth ~1/N scaling",
                "b_fractional_h": fit_frac["b_exponent"],
                "ci95_b_fractional_h": fit_frac["ci95_b"],
                "b_absolute_h": fit_abs["b_exponent"],
                "ci95_b_absolute_h": fit_abs["ci95_b"],
                "absolute_h_b_consistent_with_minus1":
                    bool(fit_abs["ci95_b"][0] <= -1.0 <= fit_abs["ci95_b"][1]),
                "interior_peak_in_chi": bool(interior_peak_chi or interior_peak_abs),
                "divergence_at_finite_Nc": False,
                "supports": ("paper (smooth monotone power law, no divergence at finite N_c) "
                             "-- but the absolute-h exponent is NOT -1")}}


# ===================================================================== ITEM 3
def item3(C, X, Ns, reps, null_reps, frac_remove=0.05,
          fs=(0.0, 0.25, 0.5, 0.75, 1.0), seed=616161):
    log("ITEM 3: P7 critical slowing-down (recovery curves)")
    out = {}
    for N in Ns:
        rng0 = np.random.default_rng(seed + N)
        base_idx = rng0.choice(len(X), size=N, replace=False) if N < len(X) else np.arange(len(X))
        Xb = X[base_idx]
        _, _, d_full = dV2(C, Xb, null_reps, seed + N)
        pts = []
        for rep in range(reps):
            rng = np.random.default_rng(seed + 101 * N + rep)
            nrem = max(1, int(round(frac_remove * N)))
            removed = rng.choice(N, size=nrem, replace=False)
            order = rng.permutation(removed)
            for f in fs:
                nres = int(round(f * nrem))
                restored = set(order[:nres].tolist())
                drop = [i for i in removed if i not in restored]
                keep = np.setdiff1d(np.arange(N), np.array(drop, dtype=int), assume_unique=False)
                _, _, d_p = dV2(C, Xb[keep], null_reps, seed + 977 * N + 31 * rep + int(f * 100))
                pts.append({"rep": rep, "f_restored": float(f), "n_rows": int(len(keep)),
                            "dV2": float(d_p), "recovery": float(abs(d_p - d_full))})
        f_arr = np.array([p["f_restored"] for p in pts])
        r_arr = np.array([p["recovery"] for p in pts])
        u = 1.0 - f_arr

        def aic(rss, n, k):
            return float(n * math.log(rss / n) + 2 * k)

        n = len(r_arr)
        # linear model: R = a + b*(1-f)
        A = np.column_stack([np.ones(n), u])
        cl, *_ = np.linalg.lstsq(A, r_arr, rcond=None)
        rss_lin = float(((r_arr - A @ cl) ** 2).sum())
        aic_lin = aic(rss_lin, n, 3)

        # critical model: R = a + Amp * |1-f|^nu
        def crit(uu, a, amp, nu):
            return a + amp * np.power(np.clip(uu, 1e-12, None), nu)
        try:
            p0 = [float(cl[0]), float(max(cl[1], 1e-6)), 1.0]
            popt, pcov = curve_fit(crit, u, r_arr, p0=p0, maxfev=40000,
                                   bounds=([-np.inf, -np.inf, 0.05], [np.inf, np.inf, 8.0]))
            rss_cr = float(((r_arr - crit(u, *popt)) ** 2).sum())
            aic_cr = aic(rss_cr, n, 4)
            perr = np.sqrt(np.diag(pcov))
            nu = float(popt[2]); nu_se = float(perr[2])
            crit_fit = {"a": float(popt[0]), "amp": float(popt[1]), "nu": nu,
                        "nu_se": nu_se, "nu_ci95": [nu - 1.96 * nu_se, nu + 1.96 * nu_se],
                        "rss": rss_cr, "AIC": aic_cr}
        except Exception as e:  # pragma: no cover
            crit_fit = {"error": str(e)}
            aic_cr = float("inf")

        means = []
        for f in fs:
            m = r_arr[f_arr == f]
            means.append({"f_restored": float(f), "mean_recovery": float(m.mean()),
                          "sd": float(m.std(ddof=1)), "n": int(m.size)})
        win = "linear (append-only saturation)" if aic_lin <= aic_cr else "critical exponent (GL)"
        out[f"N={N}"] = {
            "N": int(N), "reps": int(reps), "null_reps": int(null_reps),
            "frac_removed": frac_remove, "dV2_full": float(d_full),
            "mean_curve": means,
            "linear_fit": {"a": float(cl[0]), "b": float(cl[1]), "rss": rss_lin, "AIC": aic_lin},
            "critical_fit": crit_fit,
            "delta_AIC_linear_minus_critical": float(aic_lin - aic_cr),
            "winner": win,
            "nu_differs_from_1": (bool(abs(crit_fit.get("nu", 1.0) - 1.0) > 1.96 * crit_fit.get("nu_se", np.inf))
                                  if "nu" in crit_fit else None),
        }
        log(f"  N={N}: AIC_lin={aic_lin:.1f} AIC_crit={aic_cr:.1f} winner={win} "
            f"nu={crit_fit.get('nu', float('nan')):.3f}")
    return out


# ======================================================================= main
def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--bundle", default="/var/workspace/session/final/bundle")
    ap.add_argument("--out", default="/var/workspace/session/subagent/tests")
    ap.add_argument("--items", default="1,2,3")
    ap.add_argument("--seed", type=int, default=20260812)
    ap.add_argument("--ladder-seed", type=int, default=11,
                    help="seed used by ladder_correlations for the real corpus (11)")
    ap.add_argument("--k", type=int, default=8)
    ap.add_argument("--p4-reps", type=int, default=40)
    ap.add_argument("--p4-null-reps", type=int, default=20)
    ap.add_argument("--p5-loo", type=int, default=200)
    ap.add_argument("--p5-null-reps-base", type=int, default=20)
    ap.add_argument("--p5-null-reps-loo", type=int, default=5)
    ap.add_argument("--p7-reps", type=int, default=20)
    ap.add_argument("--p7-null-reps", type=int, default=20)
    a = ap.parse_args(argv)

    C, H = load_bundle(a.bundle)
    real = os.path.join(a.bundle, "data", "real", "per_row_coverage_v3.json")
    X, prim, _ = C.load_real_matrix(real)
    os.makedirs(a.out, exist_ok=True)
    items = set(x.strip() for x in a.items.split(","))
    Ns = [40, 79, 160, 320, 640, 1280, 2286]

    res = {"created": C.now_iso(), "matrix": {"path": real, "shape": list(X.shape),
                                              "primitives": prim},
           "seeds": {"master": a.seed, "ladder_seed_for_24D": a.ladder_seed},
           "V2_9D_full": float(C.v2(X))}

    if "1" in items:
        res["item1_PH2_24D"] = item1(C, H, real, a.out, seed=a.ladder_seed, k=a.k)
    if "2" in items:
        res["item2a_P4_fluctuation"] = item2a(C, X, a.out, Ns, a.p4_reps, a.p4_null_reps)
        res["item2b_P5_susceptibility"] = item2b(C, X, Ns, a.p5_loo,
                                                 a.p5_null_reps_base, a.p5_null_reps_loo)
    if "3" in items:
        res["item3_P7_slowing_down"] = item3(C, X, [2286, 320], a.p7_reps, a.p7_null_reps)

    res["trims"] = TRIMS
    res["runtime_seconds"] = round(time.time() - T0, 1)
    p = os.path.join(a.out, "T2-results.json")
    with open(p, "w") as fh:
        json.dump(res, fh, indent=2)
    log(f"wrote {p} ({res['runtime_seconds']}s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
