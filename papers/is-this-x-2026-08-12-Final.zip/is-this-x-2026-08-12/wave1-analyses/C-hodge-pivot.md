# C — Combinatorial Hodge Theory (HodgeRank) as a Pivot for the Latent-Curve / Ginzburg–Landau Framework

**Date:** 2026-08-12
**Scope:** evaluation of Jiang–Lim–Yao–Ye (Math. Program. 127(1):203–244, 2011; arXiv:0811.1067) as an addition to the S²-latent-curve corpus framework and its Ginzburg–Landau (GL) reading.
**Verdict (short):** **Pivot HELPS — as an *additive* second measurement channel, not as a replacement for the S² curve.** It uniquely supplies (i) a *rigorous discrete phase winding* (harmonic 1-cocycle) that the GL note explicitly demands and cannot currently produce, (ii) a **PCA-independent** disorder scalar (curl fraction) with an orthogonal-decomposition guarantee, and (iii) a principled cross-regime comparator (eligible / deferred / refused) via a single least-squares potential. It does **not** rescue κ, does **not** give a temperature, and imports a serious new confound: harmonic mass is a property of the *graph you built*, not only of the corpus.

---

## 1. The actual mathematics (Jiang–Lim–Yao–Ye)

### 1.1 Objects

Let $V=\{1,\dots,n\}$ be alternatives (here: corpus items), $\Lambda=\{1,\dots,m\}$ voters (here: primitives / contexts / scorers). Each voter $\alpha$ contributes a skew-symmetric pairwise matrix and an indicator weight

$$
Y^{\alpha}_{ij}=-Y^{\alpha}_{ji},\qquad
w^{\alpha}_{ij}=\mathbb{1}[\alpha \text{ compared } \{i,j\}].
$$

Aggregate:

$$
w_{ij}=\sum_{\alpha} w^{\alpha}_{ij},\qquad
\bar Y_{ij}=\frac{\sum_\alpha w^\alpha_{ij}Y^\alpha_{ij}}{\sum_\alpha w^\alpha_{ij}} .
$$

The **pairwise comparison graph** is $G=(V,E)$, $E=\{\{i,j\}: w_{ij}>0\}$. Its **3-clique complex** is $K_G^3=(V,E,T(E))$ with

$$
T(E)=\bigl\{\{i,j,k\}\in\tbinom{V}{3}\;:\;\{i,j\},\{j,k\},\{k,i\}\in E\bigr\}.
$$

Cochain spaces: $C^0$ = scores $s:V\to\mathbb R$; $C^1$ = edge flows (skew-symmetric $X$ supported on $E$); $C^2$ = triangular flows (alternating $\Phi$ supported on $T$).

### 1.2 Operators (JLYY Defs. 2.1, 2.2, 4.1–4.5)

$$
(\operatorname{grad} s)(i,j)=(\delta_0 s)(i,j)=s_j-s_i,
$$
$$
(\operatorname{curl} X)(i,j,k)=(\delta_1 X)(i,j,k)=X_{ij}+X_{jk}+X_{ki},
$$
$$
(\operatorname{div} X)(i)=-(\delta_0^{*}X)(i)=\sum_{j:\{i,j\}\in E} w_{ij}X_{ij},
$$

with the weighted inner product on $C^1$: $\langle X,Y\rangle_w=\sum_{\{i,j\}\in E} w_{ij}X_{ij}Y_{ij}$ and unweighted products on $C^0,C^2$.

General coboundary: $(\delta_k f)(i_0,\dots,i_{k+1})=\sum_{j=0}^{k+1}(-1)^j f(i_0,\dots,\hat i_j,\dots,i_{k+1})$, with **closedness** $\delta_{k+1}\delta_k=0$, i.e.

$$
\operatorname{curl}\circ\operatorname{grad}=0,\qquad \operatorname{div}\circ\operatorname{curl}^{*}=0 .
$$

Combinatorial Laplacians:

$$
\Delta_k=\delta_k^{*}\delta_k+\delta_{k-1}\delta_{k-1}^{*},\qquad
\Delta_0=\operatorname{div}\operatorname{grad},\qquad
\Delta_1=\operatorname{curl}^{*}\operatorname{curl}-\operatorname{grad}\operatorname{div}.
$$

$\Delta_1$ is the **graph Helmholtzian**. $\Delta_k\succeq 0$, and (JLYY Lemma 4.6)

$$
\boxed{\;\dim\ker\Delta_k=\beta_k(K)\;}
$$

the $k$-th Betti number of the complex. In particular $\dim\ker\Delta_1=\beta_1$, the number of independent 1-dimensional holes of the clique complex.

### 1.3 The decomposition (Thms. 4.7, 4.8)

$$
C^k(K,\mathbb R)=\operatorname{im}(\delta_{k-1})\;\oplus\;\ker(\Delta_k)\;\oplus\;\operatorname{im}(\delta_k^{*}),
\qquad \ker\Delta_k=\ker\delta_k\cap\ker\delta_{k-1}^{*}.
$$

At $k=1$ (Helmholtz decomposition):

$$
\boxed{\;C^1=\underbrace{\operatorname{im}(\operatorname{grad})}_{\text{gradient / globally consistent}}\;\oplus\;\underbrace{\ker(\Delta_1)}_{\text{harmonic: locally consistent, globally cyclic}}\;\oplus\;\underbrace{\operatorname{im}(\operatorname{curl}^{*})}_{\text{curl: locally cyclic}}\;}
$$

with $\ker\Delta_1=\ker(\operatorname{curl})\cap\ker(\operatorname{div})$. The three summands are **mutually orthogonal in $\langle\cdot,\cdot\rangle_w$** — this is what makes the fractions below a genuine variance budget rather than a heuristic split.

### 1.4 Least-squares interpretation (Thm. 5.1)

$$
\min_{s\in C^0}\|\operatorname{grad} s-\bar Y\|_{2,w}^2
\;\Longleftrightarrow\;
\Delta_0 s=-\operatorname{div}\bar Y,
\qquad s^{*}=-\Delta_0^{\dagger}\operatorname{div}\bar Y ,
$$

where $[\Delta_0]_{ii}=\sum_j w_{ij}$, $[\Delta_0]_{ij}=-w_{ij}$. The residual $R^{*}=\bar Y-\operatorname{grad}s^{*}$ is divergence-free and splits further:

$$
R^{*}=\underbrace{\operatorname{proj}_{\operatorname{im}(\operatorname{curl}^{*})}\bar Y}_{\text{local}}+\underbrace{\operatorname{proj}_{\ker\Delta_1}\bar Y}_{\text{global}},
\qquad
\Phi^{*}=(\operatorname{curl}\operatorname{curl}^{*})^{\dagger}\operatorname{curl}\bar Y ,
$$
$$
\operatorname{proj}_{\operatorname{im}(\operatorname{curl}^{*})}=\operatorname{curl}^{\dagger}\operatorname{curl},\qquad
\operatorname{proj}_{\ker\Delta_1}=I-\Delta_1^{\dagger}\Delta_1 .
$$

On a complete graph with unit weights, $s^{*}_i=-\frac1n\sum_j \bar Y_{ij}$ — exactly **Borda count**; HodgeRank is Borda generalized to incomplete/imbalanced data, computable in polynomial time (contrast Kemeny optimization, NP-hard).

### 1.5 Inconsistency ratios

With $\|\cdot\|=\|\cdot\|_{2,w}$ and orthogonality,

$$
\|\bar Y\|^2=\|\bar Y_{\mathrm{grad}}\|^2+\|\bar Y_{\mathrm{curl}}\|^2+\|\bar Y_{\mathrm{harm}}\|^2 ,
$$
$$
\rho_{\mathrm g}=\frac{\|\bar Y_{\mathrm{grad}}\|^2}{\|\bar Y\|^2},\quad
\rho_{\mathrm c}=\frac{\|\bar Y_{\mathrm{curl}}\|^2}{\|\bar Y\|^2},\quad
\rho_{\mathrm h}=\frac{\|\bar Y_{\mathrm{harm}}\|^2}{\|\bar Y\|^2},\quad
\rho_{\mathrm g}+\rho_{\mathrm c}+\rho_{\mathrm h}=1 .
$$

$\rho_{\mathrm g}$ is a *certificate of reliability* for the induced global ranking; $\rho_{\mathrm c}$ is local (triadic) inconsistency; $\rho_{\mathrm h}$ is global cyclicity, and $\rho_{\mathrm h}=0$ identically whenever $\beta_1(K_G^3)=0$.

### 1.6 Dimension bookkeeping

Let $B_1\in\mathbb R^{|E|\times|V|}$ be the matrix of $\delta_0$ and $B_2\in\mathbb R^{|T|\times|E|}$ that of $\delta_1$. Then

$$
\beta_0=|V|-\operatorname{rank}B_1,\qquad
\boxed{\;\beta_1=|E|-\operatorname{rank}B_1-\operatorname{rank}B_2\;}
$$

and the Euler-characteristic identity for the 2-complex $\chi=|V|-|E|+|T|=\beta_0-\beta_1+\beta_2$ gives a cheap consistency check ($\beta_2=|T|-\operatorname{rank}B_2$ when no 3-simplices are filled). Sanity check run here: a bare hexagon gives $|E|=6$, $\operatorname{rank}B_1=5$, $\operatorname{rank}B_2=0$, $\beta_1=1$ ✓.

---

## 2. Mapping designs: from an $N\times d$ binary coverage matrix to edge flows

Let $M\in\{0,1\}^{N\times d}$ be the primitive-coverage matrix ($d\in\{7,9,16,24,384\}$), $c_i=\sum_a M_{ia}$ the coverage sum, $\mathbf m_i=M_{i:}$.

### Construction A — *item graph, primitives as voters* (the canonical/primary one)

**Voters = primitives.** Primitive $a$ compares $i,j$ iff at least one of them exhibits $a$ within a shared context; the natural JLYY "score difference" pairwise ranking is

$$
Y^{a}_{ij}=M_{ja}-M_{ia}\in\{-1,0,1\},\qquad
w^{a}_{ij}=\mathbb 1[\{i,j\}\in E],
$$
$$
\bar Y_{ij}=\frac1d\sum_{a=1}^{d}(M_{ja}-M_{ia})=\frac{c_j-c_i}{d}.
$$

Note that with *all* primitives voting on *every* pair, $\bar Y$ is exactly a gradient — trivially $\rho_{\mathrm g}=1$. **This is the key design lesson: the flow only carries information when the voter set is restricted per pair.** Two non-degenerate variants:

* **A1 (shared-context restriction).** Let $S_{ij}=\{a: M_{ia}+M_{ja}\ge 1\}$ be the primitives *at stake* for the pair. Then
 $$
 \bar Y^{A1}_{ij}=\frac{1}{|S_{ij}|}\sum_{a\in S_{ij}}(M_{ja}-M_{ia})=\frac{c_j-c_i}{|\mathbf m_i\vee\mathbf m_j|}
 $$
 which is a **Jaccard-normalized dominance**, no longer a gradient: normalizing by a pair-dependent denominator injects curl. This is the recommended default.
* **A2 (per-scorer / per-cycle voters).** Voters = measurement regimes actually present in the framework (keyword scorer, manual scorer, consensus scorer — the cycle-22/23 triple, whose disagreement is already logged at Jaccard $0.182$), or cycles $1..K$ as time-indexed voters. Then $\bar Y_{ij}$ averages genuinely disagreeing judges and $\rho_{\mathrm c},\rho_{\mathrm h}$ measure *scorer/temporal* incoherence. This is the construction that most directly replaces the ad-hoc cross-regime comparisons.

**Graph.** Do **not** use the complete graph ($\beta_1=0$ trivially and $O(N^3)$ triangles). Use the same neighborhood structure the S² pipeline already implies: $k$-NN ($k\approx 8$–$15$) under cosine/Jaccard similarity on $M$, symmetrized, plus optionally chordal-distance-on-$S^2$ edges from the fitted curve $\gamma$. Weight $w_{ij}=|S_{ij}|$ (comparison count), matching JLYY's capacity weighting.

**Meaning of components.**
* $\operatorname{grad}s$: a **global capability-quality potential** on items — a principled scalar ranking that (unlike PC1) is defined by an $\ell_2$ projection with a stated model class, is invariant to the Möbius/PSL(2,ℂ) chart, and is *comparable across corpora* because $s$ is a potential, not a variance ratio.
* $\rho_{\mathrm c}$: **local triadic inconsistency** — triples of items where "$i$ covers more than $j$ covers more than $k$ covers more than $i$" under context restriction. Interpretation: the coverage ordering is unreliable *among near-neighbors* (fine scale) but may be fine at coarse scale.
* $\rho_{\mathrm h}$: **global cycles** — inconsistency that survives every triangle. Support of the harmonic flow localizes around holes of $K_G^3$: regions of capability space where the corpus has a *hole* (no triangle-filled path), i.e. missing intermediate artifacts.

### Construction B — *primitive graph* ($n=d$, tiny and fast)

Vertices = primitives; voters = items. Item $i$ compares primitives $a,b$ only if it is "at stake" ($M_{ia}+M_{ib}\ge1$):

$$
Y^{i}_{ab}=M_{ib}-M_{ia},\qquad
\bar Y_{ab}=\frac{\sum_i \mathbb 1[M_{ia}+M_{ib}\ge1](M_{ib}-M_{ia})}{\sum_i \mathbb 1[M_{ia}+M_{ib}\ge1]} .
$$

$s$ = **primitive difficulty/prevalence potential** (a rigorous version of the "primitive ladder"). $\rho_{\mathrm c}>0$ means primitives are not totally ordered by difficulty — genuine *co-occurrence cycles* ("A implies B implies C implies A"). Cheap ($d\le 384$, $\Delta_1$ dense-diagonalizable at $d\le 24$), and here the **full $\Delta_1$ spectrum** is computable, giving the spectral gap $\lambda_{\beta_1+1}(\Delta_1)$ directly.

### Construction C — *regime flow* (cross-regime comparator)

Vertices = items; voters = the three eligibility regimes {eligible, deferred, refused} × scorers. Define per-regime flows $Y^{(r)}$ by A1 restricted to rows in regime $r$ plus their boundary edges. Then compare potentials by the **relative Hodge angle**

$$
\cos\theta_{rr'}=\frac{\langle \operatorname{grad}s^{(r)},\operatorname{grad}s^{(r')}\rangle_w}{\|\operatorname{grad}s^{(r)}\|_w\|\operatorname{grad}s^{(r')}\|_w},
$$

a single scalar replacing the ad-hoc cross-regime PCA contrasts (cycle-23 reported PC1 eligible-vs-refused loadings of 89.1% / 77.2% / 29.7% across three scorers — three incomparable numbers; $\cos\theta$ is one comparable number per pair, chart-invariant).

---

## 3. Does Hodge give what GL lacked?

### (a) The vortex claim → harmonic 1-cocycles **are** discrete phase windings ✔ (strongest single gain)

The GL note (§3.6) states the vortex claim requires: a phase-like angular variable, a core with $\rho\to0$, and **nonzero winding $\oint\nabla\theta\cdot d\ell=2\pi n$** around it, and admits this has not been demonstrated.

Hodge supplies exactly this object. For a cycle $\sigma=(i_1\to i_2\to\dots\to i_L\to i_1)$ in $G$, define the **discrete circulation**

$$
W(\sigma)=\sum_{\ell=1}^{L} X_{i_\ell i_{\ell+1}} .
$$

Then:
* $X\in\operatorname{im}(\operatorname{grad}) \Rightarrow W(\sigma)=0$ for every cycle (a potential has no winding);
* $X\in\operatorname{im}(\operatorname{curl}^{*}) \Rightarrow$ $W$ is a sum of triangle curls — a *contractible* circulation, killed by filling faces;
* $X\in\ker\Delta_1 \Rightarrow W(\sigma)$ **depends only on the homology class $[\sigma]\in H_1(K_G^3;\mathbb R)$**, and is nonzero on generators. This is a *bona fide* discrete winding: constant along homologous paths, nonzero around a hole.

Formally, $\ker\Delta_1\;\cong\;H^1(K_G^3;\mathbb R)\;\cong\;\mathbb R^{\beta_1}$ (discrete Hodge/Eckmann). So: **harmonic flow = winding, hole = vortex core, $\beta_1$ = number of independent vortices.** The GL note's missing ingredient becomes a rank computation. Caveat that matters: this winding lives in $\mathbb R$, not $2\pi\mathbb Z$ — it is a *real-valued circulation class*, not a quantized topological charge. To recover quantization one must pass to $\mathbb Z$ coefficients ($H^1(K;\mathbb Z)$) or to a genuine $S^1$-valued phase (e.g. the azimuth $\phi$ of the S² embedding, where $\oint d\phi\in2\pi\mathbb Z$ *is* quantized — see §6, P3). Both are computable; only the latter is literally GL's vortex.

### (b) A PCA-independent disorder scalar ✔

$\rho_{\mathrm c}$ (and $\rho_{\mathrm h}$) depend on $M$ and the graph, **not** on any eigendecomposition of the covariance, not on the stereographic lift, not on the ridge $\lambda=10^{-3}$, not on the Möbius chart. Under the orthogonality theorem it is a *bona fide* fraction of energy, so "$\rho_{\mathrm c}=0.14$" means something exactly ("14% of comparison energy lies in locally cyclic modes"), whereas $V_2=\mathrm{PC1}{+}\mathrm{PC2}=0.769$ means "the top-2 eigenvalues carry 76.9% of variance" — a statement about a linear chart, not about the corpus's order structure. So $\rho_{\mathrm c}$ is an honest *independent* second axis. It is a **disorder** measure; calling it a temperature is the overreach (see §4).

### (c) $\Delta_1$ spectral gap vs $V_2$ stiffness — partial ✔/✖

* $\lambda_{\min}(\Delta_1)=0$ with multiplicity $\beta_1$; the **first nonzero eigenvalue $\lambda_{\beta_1+1}(\Delta_1)$** is the natural 1-dimensional spectral gap and controls how fast cyclic components relax — the closest legitimate analogue of a stiffness.
* For $\Delta_0$, $\lambda_2$ is the Fiedler value with Cheeger bounds $\frac{h_G^2}{2\max_i d_i}\le\lambda_2\le 2h_G$ — standard, and the relevant control on whether $s$ is well-conditioned (the HodgeRank sampling literature ties performance to $\lambda_2$).
* For $\Delta_1$ there is **no clean Cheeger inequality**: Gundert–Wagner and Steenbergen–Klivans–Mukherjee show the naive $\lambda_1$-vs-coboundary-expansion analogue fails in dimension $\ge1$. Use $\lambda_{\beta_1+1}(\Delta_1)$ as an empirical proxy; do **not** claim a theorem.

**Net:** (a) is a genuine, unique, rigorous gain. (b) is a real methodological gain. (c) is a usable diagnostic with no theorem behind the analogy.

---

## 4. Honest limits

1. **Graph-dependence is the dominant confound.** $\rho_{\mathrm h}$ and $\beta_1$ are properties of $K_G^3$, i.e. of your $k$-NN construction, not of the corpus alone. Kahle-type results for $G(n,p)$: $\beta_k$ vanishes a.a.s. when $p\ll n^{-1/k}$ or $p\gg n^{-1/(k+1)}$ and is nontrivial only in the window $n^{-1/k}\ll p\ll n^{-1/(k+1)}$. So $\beta_1$ is nonzero only in an *intermediate density band* — a threshold in $p$ that can trivially masquerade as a "phase transition in $N$." **Any $\rho_{\mathrm h}(N)$ curve must be reported at matched edge density and matched $k$, with a degree-matched null (configuration-model rewiring of $G$ with the same $\bar Y$).** This is the easiest way for the pivot to produce a fake result.
2. **Sampling complexity.** Xu–Yao (HodgeRank on Random Graphs, IEEE TMM 2012; Osting–Xiong–Xu–Yao arXiv:1503.00164): $O(n\log n)$ distinct edges suffice for connectivity (so $s$ is identifiable), but $O(n^{3/2})$ distinct edges are needed to force $\beta_1=0$ (loop-freeness). Empirically harmonic mass exceeded 50% of total inconsistency below ~25% edge coverage and vanished above ~70%. For $N=2286$ that is roughly $\gtrsim 2\times10^4$ edges for connectivity, $\gtrsim 10^5$ for loop-freeness — well above a $k{=}10$ NN graph ($\sim2\times10^4$). **Expect $\rho_{\mathrm h}>0$ at all your $N$ partly for sampling reasons.**
3. **Known critique: the fixed-tournament issue.** When harmonic mass persists, an adversary controlling *which* comparisons are made can drive the global order arbitrarily. Translated here: whoever chooses the neighbor graph partly chooses the ranking. Mitigation is density or balanced (random-regular) designs.
4. **Binary-data degeneracy.** With $Y_{ij}\in\{\pm1\}$, curl takes only values $\{\pm1,\pm3\}$ and everything reduces to circular-triad counting (Kendall–Babington Smith 1939). The coverage vectors are binary; only the pair-dependent normalization in A1/A2 lifts this out of the ordinal regime. **Degeneracy test first:** if $\bar Y_{ij}=g(c_j)-g(c_i)$ for *any* function $g$, then $\rho_{\mathrm c}=\rho_{\mathrm h}=0$ identically and the analysis is vacuous.
5. **$\ell_2$ fragility.** Least squares is not robust to outlier edges; JLYY's $\ell_1$ variants exist for this ($\ell_1$-projection on gradients ↔ correlation maximization over bounded divergence-free flows; sparse cyclic $\ell_1$ ↔ bounded curl-free flows). Zero-coverage "defect" rows are exactly the outliers that will dominate an $\ell_2$ fit.
6. **The GL bridge remains an analogy.** Harmonic ≈ vortex is *structurally* right (windings around holes) but there is no free energy, no dynamics, no $\xi$, no $\lambda$, so **Hodge does not repair $\kappa$** and there is still no thermodynamic temperature. $\rho_{\mathrm c}$ is disorder, not $T$; asserting $T\propto\rho_{\mathrm c}$ would be a new unearned identification. And $\beta_1$ counts *holes in your comparison complex* — the "vortex core" may be an absence of data rather than an absence of capability.
7. **No off-the-shelf inference.** The $\rho$'s have no null distribution; permutation/bootstrap CIs are required. At $N=49$ the whole thing is underpowered — expect $\beta_1$ dominated by graph noise.

---

## 5. Algorithm (numpy/scipy, sparse, $N\lesssim 2500$)

Verified in this session on a synthetic $N{=}300$, $d{=}9$ binary corpus: $|E|=1626$, $|T|=1746$, $\rho_{\mathrm g}=0.778$, $\rho_{\mathrm c}=0.137$, $\rho_{\mathrm h}=0.085$, orthogonality residuals $\sim10^{-10}$, $\beta_1=344$, $\beta_0=0$; hexagon control $\beta_1=1$.

```
INPUT  M ∈ {0,1}^{N×d}; k (neighbors); weights w
OUTPUT s, curl-component, harmonic-component, ρ_g, ρ_c, ρ_h, β_1, harmonic winding reps

1. GRAPH
   C  = cosine/Jaccard similarity of rows of M
   E  = symmetrized k-NN edge set, stored as sorted (i<j) tuples, index map idx
   T  = triangles: for each edge (i,j), intersect adj[i] ∩ adj[j], keep k>j    # O(Σ d_i^2)

2. BOUNDARY MATRICES (sparse)
   B1 ∈ R^{|E|×N} :  B1[e,i] = -1, B1[e,j] = +1                     for e=(i,j)
   B2 ∈ R^{|T|×|E|}: B2[t,(i,j)] = +1, B2[t,(j,k)] = +1, B2[t,(i,k)] = -1   for t=(i<j<k)
   W  = diag(w_e);  weighted problem uses  W^{1/2} B1  and  W^{1/2} Y

3. FLOW  (Construction A1)
   c   = M.sum(1)
   Y_e = ( c_j - c_i ) / |m_i ∨ m_j|        # OR-cardinality of the two coverage rows
   (A2: average per-voter Y^α over the voters that actually compared {i,j})

4. GRADIENT / POTENTIAL          # normal equation Δ_0 s = -div Y
   s   = lsqr( W^{1/2} B1 , W^{1/2} Y ).x           # min-norm solution, s defined up to const
   g   = B1 @ s ;  R = Y - g                         # div R = 0 by construction

5. CURL COMPONENT                # min_Φ ‖ B2^T Φ - R ‖_w
   φ    = lsqr( B2^T , R ).x                         # = (curl curl*)† curl Y
   curl = B2^T @ φ
   h    = R - curl                                   # harmonic: curl-free AND div-free

6. RATIOS  (weighted norms ‖x‖² = Σ_e w_e x_e²)
   ρ_g = ‖g‖²/‖Y‖² ,  ρ_c = ‖curl‖²/‖Y‖² ,  ρ_h = ‖h‖²/‖Y‖²         # must sum to 1
   VERIFY: |⟨g,curl⟩|, |⟨g,h⟩|, |⟨curl,h⟩| < 1e-8·‖Y‖²

7. BETTI NUMBERS
   β_0 = N - rank(B1) ;  β_1 = |E| - rank(B1) - rank(B2)
   # ranks via sparse QR, or count eigenvalues of Δ_1 = B2^T B2 + B1 W^{-1} B1^T below 1e-8
   # cross-check: χ = N - |E| + |T| = β_0 - β_1 + β_2 ,  β_2 = |T| - rank(B2)

8. HARMONIC WINDING REPRESENTATIVE
   H = eigsh(Δ_1, k=β_1+m, sigma=0)  → columns spanning ker Δ_1
   spanning tree of G; each non-tree edge e ↦ fundamental cycle σ_e
   circulation W(σ_e) = Σ_{oriented edges of σ_e} h(e')
   rank |W(σ_e)| descending → the top cycles ARE the candidate "vortex loops"
   report (cycle vertex list, W, ‖h|σ‖/‖h‖, and whether σ encloses a zero-coverage row)

9. NULL MODEL (mandatory)
   repeat 1–8 under (a) row-permuted M, (b) degree-preserving rewiring of G,
   (c) density-matched G at each N; report all ρ's and β_1 as z-scores vs these nulls
```

Complexity: triangle enumeration $O(\sum_i d_i^2)$ (trivial at $k\le15$); each `lsqr` iteration $O(|E|)$; the $\Delta_1$ eigensolve is on a sparse $|E|\times|E|$ matrix with $|E|\sim2\times10^4$ at $N=2286,k=10$ — seconds. Everything fits comfortably in memory.

---

## 6. Three falsifiable predictions linking Hodge to the existing time series

**P1 — Harmonic fraction collapses across $N_c$, *beyond the graph null*.**
With $k$ and edge density **held fixed**, $\rho_{\mathrm h}(N)$ decreases monotonically over the corpus series ($N=49,70,79,474,\dots,2286$) and drops by $\ge3\sigma$ (permutation SE) as $N$ crosses the $N_c\approx40$–$200$ band identified from $\max_N dV_2/d\log N$, while the degree-matched rewired null shows **no** such drop. Falsified if the null shows the same drop (then it was Kahle-window sampling, not corpus organization), or if $\rho_{\mathrm h}$ is flat/increasing. *This is the prediction that decides whether the pivot is load-bearing.*

**P2 — Curl fraction tracks $1-V_2$ with a nontrivial slope.**
Across the five dimensional variants (7, 9, 16, 24, 384-D) and all cycles, $\rho_{\mathrm c}$ and $1-V_2$ correlate with Spearman $\rho_s\ge0.6$, **and** the 24-D variant — the one that *fails* the $V_2\ge0.40$ gate — has the largest $\rho_{\mathrm c}$ of the five. Falsified if $|\rho_s|<0.3$, or if 24-D is not the curl maximum. Two-sided value: a *weak* correlation still justifies $\rho_{\mathrm c}$ as a genuinely new axis; only $\rho_s>0.95$ would make it redundant with $V_2$.

**P3 — Defect rows carry the harmonic support, with quantized S² winding.**
(i) The zero-coverage rows (18 at cycle 22) are over-represented in the support of $\ker\Delta_1$:
$\text{lift}=\dfrac{\|h|_{E_D}\|^2/\|h\|^2}{|E_D|/|E|}\ \ge\ 2$ where $E_D$ = defect-incident edges.
(ii) For the top-$\beta_1$ fundamental cycles by circulation, the azimuthal winding of the S² embedding $n(\sigma)=\frac1{2\pi}\oint_\sigma d\phi\in\mathbb Z$ is nonzero for at least half of them, and those cycles enclose a defect row. Falsified if the lift $\approx1$ (harmonic support diffuse → vortex language dies) or all $n(\sigma)=0$ (GL vortex claim refuted by a real test rather than left unproven). *Calibration: the synthetic control run here, with randomly placed zero rows, gave lift $=0.011/0.066\approx0.17$ — harmonic mass actively avoids random defects. A lift $\ge2$ on the real corpus would therefore be a strong, non-trivial positive.*

---

## 7. Verdict

**Adopt it, as channel 2 of a two-channel measurement, with the null model non-optional.**

| Gap in current framework | Hodge supplies | Rigor |
|---|---|---|
| No cyclic-inconsistency measure | $\rho_{\mathrm c},\rho_{\mathrm h}$ with exact energy budget | Thm. 4.8 orthogonality — theorem-grade |
| No local-vs-global distinction | curl (triadic) vs harmonic (homological) | $\ker\Delta_1=\ker\operatorname{curl}\cap\ker\operatorname{div}$ |
| GL vortex claim unproven | harmonic cocycle = circulation class on $H^1$; $\beta_1$ = vortex count | $\dim\ker\Delta_1=\beta_1$ — theorem-grade |
| Ad hoc cross-regime comparison | one potential $s$ per regime + Hodge angle $\cos\theta$ | chart-invariant single scalar |
| Chart-dependent diagnostics ($V_2$ under Möbius/ridge/lift) | $s,\rho_\bullet$ independent of PCA, lift, $\lambda$, PSL(2,ℂ) | by construction |
| Ranking without a reliability certificate | $\rho_{\mathrm g}$ | JLYY Thm. 5.1 |

What it does **not** fix: no temperature, no $\kappa$, no free energy, no cross-corpus transfer of $\kappa$, no Cheeger theorem in dimension 1. And it introduces one first-class new risk — **graph-construction artifacts that mimic phase transitions** (Kahle window). Report every Hodge quantity against a degree-matched null or the result is uninterpretable.

Cheapest decisive experiment: Construction B (primitive graph, $d\le24$, minutes, full $\Delta_1$ spectrum) on the existing 5-dimension series, then Construction A1 on the $N$-series with the P1 null. If P1 survives the null, the pivot is load-bearing; if not, keep $\rho_{\mathrm c}$ as a gate diagnostic (P2) and retire the GL-vortex bridge honestly.

---

## 8. Citations

1. X. Jiang, L.-H. Lim, Y. Yao, Y. Ye, "Statistical ranking and combinatorial Hodge theory," *Mathematical Programming* **127**(1):203–244, 2011. arXiv:0811.1067. — Defs. 2.1–2.3, 4.1–4.5; Lemma 4.4 (closedness), Lemma 4.6 ($\dim\ker\Delta_k=\beta_k$); Thm. 4.7 (Hodge), Thm. 4.8 (Helmholtz); Thm. 5.1 (normal equation, residual split, projection formulas); §6 ($\ell_1$ duals); §7 (Borda/Kemeny).
2. Q. Xu, Q. Huang, T. Jiang, B. Yan, W. Lin, Y. Yao, "HodgeRank on Random Graphs for Subjective Video Quality Assessment," *IEEE Trans. Multimedia* **14**(3):844–857, 2012. — $O(n\log n)$ vs $O(n^{3/2})$ edge sampling; harmonic-vanishing thresholds; fixed-tournament critique.
3. B. Osting, J. Xiong, Q. Xu, Y. Yao, "Analysis of Crowdsourced Sampling Strategies for HodgeRank with Sparse Random Graphs," arXiv:1503.00164 (2015; *Appl. Comput. Harmon. Anal.* 2017). — Fiedler-value-driven sampling design; sparse-regime caveats.
4. M. Kahle, "Topology of random clique complexes," *Discrete Mathematics* **309**(6):1658–1671, 2009. arXiv:math/0605536. — $\beta_k$ nontrivial only for $n^{-1/k}\ll p\ll n^{-1/(k+1)}$ (the Kahle window of §4.1).
5. J. Friedman, "Computing Betti numbers via combinatorial Laplacians," *Algorithmica* **21**:331–346, 1998.
6. B. Eckmann, "Harmonische Funktionen und Randwertaufgaben in einem Komplex," *Comment. Math. Helv.* **17**:240–255, 1944. — the original discrete Hodge theorem.
7. A. Gundert, U. Wagner, "On Laplacians of random complexes," *SoCG* 2012; J. Steenbergen, C. Klivans, S. Mukherjee, "A Cheeger-type inequality on simplicial complexes," *Adv. Appl. Math.* **56**:56–77, 2014. — why there is no naive higher-dimensional Cheeger inequality (§3c caveat).
8. M. G. Kendall, B. Babington Smith, "On the method of paired comparisons," *Biometrika* **31**:324–345, 1939. — circular triads, the ordinal ancestor of curl.
9. F. Chung, *Spectral Graph Theory*, AMS CBMS 92, 1997. — $\Delta_0$ Cheeger bounds for the conditioning of $s$.
10. Local sources: `papers/learned-latent-curves-2026-08-06.tex` (S² pipeline, $V_2\ge0.40$ gate, $Y_3^3$/Fibonacci probe, 5-dim series, $N=49/70/79$ snapshots); `complex-ginzburg-landau-skill-emergence-e2ed4704.md` (GL mapping table, §3.6 vortex requirements, §3.7 vortex-glass reading, §4 predictions, §5 limits).
