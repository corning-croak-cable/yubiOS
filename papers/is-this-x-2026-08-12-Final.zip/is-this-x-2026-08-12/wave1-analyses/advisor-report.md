# Advisor report — integration of T1/T2/T3 closures into "Is This X?" (2026-08-12)

I read the paper (all 834 lines), the three reports, and then ran two independent checks of my own on the raw dispatch logs (`papers/data/rsi-{79,docs-21,refs-113}*.json`). Those checks change the verdict on T3, so they come first.

---

## 0. Two verifications I ran (use these — they are load-bearing)

**(V1) T3's zero-regression result is empirical, not bookkeeping.** The obvious attack on "0 backward transitions in 1178" is that `missing_primitives` might be a cumulative union carried forward, which would make monotonicity definitional. It is not. Across all three corpora the per-file missing sets are nested in 1178/1178 transitions, **and 175 of the 598 shrink events remove primitives other than that cycle's `winner_primitive`** (refs 147, skills 16, docs 12 — exactly the 175 multi-step transitions T3 counted). Coverage is therefore re-assessed against the file each cycle, independently of what was dispatched. Zero regressions out of 1178 re-measurements is a real result. Put this sentence in the paper; without it a referee kills the whole dynamics section in one line.

**(V2) T3's "exact gradient flow, residual 0.0" is an identity of the instrument, not a discovered law.** `d_pre` takes exactly **one** distinct value per `k` (to 10 decimals) in all three corpora, all k. So Φ is a fixed 9-entry lookup indexed by coverage count, and `d_post(k) = Φ(k+1)` with `δ(k) = Φ(k) − Φ(k+1)` is telescoping *by construction* of the distance function. The empirical content is narrower and should be stated as exactly that: **the ladder is exchangeable in the primitives** — the distance depends only on how many are missing, not which — and therefore per-file cumulative Δ is path-independent and must decay to zero. That is a property of the measurement, and it is why the refs cycle-2 Δ "peak" is predictable from the initial k-histogram alone.

This makes T3's gradient-flow finding the **fourth member of the paper's own tautology family** (gate ⟺ r̂; in-sample sphere R² = 1; Σwrap(Δφ) ∈ 2πℤ), not a new physical claim. That reframing is what makes it publishable and, ironically, promotable.

---

## 1. Integration

### (a) Promote T3 — yes, but as *two* results, one of which is an identity

Promote. It is the cleanest statement in the program, and it closes the one item in §7 that the paper itself called "the one clean way" to settle something. But do not promote "exact gradient flow + maximal irreversibility" as a discovery; promote the pair **(strict append-only under independent re-measurement) + (absorbing at full coverage) + (no equilibrium description possible)**, and report the potential as a definitional consequence disclosed under the paper's own identity discipline. Otherwise you have promoted a tautology to a headline in a paper whose central contribution is catching tautologies — the single most damaging thing you could do here.

**New section, inserted as §7 (Scope → §8, Conclusion → §9):**

```latex
\section{Dynamics: the corpus's own construction}
\label{sec:dynamics}

The scope section of the previous draft named a detailed-balance test on the atom
edit log as the one clean way to separate potential from non-potential dynamics.
That test is run here, on the shipped log ($213$ files, $6$--$7$ cycles per corpus,
$1391$ dispatches, $1178$ file-level cycle-to-cycle transitions; \texttt{rsi-85}
excluded as a known relabel of the $79$). The state variable is the coverage count
$k=9-|{\rm missing}(i,c)|\in\{0,\dots,9\}$.

\textbf{D1 --- the log is strictly append-only, and this is a measurement, not
bookkeeping.} Of $1178$ transitions, $580$ stay (all of them the absorbing $k=9$),
$423$ advance by one, $175$ ($14.9\%$) advance by $2$--$4$, and \emph{none}
regresses. The missing sets are nested in $1178/1178$ transitions; crucially,
$175$ of the $598$ advancing transitions remove primitives \emph{other than} the
one the dispatch nominated, so coverage is re-assessed against the file each cycle
rather than carried forward as a union. Monotonicity is therefore an empirical
property of the corpus and its editor, not an artifact of the log's data
structure. It also refutes a claim made elsewhere in this lineage: dispatches are
counterfactual best-flip measurements, one per file per cycle, and the applied
edit adds up to four primitives at once. Every transition out of $k=0$ is $+4$
($14/14$) and out of $k=1$ is $+3$ or $+4$ ($27/27$). ``Append-only'' must not be
read as ``one primitive at a time''.

\textbf{D2 --- detailed balance is violated maximally; no equilibrium free energy
exists.} $T(k{+}1\to k)=0$ for every $k$, in every corpus: upward mass $598$,
downward mass $0$. Reversibility requires $\pi(k)T(k,k{+}1)=\pi(k{+}1)T(k{+}1,k)$
with the left side positive for $k=2,\dots,8$ and the right side identically zero,
so \emph{no} positive $\pi$ makes the chain reversible; the unique stationary
distribution is $\delta_{k=9}$. The Kolmogorov cycle criterion is vacuously
satisfied --- with no backward edges the transition graph is a DAG --- and is
therefore uninformative, which is itself worth recording as an instance of
Section~\ref{sec:identities}. The entropy-production estimator
$\sum_kJ(k)\log[T(k\!\to\!k{+}1)/T(k{+}1\!\to\!k)]$ diverges; it grows as
$-423\log\varepsilon$ under regularization and no single $\varepsilon$ should be
quoted. The defensible finite statement is a bound: with zero backward events in
$598$ opportunities, the rule of three puts the backward rate below $0.005$ at
$95\%$, giving entropy production $\gtrsim 3.1\times10^{3}$ nats per sweep of the
log. Any Ginzburg--Landau reading requires an equilibrium ensemble; there is none.

\textbf{D3 --- there is nonetheless a potential, and it is an identity.} Define
$\Phi(k)=d_{\rm pre}(k)$. On the shipped log $d_{\rm pre}$ takes exactly one value
per $k$ in all three corpora ($\Phi=2.0000,1.9758,1.9080,1.8091,1.6933,1.5727,
1.4552,1.3454,1.2451$), and $d_{\rm post}(k)-\Phi(k{+}1)=0$ exactly for
$k=0,\dots,7$ (max absolute residual $0.0$). Hence $\delta(k)=\Phi(k)-\Phi(k{+}1)$
and per-file cumulative $\Delta$ telescopes. This is not a discovered conservation
law: the ladder distance is a fixed function of the coverage \emph{count}, so the
gradient property follows from the definition, and the empirical content is only
that the distance is \emph{exchangeable} in the nine primitives --- it depends on
how many are missing, not which. Two consequences follow. First, cumulative
$\Delta$ is bounded and must decay to zero: ``emergence saturating'' is arithmetic
on a bounded lookup. Second, the refs cycle-2 $\Delta$ peak ($+11.98$), the
program's most-cited dynamical event, decomposes as a policy term of $-0.274$
(\emph{fewer} dispatches: $109\to106$) against a state term of $+2.368$: refs
begins at mean $k=3.01$ and cycle~1 pushes the population to $5.57$, straight onto
the maximum of the fixed ladder at $k=4$--$5$ ($\delta=0.1206,\,0.1175$).
The peak is predictable in advance from the initial $k$-histogram; skills79, which
starts at mean $k=7.22$ past the hump, never shows one.

\textbf{D4 --- ``potential vs non-potential'' was the wrong axis.} D2 and D3 hold
simultaneously. A detailed-balance test can reject equilibrium; it cannot decide
whether dynamics is potential in the gradient-descent sense, and the dichotomy
proposed in the previous draft's scope section conflated the two. The restatement
this program should carry is therefore stronger and narrower than the one proposed:
\emph{deterministic, exchangeable descent of a bounded coverage potential to an
absorbing fixpoint, with zero back-flux and no equilibrium ensemble.}

\textbf{D5 --- what the absorbing-chain fit does and does not buy.} A per-$k$
independent-flip model (jumps $\sim{\rm Binomial}(9-k,p(k))$, $9$ parameters,
AIC $878.15$) beats a global-$p$ model ($p=0.4732$, AIC $1202.10$;
$2\Delta\log L=339.96$ on $8$ df) and a two-parameter saturation model whose
exponent collapses to zero and which degenerates onto global-$p$. The fitted
$\hat p(k)=0.444,0.463,0.450,0.343,0.271,0.367,0.479,0.536,1.000$ is U-shaped with
its minimum at $k=4$, exactly where the per-flip payoff $\delta$ is maximal ---
flips are least likely where they are worth most --- though $k$ and cycle index are
entangled ($\hat p$ also rises with cycle) and within cycle~1 alone the U-shape
survives only shallowly. Two limits are stated rather than smoothed over: the
$9$ per-$k$ rates are fitted on the same jump histogram used to score the
trajectories, with no held-out check, and $\hat p(8)=1.000$ is a boundary estimate.
And \emph{no} independent-flip model reproduces the terminal fixpoint: every such
model leaves a geometric tail of $1$--$5$ open files at the last cycle where the
data show exactly zero. That sharpness is partly a stopping rule --- the loop was
run \emph{until} $\Delta=0$ --- so the last cycle is conditioned on termination and
should not be scored as a free prediction.
```

Abstract: append one sentence after the GWTC clause.

```latex
Five items the previous draft named as untested are closed here. Four close
negatively --- the $24$-D curl clause ($\rho_s=+0.17$, $p=0.69$), the three
untested Ginzburg--Landau predictions (no fluctuation peak, no susceptibility
divergence, no critical slowing-down), and the azimuthal channel, whose
ordering-permutation null ($500$ index shuffles) leaves the $Y_3^3$ probe at
$|z|\le0.19$ on both the $2286\times9$ master matrix and the real $269\times9$
GWTC matrix, with the $m{=}3$ Parseval shares \emph{below} their nulls because
PC1 ordering starves high azimuthal order. The fifth closes structurally: on the
edit log, $1178$ independently re-measured transitions contain zero regressions,
detailed balance is violated at every level with non-zero flux, and the unique
stationary distribution is the absorbing full-coverage state --- so ``emergence
over cycles'' is deterministic descent of a bounded exchangeable coverage
potential to a fixpoint, with no equilibrium ensemble and hence no
Ginzburg--Landau reading available in principle.
```

### (b) P5 where both the prediction and the replacement failed

Do not report it as two failures or as convention-dependence. **The two conventions are one fit.** With `h = 1/N`, χ = N·(per-row response), so `+0.4155` and `−0.5845` differ by exactly 1 by algebra — the same fit in two units, not two results, and T2's "verdict is convention-dependent" framing invites an easy attack. Also: **this paper's `.tex` never claims ~1/N.** I grepped; the "paper predicts smooth ~1/N" string lives in T2's own script metadata and traces to the GL reference lineage. Do not print a retraction of a claim the paper does not make.

Report it as one paragraph in §4 (replacing the P5 row's "not tested") and one row in Table 5:

```latex
\textbf{P5 (susceptibility).} Single-row leave-one-out response, up to $200$ rows
per $N$ over $N=40$--$2286$, each LOO set against its own curveball null, gives a
smooth monotone power law with no interior peak and no blow-up at any finite $N$:
per-row response $=0.0386\,N^{-0.585}$, $95\%$ CI $[-0.648,-0.521]$, $R^2=0.991$.
The two conventions for $\chi$ are the same fit in different units --- with
$h=1/N$, $\chi=N\times$(per-row response) $=0.0386\,N^{+0.415}$, the exponents
differing by exactly one --- so neither the growth under one nor the decay under
the other is evidence about criticality; what P5 requires, a divergence at a
finite $N_c$, is absent in both. Two further remarks are owed. The naive
expectation carried through this lineage, that one row's influence dilutes as
$1/N$, is also rejected: $-1$ lies far outside the CI. And $-0.585\approx-1/2$ is
the scaling of a sampling fluctuation, so the LOO response at these $N$ is
plausibly dominated by estimator noise rather than by systematic response ---
which would mean P5 as posed had no discriminating power to begin with. Separating
the two requires the same LOO sweep on matched null matrices, and that is not run
here.
```

Table 5 rows become: P4 **falsified** (no fluctuation peak beyond the subsampling baseline — see risk R1 below before you write this); P5 **falsified** (smooth power law, no divergence; the $1/N$ expectation also rejected); P7 **not supported** (see risk R6: soften from "linear wins").

### (c) The tautology finding — yes, and it is the paper's most transferable contribution

Elevate it to a named subsection in §6 with a design rule, not a footnote in §4. You now have five instances, three of them in the program's own most-cited machinery. Insert as §6.5, and add a sentence to Definition 1's discussion making the identity check a membership condition for the map.

```latex
\subsection{Identity checks: coordinates that cannot fail}
\label{sec:identities}

Five quantities in this program's lineage are true by construction, and each was
at some point read as evidence. They are collected here because the pattern, not
any one instance, is the finding.

\begin{table}[h]\centering\small
\begin{tabular}{llp{5.6cm}}
\toprule
quantity & status & why it carries no data \\
\midrule
$V_2\ge0.40\iff\hat r\le5$ & identity & $\hat r\equiv2/V_2$ (Prop.~\ref{prop:gate}) \\
sphere-fit $R^2=1.0000$ & identity & $L{=}1$ block linear in $(x,y,z)$, evaluated in-sample on the embedding it fits \\
$\sum{\rm wrap}(\Delta\varphi)\in2\pi\mathbb{Z}$ & identity & wrapped increments of any angle-valued field sum to $2\pi\mathbb{Z}$ around any closed loop; measured deviation $4.4\times10^{-16}$ on all $14{,}158$ cycles \\
Kolmogorov cycle criterion on the edit log & vacuous & zero backward edges make the chain a DAG; no directed cycle exists to test (\S\ref{sec:dynamics}) \\
$\delta(k)=\Phi(k)-\Phi(k{+}1)$ & identity & the ladder distance is a fixed function of the coverage count; the gradient property follows from the definition (\S\ref{sec:dynamics}, D3) \\
\bottomrule
\end{tabular}
\caption{Vacuous-by-construction quantities found in this program. Each was
reported at least once as a substantive result.}
\label{tab:identities}
\end{table}

The design rule this imposes on the map of Definition~\ref{def:qspace} is a
membership condition, and it is cheap: \textbf{no coordinate is admitted without a
demonstrated non-degenerate null} --- a construction under which the statistic
provably \emph{could} have taken a different value. Three of the five above fail
that test instantly: $\hat r$ is a function of $V_2$, in-sample $R^2$ is a
function of the design, and the winding sum is a function of the wrapping
convention. Two fail it subtly, and are the instructive ones: a criterion can be
satisfied vacuously by the very extremity of the effect it was meant to detect
(the DAG), and a conservation law can hold identically because the observable is a
function of the state variable alone (the ladder). P-H3 clause~(ii) is the sharpest
case: it asked whether harmonic $1$-cocycles are $2\pi$-quantized, but the
harmonic component is a real-valued flow in Jaccard-normalized dominance units, in
which $2\pi$ is not a unit of anything. The clause was not merely false; it was
dimensionally malformed, and the winding half of it was unfalsifiable. A
pre-registered prediction can fail in this fourth way --- neither confirmed,
falsified, nor untested, but \emph{void} --- and a question space that issues
exclusion-only verdicts must be able to say so.
```

Then update §4.3's P-H3 paragraph (line 447): clause (ii) moves from "not run" to **void, with the empirical part reported** — harmonic circulation is not quantized (all $14{,}158$ cycles have `round(∮h/2π)=0`; max $|∮h|=0.1010$, i.e. $1.6\%$ of $2\pi$; there is a single blob near zero, no ladder), and note the winding-number histogram (86.4% at $W{=}0$, never beyond $\pm2$) as the only non-trivial thing the winding computation yields.

---

## 2. Framing: the honest one-paragraph answer, and M_dyn

**Answer to "is this X?" — draft this verbatim into §9 as the paragraph before the last:**

> Is this corpus $X$? For every $X$ this program named, no. Mean-field Ginzburg–Landau is excluded on the shape of $\Delta V_2(N)$ and now on three further predictions run rather than asserted — no fluctuation peak beyond the subsampling baseline, no susceptibility divergence, no critical slowing-down — and it is excluded in principle as well: the corpus's own construction dynamics admits no equilibrium ensemble, so there is no free energy for a Landau expansion to be an expansion of. It is not a vortex system: the corpus is anti-cyclic, with $\beta_1$ some $313\sigma$ below a degree-matched null and zero harmonic support on the defect rows. It is not three-fold symmetric: under an ordering-permutation null the $Y_3^3$ probe is dead on both the master matrix and the real GWTC catalogue ($|z|\le0.19$), and the $m{=}3$ energy shares sit *below* their nulls, because ordering by PC1 makes the fit smoother in azimuth — the shuffled corpora are the ones with three-fold structure. What the corpus is, positively and measurably, is two things. As a matrix it is a two-population coverage mixture: $98\%$ of the headline observable is fixed by its marginals, and the surviving corpus-specific residual is $\Delta V_2=+0.0144$ at $z=+12.3$, small, real, and nearest a latent two-class mixture. As a process it is an absorbing gradient flow: $1178$ independently re-measured transitions with zero regressions, coarse-grained ($14.9\%$ adding two to four primitives at once) and front-loaded, descending a bounded exchangeable potential in the coverage count to a single absorbing fixpoint at full coverage, maximally irreversible and never returning. The second fact explains the first — an append-only policy that saturates one population while leaving another sparse manufactures exactly the row-mass bimodality that places the matrix off its own null — and it does so without any critical point, order parameter, or phase.

**Does the map need M_dyn? Yes — but as a second channel, not a fifth family.** $M_0,M_1,M_4$ are generated *matrices* at matched $(N,d,\text{density})$; an absorbing gradient flow is not a matrix and cannot be z-scored against them. Adding it to Table 8 would be a category error of the same shape as the ones this paper indicts. Do this instead, at the end of §6:

```latex
\subsection{A second channel: $\Phi_{\rm dyn}$ and the family $M_{\rm dyn}$}

Section~\ref{sec:dynamics} measures a different object --- a trajectory, not a
matrix --- and therefore extends the question space by a declared channel rather
than by a family in Eq.~\eqref{eq:svector}. Let $\Phi_{\rm dyn}$ map a per-item,
per-cycle coverage log to
\[
s_{\rm dyn}=\big[\,f_{\rm back},\ f_{\rm multi},\ k_\infty,\
{\rm shape}(\hat p(k)),\ r_{\rm telescope}\,\big],
\]
the observed backward-transition fraction, the multi-step fraction, the absorbing
state, the fitted per-$k$ flip-rate profile, and the residual of the telescoping
identity of D3. The reference family $M_{\rm dyn}$ --- \emph{absorbing gradient
flow on a bounded lattice} --- is generated as ${\rm Binomial}(9-k,\hat p(k))$
ascent from the observed cycle-$1$ $k$-histogram, and the two matched nulls are a
time-reversal null (relabel each transition's direction) and a cycle-order
permutation null. Measured on the shipped log, yubiOS's construction history is
$M_{\rm dyn}$-\texttt{not-excluded} on $f_{\rm back}$, $k_\infty$ and
$r_{\rm telescope}$, and \texttt{excluded} on the terminal cycle, which is sharper
than any independent-flip model allows (D5) --- though that coordinate is
conditioned on a stopping rule and is flagged, not scored. Any equilibrium family
is excluded outright: $f_{\rm back}=0$ with $598$ opportunities admits no
reversible $\pi$.

One boundary must be stated. The log covers $213$ files over $6$--$7$ cycles; the
coverage matrix has $2286$ rows at a different granularity. The dynamics channel
therefore \emph{corroborates} the append-only mechanism proposed for the row-mass
bimodality of Section~\ref{sec:isthisx} on a subset at a coarser index, and does
not confirm it row by row. The caveat in Section~\ref{sec:scope} stands.
```

---

## 3. Risks — ordered by how likely they are to be attacked

**R1 (most fragile — fix before publishing). T2's "no fluctuation peak" is not yet established.** `Var[ΔV₂]` computed by row-subsampling a *single* finite corpus has a built-in decay $\propto(1/N - 1/2286)$; the test has no calibrated baseline. Check the numbers: from $N{=}40\to79$ the baseline predicts a $\approx2\times$ drop, and the measured variance is *flat* ($1.394\times10^{-4}\to1.422\times10^{-4}$) — i.e. a $\approx2\times$ **excess in the normalized fluctuation, sitting exactly on the old $N_c\approx40$–$79$ band.** From $N{=}79$ on, measured and baseline ratios track each other closely ($0.40$ vs $0.48$, $0.56$ vs $0.46$, $0.48$ vs $0.42$). A referee who divides by the baseline gets a peak where T2 reports none, and it lands on the number this paper says does not exist. Required: rerun the P4 sweep reporting `Var[ΔV₂](N)` **divided by the curveball-null variance at the same $N$** (the per-rep nulls already exist — this is a re-aggregation, not a new experiment), or at minimum print the $(1/N - 1/N_{\rm tot})$ baseline beside the measured column and state whether the $40$–$79$ plateau survives it. Also **drop the $N{=}2286$ row from any monotonicity claim**: subsampling $2286$ of $2286$ is deterministic, so `Var = 3.8e-8` at $10$ reps is null-estimator noise, and T2 already says so. Until that normalization is run, the paper must not write "no fluctuation peak"; write "no peak beyond the finite-population subsampling baseline, pending the ratio test", or defer the P4 claim.

**R2. T1's "15σ farther from the 2π lattice" — do not headline it.** Two problems. (i) The rows "mean distance of $C/2\pi$ to nearest integer" and "mean $|C|$" are the **same statistic divided by $2\pi$** ($1.3153\times10^{-2}/2\pi = 2.0933\times10^{-3}$ exactly; ditto the null), hence the identical $z=+14.97$ twice. That is one test, and printing it as two corroborating rows will be caught. (ii) `mean |C|` is not scale-invariant, and the scale-invariant version of the same quantity, $\rho_{\rm h}$, is **not significant** ($z=+1.45$, $p=0.157$). So the honest statement is: unnormalized harmonic circulations are $\approx9\times$ larger than the null's, while normalized harmonic *energy* is indistinguishable from it — the "$15\sigma$" is a magnitude/scale effect, and the real argument against clause (ii) is the dimensional one (there is no $2\pi$ unit in Jaccard-normalized dominance flow) plus "max $|∮h|$ is $1.6\%$ of $2\pi$; there is no ladder". Lead with those; demote the $15\sigma$ to a parenthetical.

**R3. T1's null resolution.** $50$ draws ⇒ p-floor $1/51=0.0196$; five separate rows report exactly that. Print them as $p<0.02$ (resolution-limited), and do **not** z-score the Rayleigh $Z$ (a non-Gaussian, $n$-dependent statistic) — use the empirical rank only. Also keep T1's own disclosure that $|C|$ takes essentially two values ($0$ or $0.100954$), so $r(|C|,|W|)=+0.95$ vs $\rho_s=+0.31$ is a binary-degeneracy artifact.

**R4. T2's 24-D clause has almost no power.** With $n=8$, a Spearman CI is roughly $\pm0.7$; you can exclude $\rho_s\gtrsim0.7$, not $0.6$. Change "does **not** survive" to "not supported — point estimates $+0.17$ / $+0.10$, $p\ge0.69$, indistinguishable from zero, and at $n=8$ the test excludes only $\rho_s\gtrsim0.7$ with confidence". Keep T2's own caveat that the 24-D graph is dominated by 12 noise columns, and add the honest concession that this makes the 24-D space a weak venue for the prediction rather than a fair one — it is the space the paper defined, which is exactly why the clause should never have been posed there.

**R5. T2's P7 "linear wins by AIC" overclaims.** ΔAIC of $-2.00$ and $-0.97$ with $\nu$ CIs $[-0.20,2.23]$ and $[-0.01,1.17]$ is "no evidence for a critical exponent", not "the linear model wins". Write: "the critical-exponent model buys $\le1\%$ of RSS and is not distinguishable from linear; $\nu$'s CI includes $1$ at both $N$; P7 is not supported and no positive claim for the linear form is made either."

**R6. T3's "+∞ entropy production" as printed is an artifact of a zero count.** Use the rule-of-three bound (backward rate $<0.005$ at $95\%$ over $598$ opportunities ⇒ $\gtrsim3.1\times10^3$ nats), state that the estimator is unbounded, and never quote a single $\varepsilon$. Same discipline for "$0$ backward transitions": always with the denominator.

**R7. T3's per-$k$ model.** Nine free rates fitted on the same jump histogram used to score trajectories, no held-out validation; $\hat p(8)=1.000$ on the boundary; $k$ and cycle index entangled (they disclose this — keep it, and keep the cycle-1-only shallower U-shape). And the "no model reproduces the hard fixpoint" line is partly **selection on stopping**: the loop was run until $\Delta=0$, so the terminal zero is a stopping rule. Say so or a referee will.

**R8. Provenance of the coverage labels.** V1 shows coverage is re-measured, but I cannot verify *how* — if the same judge re-scored each file with the previous cycle's label in view, monotonicity could be partly manufactured by anchoring. One sentence: "the per-cycle coverage assessment is inherited from the improvement loop and its blinding is not documented; the zero-regression result is conditional on that assessment being independent across cycles."

**R9. Granularity mismatch.** 213 files vs 2286 rows. Do **not** flip line 743's "flagged as unconfirmed" to confirmed. Corroboration on a subset at a coarser index, as drafted above.

**R10. GWTC $P_3$.** Keep T1's treatment, but print the multiplicity explicitly: 1 nominal hit in 10 reported tests, Bonferroni $p_{\rm adj}=0.38$, sign flips to $z=-0.96$ under PC1 weighting on the same data. And keep the low-power disclosure at $N=269$.

**R11 (an asset, not a risk).** The $m{=}3$ shares sitting *below* null with a stated mechanism (PC1 ordering starves high azimuthal order; shuffling manufactures it) is stronger than a non-detection and is the definitive burial of the three-fold narrative. Give it its own sentence in §8 and in the abstract — it converts "unsupported" into "the effect runs the other way, and we know why".

---

## 4. Priorities

**Must (in this order):**
1. **New §7 dynamics** with D1–D5, including V1's re-measurement argument and V2's identity disclosure.
2. **§6.5 identity audit + the admission rule** (Table `tab:identities`).
3. **Fix R1 before writing any P4 sentence.** Either run the variance-ratio re-aggregation or state P4 as pending.
4. **Rewrite §7's "Untested items, named"** into "Items closed" — a five-row table (P-H3(ii): void + empirically not quantized; P-H2 24-D: not supported, low power; P4/P5/P7: falsified / falsified / not supported; ordering-permutation null: executed, azimuthal channel dead with reversed sign; dynamics: closed, §7) — plus the P5 paragraph and the Table 5 row updates.
5. **De-risk T1's headline** per R2/R3 and update Remark 1 and §8: the ordering-permutation null is no longer "specified, not executed"; it ran, and it kills the azimuthal reading with the direction reversed.
6. **Abstract + Conclusion**: the one-sentence abstract insert and the "is this $X$?" paragraph.
7. **§6.6 $\Phi_{\rm dyn}$ / $M_{\rm dyn}$** as a declared second channel, with the granularity boundary. Do not touch Table 8.
8. **Qualifier sweep**: R4–R10 (each is one clause or one sentence).

**Do not put in (scope creep):**
- Any new Hodge work: 24-D Hodge re-runs, torsion resolution, coverage-band cap fixes.
- Quotienting the GWTC kinematic identities and re-measuring.
- The LOO-on-null-matrices run for P5's noise-floor question. Name it as unrun; do not run it. (R1's ratio test is different — that one is a re-aggregation of data you already have, and it is required.)
- Any further modelling of $\hat p(k)$, mechanistic stories for the U-shape, or a generative dynamics model beyond `Binomial(9−k, p̂(k))` as a reference family.
- The auxiliary 20-cycle file. One footnote at most; do not build on it.
- Renaming/retitling, extending the fold ladder, new corpora, or promoting $M_{\rm dyn}$ into the matrix family table.
- Any claim that D3 discovers a potential, or that the corpus "is" a gradient system in a physical sense. It descends a lookup table. That is the finding, and its modesty is the point.
