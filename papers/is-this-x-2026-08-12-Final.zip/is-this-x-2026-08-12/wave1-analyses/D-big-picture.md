# D — Big-Picture Synthesis Memo (wave 1)

**Agent role:** big-picture synthesis / strip-the-metaphors
**Date:** 2026-08-12
**Inputs read:** CGL ref entry (`complex-ginzburg-landau-skill-emergence`), cycles 1–34 README, cycle-34 (`new-ideas`, `empirical_gate_results`, constraints catalog), cycles 31–33 gate JSONs, `rsi-regime.md`, `learned-latent-curves-2026-08-06.tex` (abstract, §2–4, §5–8, App A–C), single-action-atom evidence bundle.
**Intended path** `/var/workspace/session/wave1/D-big-picture.md` is on a read-only mount; written to `session/subagent/D-big-picture.md` instead.

> **NOTE — this memo contains new computation, not just reading.** I re-ran the program's own headline observable on the program's own data (`cycle-20/per_row_coverage_v3.json`, 2286×9) against three null models that the program has never run. My pipeline reproduces the published number exactly (V₂ = 0.7235 vs published 0.723529), so the nulls are directly comparable. **The result changes the headline conclusion of the whole program.** All numbers below marked ⟨new⟩ are from that run and are reproducible from the shipped JSON alone.

---

## 0. The one-paragraph answer

The program is measuring the **top-2 eigenvalue share of the 9×9 correlation matrix of a binary coverage matrix**, which is an almost pure function of one thing: how bimodal the row coverage-sum distribution is. ⟨new⟩ Against a matched-marginal (row **and** column sums preserved) null the real corpus scores V₂ = 0.7235 versus null 0.8005 ± 0.0017 — the corpus is **46 σ *below* its own null**, i.e. it has *less* two-dimensional concentration than a random matrix with the same marginals. And ⟨new⟩ the famous +0.4664 "phase transition" (0.2993 → 0.7657) is reproduced to within 0.011 by **holding the data fixed and changing the feature-space dimension from 24 to 9** (V₂ = 0.2882 at D = 24, 0.7235 at D = 9 on the *identical rows*). The 0.2993 baseline is the 24-D basis and the 0.7657 endpoint is the 9-D basis — this is documented in `rsi-regime.md`'s own 5-dim library. There is no transition to explain. Ginzburg–Landau, Grothendieck, and the pentagon are all descriptions of an artifact.

---

## Q1. What is the program actually measuring?

### 1.1 The observable, stripped

`V₂ = (λ₁+λ₂)/Σλ` on the correlation matrix of `X ∈ {0,1}^{N×9}`. Since the correlation matrix has trace D = 9, V₂ is fully determined by the two leading eigenvalues of a 9×9 matrix whose off-diagonal entries are primitive co-occurrence correlations.

⟨new⟩ Measured on the real matrix: mean off-diagonal correlation **ρ̄ = 0.590**. The equicorrelated (one-factor) model predicts λ₁ = 1 + (D−1)ρ̄ = **5.717**; observed λ₁ = **5.789**. Predicted V₂ = 0.681, observed 0.7235. **A single scalar — the mean pairwise co-occurrence — accounts for ~94% of the headline observable.** Effective rank: participation ratio 2.31, Shannon effective rank 3.87.

Where does ρ̄ = 0.59 come from? ⟨new⟩ The coverage-sum distribution is violently U-shaped: `{0:204, 1:317, 2:227, 3:124, 4:92, 5:110, 6:103, 7:127, 8:187, 9:795}`. 795 rows are all-ones and 204 are all-zeros. Rows that are all-on or all-off make every column pair positively correlated. So:

> **V₂ measures the bimodality of "how many primitives this row has". It is a re-encoding of the row-mass histogram, not a measure of "organization", "capability", or "emergence".**

Worse, that U-shape is **manufactured by the program itself**. The atom loop (Lemma 1, append-only 0→1 flips) drove `skills/`, `docs/`, `refs/` to 100% coverage on all nine primitives — 795 saturated rows. The `self` corpus (895 rows, 1.77 bits/row) was never run through it. ⟨new⟩ Per-corpus: skills 8.45 bits/row, docs 7.83, refs 7.13, self 1.77. **Pooling a saturated population with a sparse one is exactly the recipe for a large common factor.** Per-corpus V₂ (0.58–0.65) is *lower* than the pooled 0.7235. The headline number is a Simpson-style pooling artifact on top of the loop's own output.

### 1.2 The three nulls the program never ran ⟨new⟩

| Null (all on the real 2286×9 matrix) | V₂ | Interpretation |
|---|---:|---|
| **Real corpus** | **0.7235** | (matches published 0.723529) |
| A: iid Bernoulli, matched **column** marginals | 0.2398 ± 0.0026 | ≈ 2/D = 0.2222 + finite-size (Marchenko–Pastur) |
| B: independent column permutation | 0.2401 ± 0.0025 | same |
| C: **curveball** — row **and** column sums preserved | **0.8005 ± 0.0017** | real is **z = −45.8** |
| D: row-mass preserved, columns randomized | 0.6708 ± 0.0009 | row mass alone gives 93% of the signal |

Three things fall out immediately:

1. The program's own `V_floor = 0.222` is **exactly 2/D — the iid null** — and was never recognized as one.
2. The program's own `V_sat_emp ≈ 0.78` / `V_inf ≈ 0.769` is **exactly the matched-marginal null (0.80)**. The "7/9 = 0.7778" numerology is coincidence: change the row-mass histogram and the saturation moves.
3. Conditional on marginals, the corpus is **anti-structured**. Whatever the nine primitives co-occur by, it is *less* concentrated than chance.

### 1.3 The climb is a dimension change, not a transition ⟨new⟩

Appending nuisance columns to the *identical* 2286 rows:

| D | V₂ | 2/D |
|---:|---:|---:|
| 9 | 0.7235 | 0.222 |
| 14 | 0.4907 | 0.143 |
| 24 | **0.2882** | 0.083 |
| 34 | 0.2052 | 0.059 |

`rsi-regime.md` states plainly: **24-D basis (9 primitives + 12 NSS axes + 3 metadata) → gate 0.2993 ✗; 9-D basis → 0.4565 ✓**. The GL entry §1 takes the 24-D number as the "paper baseline" and the 9-D number as the "endpoint" and reads the difference as a second-order phase transition. My D = 24 reconstruction lands at 0.2882 (0.3525 when the nuisance columns are made row-mass-correlated, as real NSS axes would be). **The +0.4664 is the D-dependence of an eigenvalue-share statistic.**

### 1.4 N-dependence: there is none ⟨new⟩

| N | real | curveball null | mass-only null | col-perm null |
|---:|---:|---:|---:|---:|
| 40 | 0.7895 | 0.8267 | 0.7522 | 0.3643 |
| 79 | 0.7383 | 0.7980 | 0.6760 | 0.3249 |
| 200 | 0.7447 | 0.8032 | 0.6890 | 0.2835 |
| 500 | 0.7183 | 0.7845 | 0.6674 | 0.2608 |
| 1000 | 0.7327 | 0.7880 | 0.6837 | 0.2489 |
| 2286 | 0.7235 | 0.7613 | 0.6709 | 0.2410 |

Real V₂ is **flat-to-mildly-decreasing** in N. The only monotone N-dependence anywhere in the table is the *null's* finite-size relaxation toward 2/D (0.364 → 0.241) — pure Marchenko–Pastur, aspect ratio D/N. So:

- `N_c ≈ 40` (cycle 25) is the smallest N in the sweep and sits where finite-size inflation is largest. It is an **estimator artifact**, not a critical point.
- `dV₂/d log N` has no maximum to find.
- The mean-field exponent β ≈ 1/2 has nothing to fit.

### 1.5 Does any of GL / pentagon / Grothendieck survive?

**Ginzburg–Landau — survives as vocabulary only, and less of it than §5 already concedes.**
- *Order parameter / control variable / free energy / fluctuations / defects* is a fine **checklist** and forced the program to construct `F_eff = −T log P` (a legitimate object: it is a KDE log-density of PC scores). Keep the discipline, drop the physics.
- The transition itself: **falsified** (§1.3–1.4).
- κ ≈ 1: the ξ and λ estimators are **row-lag** quantities (autocorrelation / Hamming saturation *as a function of row index*). Row order in a corpus is file-listing order — arbitrary. A statistic that changes under row relabeling cannot be a physical length. That κ ≈ 1.0 reproduces across "three methods" on yubiOS and spans 0.086 → 323 across corpora (L135, L143) is exactly what you expect from an estimator with no invariance property. The program has itself root-caused **three** κ artifacts (L126 protocol artifact, L139 Method-A degeneracy, L143 NIST d_sat clamp). That is the signal.
- Type-I/type-II: what L138's p-sweep actually measures is **robustness of V₂ to bit-flip noise**. That is a real, useful curve. It is not a surface-energy sign.
- L131 is the program's own null result and the most important finding in cycles 31–34: **all 10 perturbation protocols gave c_lin indistinguishable from the row-permuted null.** Read alongside my curveball result, the honest summary is: *the corpus carries no linear-response signal above matched-marginal chance.*

**Pentagon — dead.** RMS 0.34–0.42 against an ideal of 0; κ = 1.06 vs φ = 1.62 (56% apart, no CI overlap); the 5-basin count is bandwidth- and PC-pair-dependent (L146: (PC1,PC2) gives 4 or 5 depending on a depth threshold). Recommend permanent retirement of φ/pentagon/nonagon coincidence-hunting.

**Grothendieck — vocabulary, and the program's own §10 says so.** "yubiOS gap 1.20 < k_G 1.78" says the corpus is not a worst-case instance — true of essentially every real dense low-rank ±1 matrix, so it excludes nothing. "Yoneda down-set ≈ N/2" is an identity about down-sets of a near-total order, not a finding. The one computation with any content left is the **corpus-internal SDP-vs-integer gap** (their own open item #2), and even that needs a null (compute it on the curveball ensemble too) before it means anything.

**What genuinely survives, in one line:** *the effective-potential construction*, *finite-size scaling as a diagnostic*, and *the discipline of naming a control variable and an order parameter before measuring*. That is a methodology, not a model.

---

## Q2. What has been missing — ranked

**#1 — (a) No null model.** *Decisive; now demonstrated.* Every number the program has produced in 34 cycles — V₂, V_inf, V_floor, N_c, κ, basin counts, pentagon RMS, cross-corpus transfer — was computed without a matched-marginal baseline. With one, the headline collapses (z = −45.8, wrong sign) and two of the program's three "boundary objects" turn out to be the null itself (2/D and the curveball value). **Nothing else on this list matters until this is fixed, because every downstream statistic inherits the same defect.** Cost to fix: one afternoon; I did the yubiOS half above.

**#2 — (e) The "IS THIS X" identification problem.** *Structural cause of everything else.* Thirty-four cycles, one X at a time (GL → LIGO → Grothendieck → pentagon), each evaluated by narrative compatibility ("T1 PARTIAL, T2 YES/PARTIAL") rather than by a discriminating prediction. A framework that produces "PARTIAL" as its median verdict is not being tested. Two specific defects: (i) **no null class** — X-space has no origin, so "compatible with GL" is never weighed against "compatible with nothing"; (ii) **no shared sufficient statistic** — each X is tested with bespoke estimators (d_sat windows, KDE bandwidths, row-lag correlations) that are not comparable across X or across corpora, which is why κ can be 1.0 and 323 in the same table. Design in Q3.

**#3 — (f, not on your list) No estimator validation / no invariance requirements.** I'm inserting this above (b)(c)(d) because the program's own evidence demands it. Three κ artifacts root-caused; basin counts that move with bandwidth and depth threshold; a "length" measured along an arbitrary row ordering; a 384-D gate that reports PC1+PC2 = 1.0000 (a degeneracy, see Q4). **Rule to adopt: every statistic must be invariant under row relabeling and column permutation, and must be reported with its value on the null ensemble and its sensitivity to every free tuning parameter.** Cheap, and it would have caught L143 in cycle 25 instead of cycle 34.

**#4 — (c) No dynamics.** *Highest upside of the remaining holes, because the data already exists and is unused.* The program has 1,391 atom dispatches with per-cycle coverage vectors, per-cycle `c₁…c₆` primitive counts, a 20-cycle re-fit experiment, 34 cycles of snapshots, and git history — a genuine trajectory dataset — and treats every cycle as an equilibrium snapshot. Note the trap this creates: the atom policy is a **monotone absorbing Markov chain** (append-only 0→1 flips toward all-ones), so *of course* aggregate coverage rises and *of course* increments diminish; the Δ-ladder peaked at k = 5 in App A.3 is a pure geometric property of the chordal metric, reproduced identically on all three corpora. Any "emergence over cycles" reading must first be differenced against the absorbing chain. Conversely, the detailed-balance test on the edit log is the *only* clean way to settle GL-vs-CGLE (their §5 caveat 4), and it is one transition-matrix estimate away.

**#5 — (d) No information-theoretic account.** *Medium; more a replacement than a hole.* V₂ is a crude, dimension-sensitive stand-in for "how compressible is this matrix". The honest quantity is **description length**: bits/row under {independent columns, k-factor logistic PCA / Rasch, latent-class mixture, saturated}. That is dimension-comparable (so the 24-D vs 9-D confound cannot recur), null-comparable, and answers the actual scientific question — *how many latent skills are there?* — which V₂ only gestures at. Adopt MDL as the primary observable and demote V₂ to a plotted diagnostic.

**#6 — (b) No topology.** *Lowest priority, but cheap and a clean falsifier.* The vortex/defect language has been running since cycle 24 while the GL entry's own §3.6 lists five conditions for a vortex claim (phase coordinate, amplitude zero, winding, persistence, localization) of which **zero** have been demonstrated — there is no phase coordinate anywhere in the pipeline. With D = 9 binary columns the state space is ≤ 512 hypercube vertices; persistent homology on the Hamming metric is minutes of compute. I expect β₁ to be null-consistent, which is precisely why it's worth running: it retires "vortex", "defect", and "glass" in one shot.

---

## Q3. The IS-THIS-X question space

### 3.1 Design principles

1. **The null is the origin, not a member.** Every statistic is reported as a null-standardized residual `z = (s − E₀[s])/SD₀[s]`, where the null M₀ is the maximum-entropy ensemble with the corpus's row and column marginals (curveball). Only residual coordinates enter classification. A corpus whose residuals are all |z| < 2 **is** M₀ and gets no further modelling.
2. **Invariance requirement.** Every statistic must be invariant to row relabeling and to permutation of columns (up to the obvious equivariance). This deletes the row-lag κ family by construction.
3. **Discriminating predictions only.** Each class must name a statistic on which it predicts something at least one *other* class forbids. "Compatible with" is not evidence. No verdict may be "PARTIAL"; the allowed verdicts are `excluded (p<α)`, `not excluded`, `not tested`.
4. **The deliverable is a map, not a verdict.** `Φ : corpus ↦ s ∈ ℝᵐ`, plus a figure placing yubiOS / NIST / CIS / SCAP-SSG / GWTC as points in null-standardized s-space, plus an exclusion table (class × corpus).
5. **Pre-register.** Statistics, thresholds, and kill criteria fixed before running; corpora split into a tuning half and a confirmation half.

### 3.2 The sufficient-statistic vector s (concrete)

| Block | Components | Notes |
|---|---|---|
| **S1 Spectral** | λ₁…λ_D of the correlation matrix; V_k for k=1..4; participation ratio; Shannon effective rank; **number of eigenvalues above the Marchenko–Pastur edge**; Tracy–Widom z of λ₁ after projecting out the row-mass factor | ⟨new⟩ yubiOS: 2.31 / 3.87; λ = [5.79, .73, .66, .50, .39, .33, .22, .20, .18] |
| **S2 Marginal** | row-mass histogram + bimodality coefficient; column marginals; Gini; mean off-diagonal correlation ρ̄ | ⟨new⟩ ρ̄ = 0.590 — the single number that explains V₂ |
| **S3 Null-residual** | V_k − V_k^{curveball}, z-scored; total correlation minus sum of pairwise MI (genuine higher-order dependence) | ⟨new⟩ yubiOS z = −45.8 |
| **S4 Latent-trait** | logistic PCA / Rasch with k = 1…5 and latent-class with k = 1…10: ΔBIC, residual dependence, bits/row (MDL) | replaces V₂ as the primary observable; dimension-comparable |
| **S5 Landscape** | F_eff well **persistence** (bandwidth range over which each well survives), not well count at one bandwidth; well depth in units of the null's well depth | kills the 4-vs-5 basin instability at its root |
| **S6 Topology** | β₀, β₁ of the Vietoris–Rips / witness complex on Hamming distance, with persistence lifetimes, vs curveball null | the vortex falsifier |
| **S7 Dynamics** | transition counts between coverage states across cycles; generator estimate; spectral gap / relaxation time; **detailed-balance test** (probability current); absorbing-chain reference model | requires the edit log |
| **S8 Finite-size** | V_k(N), λ₁(N), MDL(N) exponents **with the null's own N-dependence subtracted** | this subtraction is what N_c ≈ 40 was missing |
| **S9 Compression** | rate–distortion curve R(D) for the corpus; where the 2-D projection sits relative to the frontier | says how much PCA-to-2D actually costs |
| **S10 Robustness** | dV₂/dp and dMDL/dp under bit-flip noise (the honest content of the type-I/II test) | keep, rename |

### 3.3 The classes X, with decision rule and falsifier

| Class | Decision rule (on null-standardized s) | Falsification criterion |
|---|---|---|
| **M₀ matched-marginal null** (origin) | all residual coords \|z\| < 2 | any residual \|z\| > 3 replicated on the confirmation half |
| **M₁ low-rank factor / latent trait** | #eigs above MP edge = k; ΔBIC favors k-factor; residuals null | residual correlation survives k factors |
| **M₂ mean-field GL** | order-parameter exponent β ≈ ½ in a *named* control variable; Var[V₂] peak and susceptibility peak at the **same** N_c; cross-corpus data collapse after rescaling | no fluctuation peak; N_c unstable across estimators; V₂(N) explained by null's N-dependence — **all three already met ⟨new⟩ ⇒ M₂ excluded for yubiOS** |
| **M₃ spin-glass / multi-well** | ≥2 wells persistent over a bandwidth decade; overlap distribution P(q) with broad support / RSB signature | wells vanish under ×2 bandwidth; P(q) matches mixture null |
| **M₄ finite mixture / latent class** *(the boring alternative, and my prior)* | BIC-optimal k-class model on the hypercube; **simulating from it reproduces S5 well counts and S1 spectrum** | simulated data fails to reproduce basin counts within CI |
| **M₅ percolation** | giant-component onset in the co-occurrence graph with mean-field β = 1; cluster-size τ = 5/2 in a scaling window | no scaling window |
| **M₆ Hodge / topological** | β₁ persistent above null; nonzero curl in the Hodge decomposition of a pairwise flow | β₁ null-consistent |
| **M₇ rate–distortion / MDL** | *descriptive, not a hypothesis*: report bits/row and R(D) | n/a — this is the yardstick, not a claim |
| **M₈ non-equilibrium CGLE** | edit dynamics violate detailed balance with measurable current | reversibility test passes, or absorbing-chain model explains the trajectory |
| **M₉ Grothendieck / SDP gap** | corpus-internal SDP-vs-integer gap differs from the curveball ensemble's and moves with N | gap ≈ 1.2 on real *and* null and constant in N ⇒ retire |

Note the shape this gives the next paper: **yubiOS's position is already computable** — S1/S2/S3/S8 are in this memo, and they place it at M₀-plus-M₄ (a two-population mixture with strongly bimodal row mass), with M₂ excluded. NIST/CIS/SCAP/GWTC then become points in the same space rather than four incommensurable narratives, and "PC2 anti-emerges on homogeneous rule catalogs" (L137/L142) becomes what it actually is: *corpora with unimodal row mass sit near the origin; corpora that pool two populations sit far from it.* That single sentence subsumes cycles 27–34's cross-corpus work.

---

## Q4. Where φ / Y₃³ fits — keep it, precisely scoped

**What it is:** a **sampling scheme plus a fixed basis element used as a diagnostic probe**, living entirely in the *curve-fitting* stage — downstream of PCA, downstream of the coverage matrix, and therefore downstream of everything in Q1–Q3. It is not a model of the corpus and never was.

**The three roles, kept:**
1. **Sampling scheme (keep, genuinely good).** Vogel's golden-angle Fibonacci lattice `z_i = 1 − (2i+1)/N, φ_i = 2πi/φ_golden` is a low-discrepancy, near-equal-area design on S² with O(1) index→point and no pole clustering. That is a real engineering property with a real literature (Vogel 1979, Saff–Kuijlaars 1997) and it is the right default for any S² quadrature or diagnostic grid. Keep the hard rules (canonical φ_golden, `i = t`, never substitute lat-long) — they are reproducibility hygiene and cost nothing.
2. **Basis choice (keep, frozen, unremarkable).** `Y₃³ = K sin³θ cos(3φ)`, K = √(245/64π), Condon–Shortley. One of the 16 real SH functions at L = 3. The 384 azimuthal lobes `m_k = 3k` are a **feature construction**, chosen by the analyst.
3. **Diagnostic probe (keep, but reinterpret).** Projecting onto Y₃³ measures **3-fold azimuthal power in whatever azimuthal ordering was fed in**. That is a legitimate diagnostic *of the ordering*, and it is the natural positive control for the synthetic-manifold benchmark (App C.3) — where it is used correctly, as an off-span target that the flat periodic basis provably cannot represent. That benchmark is the strongest piece of methodology in the whole corpus of work and should be the template for everything else.

**What it CANNOT claim — state these explicitly in the next paper:**

- **It cannot certify 3-fold symmetry in the corpus.** The azimuth φ_i is *assigned by construction* from the Fibonacci index, and the index order comes from PC1 rank. Power at cos(3φ) is therefore a property of the index map, not of the data. **Required guardrail: an ordering-permutation null** — shuffle row order, recompute the Y₃³ projection, and report the real value as a z-score against that ensemble. Until that is run, no azimuthal-structure claim is admissible.
- **PC1+PC2 = 1.0000 in the 384-D variant is a degeneracy, not a success.** 384 deterministic functions of a single scalar index produce a design matrix that is essentially rank-2 in the sampled directions; the ≥0.40 gate is uninformative there — it is passed by *any* smooth 1-D parameterization. Report the **condition number and numerical rank** of the design matrix instead, and treat "1.0000" as a red flag. (The same applies to the 7-D `refs` fit at exactly 1.0000.)
- **It cannot license any φ-numerology.** The golden ratio in the sampler has no relationship to κ, to pentagon geometry, to φ-shaped basins, or to 7/9. Cycle 34 already measured κ = 1.06 vs φ = 1.62 with no CI overlap. Close this line permanently.
- **It cannot identify the manifold.** S² was assumed, not inferred. The only evidence bearing on the choice is the T² negative control in App C.3 — keep that experiment, run it on a genus-2 control as well, and stop treating the S² win on yubiOS as manifold identification.
- **It has no bearing on Q1–Q3.** No result about the corpus's phase, class, or structure can be derived from the sampling scheme. Keeping φ/Y₃³ is fully compatible with abandoning GL.

---

## Five concrete experiments

### E1 — Null calibration battery *(run this first; everything else is conditional on it)*
- **Input:** all five binary matrices — yubiOS 2286×9, NIST 324×9, CIS 447×9, SCAP-SSG 2107×9, GWTC 138×9 (real PE samples, see flags).
- **Computation:** V_k, full spectrum, effective rank, MP-edge counts for the real matrix and for 4 nulls (iid matched-column, column-permutation, row-mass-only, curveball ×200). Report every published statistic as a z-score. Repeat the N-sweep with the null's own N-dependence subtracted.
- **Expected — GL/emergence:** real ≫ null, growing with N. **Expected — factor/mixture:** real ≈ null or below, flat in N. **Expected — pure null:** |z| < 2.
- **Kill criterion:** if |z| < 3 for V₂ against the curveball null, the words *emergence, phase transition, critical point, order parameter, saturation* are withdrawn from the program's vocabulary corpus-wide. ⟨new⟩ **Already met for yubiOS at z = −45.8 (wrong sign). Treat E1 as confirmation on the other four corpora.**

### E2 — Dimension-confound decomposition of the +0.4664 climb
- **Input:** the actual feature matrices behind the 5-dim library (7-D, 9-D, 16-D, 24-D, 384-D) at the 49 / 70 / 79 / 474 / 1091 / 1472 / 2286 snapshots, plus the three scoring protocols (keyword, manual, consensus-OR).
- **Computation:** V₂ on the full (feature-set × N × protocol) grid; variance decomposition / three-way ANOVA of V₂ across the three factors; report partial η² per factor.
- **Expected — GL:** N is the dominant term. **Expected — artifact:** feature-set dimension dominates and N is negligible.
- **Kill criterion:** if D explains > 50% of V₂ variance, the phase-transition reading of 0.2993 → 0.7657 is formally withdrawn and the GL ref entry is retracted to "vocabulary". ⟨new⟩ Proxy evidence already strongly favors the artifact branch (D = 24 → 0.2882 on identical rows vs the 0.2993 baseline).

### E3 — Latent-class model selection vs the whole landscape apparatus
- **Input:** the four compliance corpora.
- **Computation:** fit logistic PCA / Rasch (k = 1…5) and latent-class mixtures (k = 1…10); select by BIC and by bits/row (MDL). **Then simulate 200 corpora from the selected model** and re-run, on the simulated data, the exact cycle-27→34 pipeline: F_eff basin counter on PC1/PC2/PC3, 2-D archetype extraction, pentagon fit, K_PC ratios, type-I/II p-sweep.
- **Expected — genuine landscape structure:** simulated data fails to reproduce basin counts, archetypes, and K-hierarchies. **Expected — mixture:** simulated data reproduces all of them within CI.
- **Kill criterion:** if the mixture simulation reproduces basin counts and the K_PC2/K_PC1 hierarchy within CI, then all of L107/L111/L115/L120/L132/L133/L137/L142/L144/L146 reduce to "the corpus has k clusters", and the multi-well / archetype / pentagon program is closed.

### E4 — Persistence audit: basins and topology
- **Input:** PC scores and raw Hamming metric for all corpora.
- **Computation:** (i) bandwidth-persistence diagram for F_eff minima — sweep KDE bandwidth over a decade, record each well's birth/death and lifetime; (ii) persistent homology (β₀, β₁, optionally β₂) on the Vietoris–Rips complex over Hamming distance, real vs curveball null, with bottleneck distance between diagrams.
- **Expected — spin-glass/multi-well:** ≥ 2 wells with lifetime spanning a full decade. **Expected — topological/vortex:** β₁ persistent and clearly above null. **Expected — mixture/null:** every well dies within a factor-2 bandwidth change; β₁ null-consistent.
- **Kill criterion:** if no well survives a ×2 bandwidth change **and** the bottleneck distance between real and null persistence diagrams is within the null's own spread, retire *vortex, defect, vortex-glass, Abrikosov, archetype,* and *pentagon* permanently.

### E5 — Transfer operator on the edit log *(the one that tests dynamics)*
- **Input:** per-cycle coverage vectors from the 474-dispatch and 1391-dispatch atom runs, the 20-cycle re-fit experiment, cycles 4–34 snapshots, and git history with timestamps.
- **Computation:** empirical transition matrix on coverage states (and on the coarse variable k = coverage sum); maximum-likelihood generator; spectral gap and relaxation time; **detailed-balance / probability-current test**; and a reference **absorbing-chain model** built directly from the atom's deterministic geodesic policy (append-only flips, Δ(k) ladder from App A.3).
- **Expected — TDGL (potential):** reversible, current ≈ 0, relaxation set by a single gap. **Expected — CGLE (non-potential):** measurable current, complex generator spectrum. **Expected — no physics:** the absorbing chain alone reproduces the ΔV₂ and Δ-per-cycle trajectories, including the `refs/` cycle-2 rise (which App B.2 already explains by k-quantization).
- **Kill criterion:** if the absorbing-chain model reproduces the observed per-cycle Δ and V₂ trajectories within CI, the TDGL/CGLE framing is retired and "emergence over cycles" is restated as "an append-only improvement policy saturating a bounded coverage space".

---

## Flags for the orchestrator — needs user data or is too speculative

1. **Blocking for E2 (highest value):** I only had the 2286×9 consensus matrix. **Need the actual 24-D and 16-D and 384-D feature matrices** for the 49/70/79 snapshots (`papers/data/series/*/points.json`) to run the dimension-confound decomposition properly rather than by reconstruction. Ask the user for `papers/data/series/INDEX.json` and the per-dim `points.json`/`fit.json`.
2. **Blocking for E5:** need the per-cycle coverage-state sequences with timestamps — `papers/data/rsi-3-corpus-summary-2026-08-06.json`, `single-action-curve-rsi-cycles-2026-08-05.json`, and the cycle-18/19 per-row files (partially shipped). Without them the dynamics hole stays open.
3. **GWTC comparison is not currently admissible.** L141's 0.4003 is computed on a **synthetic 3-component mixture at median values**, not posterior samples (their own caveat #1). Any cross-domain LIGO claim should be suspended until real GWTC-4 PE samples are used — and even then, a 9-column *continuous physical parameter* matrix and a 9-column *binary coverage* matrix are not the same object; V₂ ≈ 0.40 there is unremarkable for correlated continuous data. Recommend the whole LIGO bridge (L136/L141/L144/L145) be re-scoped from "quantitative bridge" to "unrelated" unless E1 shows both corpora sitting in the same region of null-standardized s-space.
4. **Speculative, flagged as mine, not established:** the claim that the U-shaped row-mass distribution is *caused by* the atom loop saturating skills/docs/refs while `self` was left sparse. It is strongly consistent with the per-corpus bit-rates I measured (8.45 / 7.83 / 7.13 vs 1.77) and with App A.2's `c₁→c₆` saturation table, but I have not traced individual rows. Worth one confirmatory query before it goes in a paper.
5. **Speculative, low expected value:** the corpus-internal Grothendieck SDP gap (their open item #2). Include only if E1 leaves an unexplained residual, and only computed *with* a null ensemble. My prior: it returns ≈ 1.2 on real and null alike.
6. **Recommend permanent retirement, no further data needed:** φ ≈ κ, pentagon, nonagon, 7/9, and the 50-digit precision on 0.7656564170155055748523409 (the statistic has a bootstrap spread of ~0.01 and a null-model uncertainty larger than that; 25 significant figures on it is a category error and should be dropped from every document).

---

## Bottom line for the orchestrator

The program has been asking "is this X?" for eleven cycles and answering "PARTIAL" because it has never asked **"is this anything?"**. The answer, on the one corpus where I could check it with the shipped data, is: *not much, and less than chance.* That is not a failure of 34 cycles — it is the most decisive result the program has produced, and it is one afternoon of null-model computation away from being publishable as such. The next paper should be **the map Φ, the null-standardized s-space, and the exclusion table** — with yubiOS's own position (M₀ + two-population mixture, M₂ excluded) as the worked example, and the honest 24-vs-9-dimension story as the methodological centerpiece.

Keep φ/Y₃³ as the sampling and basis convention, with an ordering-permutation null attached to any azimuthal claim and a rank report replacing the 384-D gate.
