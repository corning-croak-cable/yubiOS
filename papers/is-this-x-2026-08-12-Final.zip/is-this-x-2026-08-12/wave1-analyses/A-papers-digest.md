# Deep Technical Digest — yubiOS `papers/` corpus
Source root: `/var/workspace/session/extracted/yubiOS-main (8)-d3da6d83/yubiOS-main/papers/`
Primary document: `learned-latent-curves-2026-08-06.tex` (629 lines, author Shant Tchatalbachian, title-page date 2026-08-06, body patched 2026-08-07 via PR #200).

NOTE: `/var/workspace/session/wave1/` is a read-only mount for this subagent; digest written here instead.

---

## A) Every primary equation, in LaTeX, with its role

**A1 — Flat learned latent curve (Eq. `eq:flat`)** — re-expands a 1-D ordering coordinate `t` into a D-dim embedding via a Fourier basis with *learned* frequencies. The base model of the whole family.
```latex
z_j(t) = a_{j,0} + \sum_{m=1}^{k}\big(a_{j,m}\sin(2\pi f_m t) + b_{j,m}\cos(2\pi f_m t)\big)
```

**A2 — Design vector (Eq. `eq:design`)** — the explicit feature map; stacking gives `\gamma(t) = C\phi(t)`, `C \in \mathbb{R}^{D\times(1+2k)}`.
```latex
\phi(t) = [\,1,\ \sin(2\pi f_1 t),\ \cos(2\pi f_1 t),\ \dots,\ \sin(2\pi f_k t),\ \cos(2\pi f_k t)\,] \in \mathbb{R}^{1+2k}
```

**A3 — Flat parameter count (Eq. `eq:paramflat`)** — capacity accounting for the ablation. At `D=384, k=8`: 6,528.
```latex
P_{\mathrm{flat}} = D\cdot(1+2k)
```

**A4 — Tikhonov ridge closed-form solve (Eq. `eq:ridge`)** — the coefficient solve at fixed frequencies; declared the "sanity floor" for any gradient fit. Used with `λ = 1e-3` everywhere in the operational regime.
```latex
C^{\star} = (\Phi^{\top}\Phi + \lambda I)^{-1}\Phi^{\top} Z
```

**A5 — Hyperspherical-harmonic curve (Eq. `eq:hyperspherical`)** — replaces the flat `[0,1]^2` parameter manifold with the Riemann sphere `S^2` plus a learned Möbius domain reparameterization. The paper's central model.
```latex
\gamma(\mathbf{x}) = \mathbf{b} + \sum_{\ell=0}^{L}\sum_{m}\mathbf{a}_{\ell,m}\,Y^{S^2}_{\ell,m}\!\big(\phi_\theta(\mathbf{x})\big)
```
Parameter count: `D\cdot n_{basis} + D + n_{Möbius}`, `n_{basis} = \sum_{\ell=0}^{L}(2\ell+1) = 16` at `L=3`; at `D=384`: `P_sphere = 384·16 + 384 + 6 = 6,534`.

**A6 — Möbius reparameterization, PSL(2,C)** — the learned domain warp; 8 real components minus the *complex* constraint (2 real DOF) = **6 real DOF**; the `M ~ -M` identification is discrete and removes none.
```latex
\phi_\theta(z) = \frac{az+b}{cz+d},\qquad a,b,c,d\in\mathbb{C},\qquad ad-bc = +1
```
Refinement claimed via L-BFGS-B with A4 re-solved each step; cross-ratio invariance is used only as an implementation-consistency check (it holds identically for any element of PSL(2,C)).

**A7 — Fibonacci (Vogel golden-angle) sphere sampling** — makes the corpus index *be* the parameter (`i = t`), O(1) per point, no pole clustering.
```latex
z_i = 1 - \frac{2i+1}{N},\qquad \phi_i = 2\pi\frac{i}{\varphi},\qquad \theta_i = \arccos(z_i),\qquad \varphi = \frac{1+\sqrt5}{2}
```

**A8 — `Y_3^3` real angular probe (Condon–Shortley)** — the native basis of `rsi-phi-skill`; `\sin^3\theta` vanishes at the poles and peaks at the equator, `\cos(3\phi)` folds in 3-fold rotational symmetry.
```latex
\Re\{Y_3^3(\theta,\phi)\} = K\,\sin^3\theta\,\cos(3\phi),\qquad K = \sqrt{\frac{245}{64\pi}}
```
(paper glosses this as `K = \sqrt{(35\cdot 7)/(64\pi)}` — **this constant is wrong, see §E1**).

**A9 — 384-lobe per-item basis vector** — the extension of A8 to 384 symmetric azimuthal lobes, `m_k = 3k`, `k = 1..128` (`384 = 2^7·3`).
```latex
b_i = \big(\sin^3\theta_i\cos(m_1\phi_i),\ \dots,\ \sin^3\theta_i\cos(m_{384}\phi_i)\big)
```

**A10 — Stereographic lift (Eq. `eq:stereographic`)** — takes the PCA top-2 coordinates of a file's section-coverage matrix to a single point on `S^2`. (Source has a stray `$` inside the equation environment — a LaTeX bug.)
```latex
\sigma(u,v) = \frac{1}{1+u^2+v^2}\big(2u,\ 2v,\ u^2+v^2-1\big)\in S^2
```

**A11 — Atom aggregate coverage vector** — weighted section aggregation, thresholded at 0.5, over the 9-D binary primitive basis.
```latex
c = \sum_i w_i c_i,\qquad w_i = \frac{\mathrm{len}(\mathrm{section}_i)}{\mathrm{len}(f)},\qquad c_i \in \{0,1\}^9
```

**A12 — Geodesic gap and the geodesic-only criterion** — chordal proxy on `S^2` to the ideal pole `p^* = \sigma(\bar u^*,\bar v^*)` (lift of the all-ones coverage vector); the selected action is the single missing-primitive flip minimizing post-flip distance.
```latex
d(f) = \|p - p^*\|_2,\qquad i^{*} = \arg\min_{i\in\{j:\,c_j=0\}} d_{\mathrm{post}}(f)
```

**A13 — Lemma 1 (atom invariant)**
```latex
\Delta_f = d_{\mathrm{pre}} - d_{\mathrm{post}} \geq 0
```

**A14 — Theorem 1 (linear composition, Eq. `eq:composition`)**
```latex
\Delta_{\mathrm{corpus}} = \sum_{i=1}^{N}\Delta_{f_i}
```

**A15 — Corollary 1 (cumulative monotonicity)**
```latex
\Delta^{(n)}_{\mathrm{corpus}} = \sum_{c=1}^{n}\sum_i \Delta^{(c)}_{f_i},\qquad \Delta^{(n+1)}_{\mathrm{corpus}} \ge \Delta^{(n)}_{\mathrm{corpus}}
```
Explicitly: no shape constraint on the per-cycle increment.

**A16 — The concentration gate (prose, not numbered)**
```latex
\mathrm{PC1}+\mathrm{PC2} \ \ge\ 0.40
```

**A17 — Synthetic-benchmark targets (Appendices C.3 / D)**
```latex
T^2_{\text{v4}} : \ \sin\theta + 0.5\cos\phi + 0.3\sin(\theta+\phi)
\qquad
S^2_{\text{v4}} : \ \cos^3(\mathrm{lat})\cos(3\,\mathrm{lon}) + \epsilon,\ \epsilon\sim\mathcal N(0,0.01^2)
```
```latex
T^2_{\text{FixA}} : \ \sin\theta\cos\phi + 0.5\sin(2\theta)\cos(2\phi)
\qquad
S^2_{\text{FixA}} : \ \sin^3(\theta_c)\cos(3\phi)
```

### Headline empirical numbers (main body)
| Item | Value |
|---|---|
| 49-item ablation | sphere `R²_hold = +0.618`; flat `−0.359`; δ = **+0.977** |
| 70-item ablation | sphere `+0.222`; flat `−1.120`; δ = **+1.342** |
| Phases A→H (cycles 5–9, 70→73 skills) | sphere `−0.5021 → +0.2534`; flat `−0.4588 → −0.4231`; 5-seed ±std for E–H only |
| 79-skill atom run | 474 dispatches, 6 cycles, Δ = **+11.2963** (unrounded +11.2971), 116 positive, 358 zero, **0 negative** |
| Multi-corpus | 1,391 dispatches / 213 files / Δ = **+59.7671**, 0 negative |
| 20-cycle deep-research | 11 files, 20 cycles, "cumulative Δ = +1.6882", 0 negative |
| Synthetic v4 (50 seeds) | T²: sphere `+0.9814±0.0110` vs flat `+1.0000±0.0000`, p=3.87e-16; S²: sphere `+0.9995±0.0001` vs flat `−0.0825±0.0840`, p=2.47e-56 |
| Manifold-coord Fix A (10 seeds) | T²: sphere `+0.4572±0.1425` vs flat `+0.7790±0.0586`, t=−8.747, p=5.4e-6; S²: sphere `+1.0000±0.0000` vs flat `−0.1101±0.0633`, t=+52.628, p=8.1e-13 |

### Appendix contents (A–E)
- **A — Atom coverage of 79 skills.** Per-cycle Δ `+5.5787 → +3.0091 → +1.2833 → +0.8829 → +0.5423 → 0`; positive dispatches `59 → 30 → 12 → 9 → 6 → 0`; sparse cells `7 → 3 → 2 → 3 → 0 → 0` (non-monotone, flagged as allowed). Coverage vectors c₁..c₆ (order: attestation, trust_chain, least_privilege, declarative_policy, continuous_adaptive, immutability, audit_evidence, cryptographic_identity, segmentation); `continuous_adaptive` starts 35/79 and takes 44 of 116 winning flips; `cryptographic_identity` closes last. **Δ-vs-k ladder:** k=1→0.0904, 2→0.1003, 3→0.1098, 4→0.1175, **5→0.1206 (max)**, 6→0.1158, 7→0.0989, 8→0.0678, 9→0.0242.
- **B — Multi-corpus RSI audit.** `skills/` 79/6/474/+11.2963; `docs/` 21/6/126/+5.5410; `refs/` 113/7/791/+42.9298. Differential baselines (Δ per file per cycle); `refs/` **rises** at cycle 2 (0.0881→0.1061), explained by the k-ladder. Three transferring properties: Δ ladder, peak-Δ termination sequence, `cryptographic_identity` as universal laggard. Explicit scope caveat: does not strengthen the headline ablation.
- **C — 20-cycle deep-research corpus + synthetic-manifold benchmark.** 11 files, 20 cycles (12 sweep + 8 post-edit re-fits), peak-run trace `+0.3092 → +0.2705 → +0.1872`, per-file reductions (advisor-report −55.7%, pkcs11-ecdsa-deepdive −66.6%, pkcs11-ecdsa-VERIFIED −47.5%, prior-art-V52 −43.4%, comparative-report −100%). C.3 = v4 controls (N=200/manifold, 50 seeds, per-arm λ sweep logspace(−6,1,29), 60/20/20 splits, 16 functions/arm) with a full v1/v2/v3 post-mortem (v3's S² win was a paired-t on `np.linalg.solve` round-off; v1 had PCA leakage, fixed λ=1e-3 mis-conditioning, one −7.35 outlier seed).
- **D — Manifold-coordinate benchmark (rigorous re-test).** Fix A partial-in-span design at the smaller flat K=2 basis (rank 9 effective; 7 identically-zero columns), 10 seeds, 5-fold train-only inner CV over `{1e-4..1e0}`, lstsq floors verified at N=4000 (T²: flat 0.8001 / sphere 0.5775; S²: sphere 1.0000 / flat 0.0022). Both predictions confirmed; explicit admission that without Fix A the sphere wins T² by capacity alone.
- **E — Use-cases gallery.** Full-corpus curve map, cycle-3 refs re-map, 384-D curve map, multi-corpus map (2286 sections across skills/docs/refs/self), drift detection (aligned curves / points / series-aligned curves), the 5-dim keystone diagram, per-dimension fit plots, and **Table E.1 — the five-dimension concentration gate**.

---

## B) The dimension ladder

| Dim | Basis definition | N | PC1 / PC2 | PC1+PC2 | Gate ≥0.40 | Median residual (chordal, [0,2]) | Cycle/time-series info in fit.json? |
|---|---|---:|---|---:|:---:|---:|---|
| **7-D** | `repo-refs-skill` 7 binary doc primitives (has_problem_statement, has_recommendation, has_evidence, has_cross_reference, has_verification_plan, has_source_citation, has_priority_signal) on `refs/*.md` only | 1862 | 0.9536 / 0.0464 | **1.0000** | PASS ("boundary / floor case, not evidence") | 0.001707 (max 0.7609) | No — only dimension + corpus label; INDEX.json has one global timestamp `2026-08-07T21:35:00Z` |
| **9-D** | `internal-big-picture` 9 binary security primitives over self+docs+refs sections | 2286 | 0.2657 / 0.1908 | **0.4565** | PASS | 0.2829 (max 1.6830) | No |
| **16-D** | 16 real spherical harmonics (SH `L=3`) evaluated at each item's S² point | 2286 | 0.2995 / 0.1633 | **0.4627** | PASS | 0.0372 (max 0.7283) | No |
| **24-D** | 9-D + 12 NSS axes (audience, inputs, outputs, mode, assumption_set, adjacent_problems, failure_modes, lifecycle, composition, knowledge_sources, calibration, recursion) + 3 meta (`size_log`, `age_log`, `is_rsi`) | 2286 | 0.1768 / 0.1224 | **0.2993** | **FAIL** | 0.4969 (max 1.7733) | No |
| **384-D** | Fibonacci-sphere `sin^ℓθ·cos(mφ)`; 3 variants | 2610 | — | native **0.0156** / variant1 (ℓ=128) **0.6667** / **chosen variant2 (ℓ=384,m=3,sin³⁸⁴) 1.0000** | PASS via chosen variant | 0.0473 canonical (max 1.8071) | No cycle series; does store sampling scheme, native basis, all 3 variant scores, skill credit |

All five `fit.json` store `ridge_lambda=0.001`, `basis_L=3`, `basis_size=16`, `fit_method="closed-form ridge on real SH basis (L=3, 16 fns)"`, `distance_metric="chordal S² (bounded [0,2])"`, a 16×3 `gamma_coefficients_L3_16`, and per-item slugs. `points.json` = `{slug, p, t, residual}`; `curve.json` = 360 sampled points. **None stores per-cycle history** — the "5-dim time-series library" is a five-*dimension* snapshot library, not a temporal series.

### Why 24-D fails and 384-D saturates — my mathematical reading

Gate = `(λ₁+λ₂)/tr(Σ)`. Define effective rank `r_eff ≈ 2/(PC1+PC2)` (exact for a flat top-r spectrum):

| Dim | PC1+PC2 | r_eff | flat-spectrum floor 2/p |
|---|---:|---:|---:|
| 7-D | 1.0000 | **2.00** | 0.286 |
| 9-D | 0.4565 | 4.38 | 0.222 |
| 16-D | 0.4627 | 4.32 | 0.125 |
| 24-D | 0.2993 | **6.68** | 0.083 |
| 384-D native | 0.015631 | **127.95** | 0.0052 |
| 384-D variant1 | 0.666667 | **3.00** | — |
| 384-D variant2 | 1.0000 | **2.00** | — |

So the gate `PC1+PC2 ≥ 0.40` is exactly **`r_eff ≤ 5`**. Three consequences:

1. **7-D and 384-D "passes" are rank artifacts.** `2/128 = 0.015625` vs measured native 384-D `0.0156309` — effective rank ~128, i.e. exactly the 128 distinct azimuthal modes `m = 3k`, with a near-uniform spectrum. Variant1 gives `2/3 = 0.6666…` vs measured `0.6666666666668841` — rank exactly 3. Variant2 gives 1.0000 — rank exactly 2 (one azimuthal mode under a fixed polar profile spans a 2-D column space, so two PCs explain everything *by construction*). 7-D sums to exactly 1.0000 (0.9536+0.0464) — the surviving coverage matrix on `refs/` is rank 2. All computable without looking at the corpus. **The gate rewards basis degeneracy.**
2. **24-D fails by ordinary trace dilution, and is the only genuinely informative rung.** 9-D→24-D adds 12 near-independent low-variance binary NSS axes plus 3 *continuous* meta features. Under z-scoring `tr(Σ)=p`, so pure dilution predicts `0.4565 × 9/24 = 0.171`; measured 0.2993 is higher (the new axes do load somewhat on the leading plane) but `r_eff = 6.68 > 5`. Mechanistically the binary primitive columns are strongly correlated because they are all driven by one latent "total coverage" direction — visible in the atom data, where `d_pre` is a function of `k` alone (1.2451 at k=1, 1.3454 at k=2, 1.9758 at k=8, identically across files). That direction plus one contrast is what makes 9-D concentrate. NSS axes are qualitative and orthogonal *by design*, and `size_log`/`age_log` are heavy-tailed continuous variables unrelated to coverage. The concentration was a property of the correlated binary block, not of `S²`.
3. **9-D and 16-D are not independent measurements.** 16-D features are SH values evaluated at each item's S² point, and that point is a deterministic function of the 9-D PCA top-2 — a 16-function smooth re-encoding of a 2-D statistic derived from 9-D. `0.4627 ≈ 0.4565` is expected by construction, not evidence that the harmonic basis "neither helps nor hurts". No test, CI, or seeds back the "statistically indistinguishable" claim.

Honest ladder: **9-D 0.4565 (real), 16-D 0.4627 (derived), 24-D 0.2993 (real, informative negative)**; 7-D and 384-D are degenerate-rank endpoints. Also, "corpus held fixed, only the basis changes" is false: N = 1862 / 2286 / 2286 / 2286 / 2610.

---

## C) Lemma 1 / Theorem 1 / the 474-dispatch atom experiment

**Lemma 1 (atom invariant).** *For any file `f` and any action `α` selected by the geodesic-only criterion, `Δ_f = d_pre − d_post ≥ 0`.* Proof as printed: argmin over the `k` missing-primitive candidates; "if all k candidates had `d_post ≥ d_pre` the argmin would tie at `d_pre`"; action space append-only.
**Status: empirically unfalsified across 1,391 yubiOS + 124 synthetic dispatches; the printed proof is invalid.** The argmin ranges over flip candidates only and does not include the null action, so nothing forces a tie at `d_pre`; if every flip increased distance, `Δ < 0`. What actually saves it is an unstated monotonicity: with the ideal pole = lift of the all-ones vector and coverage entering only through `k`, any 0→1 flip moves toward `p*`. A follow-up must reprove it or restate it as an empirical regularity.

**Theorem 1 (linear composition).** `Δ_corpus = Σᵢ Δ_{f_i}`, non-negative if every atomic Δ is, strict if any is strict; proof by per-file independence.
**Status: true but trivial** — additivity of independent per-file scalars. Not empirically testable, so the abstract's "confirming Lemma 1 and Theorem 1 directly" only applies to Lemma 1. Its independence premise survives only because the corpus-level Möbius is **frozen** (refine-once); joint-refine-per-cycle is reserved for `N_items < 30` or corpus growth > 25%.

**Corollary 1.** Running totals non-decreasing; per-cycle increment unconstrained (this licenses the `refs/` cycle-2 rise). Also trivial.

**The 474-dispatch experiment.** 79 skills × 6 cycles, `skills/` on `yubi-OS/yubiOS main`, snapshot 2026-08-06, commit `6ae3abeb65`. **0 negative, 116 positive, 358 zero**, Δ = +11.2963 published / +11.2971 unrounded (I re-summed all 474 records: **11.2971 ✓**). Fixpoint at cycle 6 (peak Δ < 0.001). Terminal coverage 79/79 on all nine primitives. Winner counts verified from the JSON: continuous_adaptive 44, declarative_policy 22, trust_chain 16, least_privilege 16, attestation 8, cryptographic_identity 8, immutability 1, audit_evidence 1 — **matches the paper exactly**. Max single-dispatch Δ = 0.1206 at k=5.
Caveats not drawn: **75.5% (358/474) of dispatches are structural no-ops**, so the invariant is exercised on 116 cases; and the data only reaches k=8 (0.0678) — **the paper's k=9 → 0.0242 rung does not occur in this corpus**.

---

## D) The fractalrabbit falsification harness

Self-contained harness reimplementing NSA `fractalrabbit` (Darling 2018, DOI 10.13140/RG.2.2.15267.40489; three tiers: Agoraphobic Point Process, Retro-preferential Process, Sporadic Reporting Process) in Python (no Java/Maven in sandbox; the Java CLI can't expose per-observation features for anomaly planting). Apache 2.0. It runs the `single-action-curve-rsi` pipeline (9-D coverage → PCA top-2 → stereographic projection from the **south** pole → chordal atom + 0.05×0.05 sparse-cell grid) on a synthetic, non-yubiOS corpus.

Three gated tests: **T1 basic_fit** (`PC1+PC2 ≥ 0.40`), **T2 sparse_cell_recovery** (plant 10 anomalies, recover ≥ 80% — the falsification test for the prioritization lens), **T3 lemma_1_invariant** (zero negative Δ).

**Seed-42 headline (`results.json`):** 124 observations; only **4 of 9 primitives survived** (dropped p1_is_recurrent, p2_is_first_visit, p3_near_fract_limit, p5_inter_event_short, p6_origin_proximity; three columns at 0.0 coverage, two at 1.0). T1 pass (0.3752 + 0.2538 = 0.6291). T2 pass at **exactly** 8/10 = 0.80 = threshold. T3 pass (124/124 strictly positive, 0 violations). `overall_passed: true`, 0.078 s.

**10-seed sweep:** `t1_pass_rate = 1.0` (mean 0.6703); `t2_pass_rate = 0.4` (recoveries 0.0, 0.5, 0.8, 0.8, 0.5, 0.7, 0.8, 0.8, 0.6, 0.0; mean **0.55**); `t3_pass_rate = 1.0` (0 violations on every seed); `overall_pass_rate = 0.4`.

**Verdict.** *Falsified:* the **sparse-cell recovery / prioritization-lens claim** — fails its own 0.80 gate on 6/10 seeds including two total failures (0.0), and the published single-seed pass clears only by exact equality. *Survived:* **Lemma 1** (100% of seeds, zero negative Δ, under a completely different generative model — the strongest independent support the invariant has) and the gate as an achievable fit criterion (10/10). **The main paper never cites this harness anywhere.**

---

## E) Skeptical review — inconsistencies, suspicious numbers, unproven claims

**E1. `K = √(245/(64π))` is wrong.** Complex `Y_3^3`: `√((2ℓ+1)/(4π)·(ℓ−m)!/(ℓ+m)!)·|P_3^3| = 15·√(7/(2880π)) = √(35/(64π)) ≈ 0.4172`; orthonormal real form `√(70/(64π)) ≈ 0.5900`. The paper's `√(245/(64π)) ≈ 1.1039` is √7× the complex constant. Its own gloss `√((35·7)/(64π))` reveals the bug: `(2ℓ+1)=7` is already inside 35/64 and has been multiplied twice. `playbooks/rsi-regime.md` enshrines the wrong value as **Hard Rule #2**. Scale-only (doesn't change PCA ratios) but a published Methods error.

**E2. Lemma 1's proof is logically invalid as written** (see §C).

**E3. The Möbius reparameterization is never actually learned.** §3.2 claims L-BFGS-B refinement; Appendix B says "`φ_θ` frozen at identity"; §4.5 says all reported runs use "refine-once, frozen"; the playbook says "Identity-init Möbius … **FROZEN — no L-BFGS-B refinement**". Yet the abstract and conclusion both claim the model "learns a Möbius reparameterization `φ_θ ∈ PSL(2,C)`". On reported evidence PSL(2,C) contributes 6 unused parameters and the identity map. No with/without-Möbius ablation exists.

**E4. "Matched-parameter ablation" is not matched.** Sphere 6,534 vs flat 9,984 (`384·25+384`). Honest about "fewer parameters", but "capacity-matched"/"matched-parameter δ" are misnomers; Appendix D separately notes the flat arm's *effective* rank is far below nominal.

**E5. Cited data files don't exist / don't match.** The tex cites `manifold-coord-benchmark-results-v3.json`; only `manifold-coord-benchmark-results.json` exists, whose `version` field reads **"v2 — designed after advisor critique of PR #192"**. Its per-seed values *contradict* Appendix D: T² sphere ≈ 0.50–0.83 (not 0.4572), T² flat ≈ 1.0000 (not 0.7790), and **S² both arms ≈ 0.99999999** — exactly the round-off regime v4 supposedly fixed, not sphere 1.0000 / flat −0.1101. **No file in the repo backs Table D.1.** `chart-synthetic-manifold-v4-2026-08-06.png` (Figure C.2) is **absent from `charts/`** — the tex will not build as committed.

**E6. The 20-cycle numbers don't reconcile with their source.** `single-action-curve-rsi-cycles-2026-08-05.json` sums to **2.1826**; the paper reports "+1.6882". Cycles 1–12 sum 1.4107 (mean 0.1176 ✓), but 13–20 mean **0.0965**, not 0.0844 — "mean Δ fell 28.2%" is unreproducible. "Seven post-edit re-fits" vs Figure C.1's "cycles 13–20" (= eight). The JSON stores only `{cycle, d_pre, d_post, delta_d}` — **no file identities** — so every per-file claim in C.2 is unverifiable. `d_pre = 1.0` on all 20 cycles is itself suspicious.

**E7. `rsi-85-corpus-multi-cycle-2026-08-07.json` is a relabel, not a run.** Declares 85 items / 480 records, but per-cycle Δ, sparse cells, coverage vectors (still capped at **79**), winner distribution and total Δ (11.2971) are byte-identical to the 79 corpus; the 6 added skills (`continuous-runtime-detection-falco`, `least-privilege-pod-security-standards`, `parallel-deep-research`, `repo-history-skill`, `repo-refs-skill`, `runtime-attestation-keylime`) all carry Δ = 0. Its `_note` admits this. Citing an "85-skill corpus" would double-count.

**E8. `INDEX.json` contradicts everything else on what 384-D is** — it defines 384-D as *"384-D TF-IDF vector (sklearn TfidfVectorizer, n_features=384, 1-2 grams, English stopwords)"*, while `fit.json`, the paper, the playbook and the refs all say Fibonacci-sphere `sin^ℓθ·cos(mφ)`. The playbook calls `curve-map-output-384d/` the "384-D TF-IDF curve map (legacy)" — and Figure E's 384-D map is drawn from that directory.

**E9. The 384-D variant selection violates its own hard constraint.** Hard Rule #3 / Constraint #5 mandates testing `(ℓ=128, m=256)` and `(ℓ=256, m=128)`. What was tested: native `(ℓ=3, m=3..384)`, `(ℓ=128, m=3..384)`, `(ℓ=384, m=3)` — **none is either mandated ordering**, yet the main-body Remark repeats the mandated language and then reports `(ℓ=384, m=3)` as "the chosen variant".

**E10. Choosing the basis by maximizing the gate is circular.** Sweep variants, keep the highest PC1+PC2, then cite PC1+PC2 as evidence the manifold structure is real. Since PC1+PC2 = 2/r_eff, the search is a search for the most degenerate basis, and 1.0000 is its saturation point. Calling it "the strongest evidence that the concentration is driven by the spherical inductive bias rather than by the particular 9 primitives" inverts the inference.

**E11. `d_pre` is a function of `k` alone — collapsing the whole S² apparatus.** Every file with the same missing count has identical `d_pre` and Δ regardless of which primitives or which file (1.2451/1.3454/…/1.9758). The paper states this as a feature; it is a diagnosis: the PCA+stereographic pipeline discards directional information and reduces to a monotone function of coverage count. If so, the geodesic-only criterion is equivalent to "flip any missing primitive", the sphere is decorative for the atom, and the winner distribution is set purely by column sparsity — contradicting the paper's claim that "the criterion minimizes post-flip geodesic distance, not per-column deficit".

**E12. Two inconsistent statements of the gate.** §2.3 "PC1+PC2 … ≥ 0.40" vs §5.1 "both clear the **PC1 ≥ 0.40** gate". The 0.40 threshold is never justified anywhere — no derivation, no power analysis, no citation.

**E13. Corpus bookkeeping is inconsistent.** Appendix B: `refs/` = 113 files, `docs/` = 21. `INDEX.json`: refs 1862, docs 310, self 114. `self+docs+refs = 2286`, so the "**4 corpora** (2286 sections)" label actually covers **three**; the fourth (`cycle4`, 324) appears only in the 2610-item 384-D run — meaning 384-D is fit on a *different corpus*, invalidating the series-aligned-curves premise. Separately, "grew by an order of magnitude" conflates files (213) with sections (2286).

**E14. Cycle numbering conflicts.** Appendix B: the 79-skill audit used "cycles **10–15**"; §6.3/Appendix A call the same run cycles **1–6**. §6.2's phases A–H are "cycles 5–9" on a "70→73-skill corpus" that appears nowhere else.

**E15. Figure 2 mislabels its own series.** `+5.5787 → … → 0` are per-cycle *increments* (they sum to 11.2963), but both the caption and the JSON key call them `cumulative_delta_per_cycle`.

**E16. The v4 "negative control" is a tautology.** Flat scores `+1.0000 ± 0.0000` on T² — the target is exactly in its span, structurally the same in-span triviality the paper criticizes in v3. A control whose winner interpolates exactly measures span membership, not topology (half-admitted: "a noisier or higher-mode T² target is the natural next step").

**E17. C.3 and D contradict each other on the flat arm's rank.** C.3 describes a 16-function tensor of `{1,sinθ,cosθ,sin2θ}×{1,sinφ,cosφ,cos2φ}` — no zero columns, rank 16. D asserts C.3's flat basis is "rank 9 effective at K=2" with 7 zero columns. Both cannot hold, and D's entire capacity-confound argument turns on which does.

**E18. Statistics asserted without tests.** "statistically indistinguishable" (no test, N=2286, one fit each); "a margin hard to attribute to noise" for single-seed δ with explicitly no error bars; "stable under a corpus that grew by an order of magnitude" (visual assertion from two PNGs, no alignment metric).

**E19. Residual quality invisible in the main text.** 9-D median chordal residual **0.283** (max 1.683) on a metric bounded in [0,2] — ~14% of full range at the median; 24-D 0.497. The body reports only PC1+PC2, so a reader never learns the curve fits poorly at the headline dimension.

**E20. Provenance gaps.** Title date 2026-08-06 with §3.3 admitting 2026-08-07 content (disclosed); the PDF was regenerated with **pandoc 2.14.0 because pdflatex is unavailable**, so the committed PDF is not a LaTeX render of the committed tex; only 2 of the 4 cited y33 artifacts exist under `papers/refs/`; the k=9 rung is absent from the data; and Eq. `eq:stereographic` has a stray `$` inside `\begin{equation}`.

**E21. The falsification harness's own result is suppressed** — a 0.4 overall pass rate on the prioritization claim sits in the repo and is cited nowhere.

**E22. `refs/` cycle-1 red flag.** `repo-refs-skill-cycle-1-fit-2026-08-07.json` records a **50.8% sparse-cell rate**, tripping its own rule ("> 50% → re-derive basis via NSS"), caused by two primitives at 100% coverage dominating PCA; the fix was dropping them (9-D → 7-D). Same pathology as E10 — and it produced the very 7-D basis whose PC1+PC2 = 1.0000 is later reported as a gate pass.

---

## F) The 10 most load-bearing facts a follow-up paper must not contradict

1. **The geometry stack is fixed and frozen:** 9-D binary coverage → z-score/PCA top-2 → stereographic lift → **identity Möbius, 6 real DOF, not refined** → real SH `L=3`, 16 functions → closed-form ridge `λ = 1e-3` → **chordal** `S²` distance bounded in [0,2]. Reporting a *learned* `φ_θ` is a new experiment, not this one.
2. **Lemma 1 holds empirically over 1,391 yubiOS + 124 synthetic dispatches with exactly zero negative Δ; Theorem 1 is an algebraic identity conditional on `φ_θ` frozen across dispatches.** The invariant must not be contradicted; the (invalid) proof may be rewritten.
3. **The 474-dispatch result:** 79 × 6, 116 positive / 358 zero / 0 negative, Δ = +11.2963 published (+11.2971 unrounded, re-verified), fixpoint at cycle 6 under peak-Δ < 0.001, terminal coverage 79/79, snapshot 2026-08-06 / commit `6ae3abeb65`.
4. **Multi-corpus totals:** `skills/` 79/6/474/+11.2963, `docs/` 21/6/126/+5.5410, `refs/` 113/7/791/+42.9298 → 213 files, 1,391 dispatches, Δ = +59.7671, all three at 100% coverage under the same fixpoint rule. `refs/` peaks at cycle 2 (+11.9840), permitted by Corollary 1.
5. **The Δ-vs-k ladder is unimodal with maximum 0.1206 at k = 5**, identical across `skills/`, `docs/`, `refs/`; `cryptographic_identity` is the last primitive to saturate in every corpus.
6. **Gate = `PC1+PC2 ≥ 0.40`**, and the ladder is **7-D 1.0000 (N=1862), 9-D 0.4565 (N=2286), 16-D 0.4627 (N=2286), 24-D 0.2993 FAIL (N=2286), 384-D 1.0000 via `(ℓ=384, m=3, sin³⁸⁴ polar)` (N=2610)**, with the other 384-D variants at 0.0156 (native) and 0.6667 (ℓ=128). 24-D is the only failing dimension and is 9-D + 12 NSS + 3 meta.
7. **The headline ablation is two single-seed point estimates with no error bars:** 49-item δ = +0.977 (+0.618 / −0.359) and 70-item δ = +1.342 (+0.222 / −1.120), sphere 6,534 params vs flat 9,984. The paper's own open item — **a second-corpus re-run of the ablation** — has not been done, and Appendices B–D do not close it.
8. **The synthetic controls are the only inductive-bias evidence, and both are span-membership experiments:** v4 (50 seeds) T² flat +1.0000 vs sphere +0.9814 (p<1e-15), S² sphere +0.9995 vs flat −0.0825 (p<1e-55); Fix A (10 seeds) T² flat +0.7790 vs sphere +0.4572 (p=5.4e-6), S² sphere +1.0000 vs flat −0.1101 (p=8.1e-13); lstsq floors 0.8001/0.5775 and 1.0000/0.0022. The v1/v2/v3 retractions (leakage, λ mis-conditioning, round-off-scale statistics) must not be quietly reversed.
9. **Fibonacci/`Y_3^3` operationalization:** `z_i = 1 − (2i+1)/N`, `φ_i = 2πi/φ_golden`, `θ_i = arccos(z_i)`, `φ_golden = (1+√5)/2`, `i = t` with no lookup table; 384 lobes as `m = 3k, k = 1..128` (`384 = 2⁷·3`); real probe `K sin³θ cos(3φ)`. **The published `K = √(245/(64π))` is wrong (should be `√(35/(64π))` complex, `√(70/(64π))` real-orthonormal) — correct it explicitly, since the playbook enshrines it as a hard rule.**
10. **The fractalrabbit verdict stands:** T1 10/10, **T3 (Lemma 1) 10/10 with zero violations**, T2 (sparse-cell recovery) **4/10, mean recovery 0.55, overall pass rate 0.40**. Lemma 1 survived an independent generative model; the sparse-cell prioritization lens did not. Marketing sparse cells as a validated gap detector contradicts data already in this repo.

---

### Files read
`learned-latent-curves-2026-08-06.tex` (full) · `playbooks/rsi-regime.md` · `playbooks/papers-8-6-iteration-2026-08-07.md` · `refs/rsi-phi-skill-deep-research-2026-08-07.md` · `refs/y33-fibonacci-sphere-applied-2026-08-07.md` · `appendix-D-manifold-coord-2026-08-06.md` · `data/series/INDEX.json` + all five `<dim>/<dim>/{fit,points,curve}.json` · `fractalrabbit-falsification/{README.md,results.json,multi_seed_results.json,falsification_harness.py}` · `data/{rsi-79-corpus-multi-cycle-2026-08-06, rsi-85-corpus-multi-cycle-2026-08-07, single-action-curve-rsi-cycles-2026-08-05, rsi-3-corpus-summary-2026-08-06}.json` · `data/repo-refs-skill-cycle-{1,2,3}-fit-2026-08-07.json` · `data/manifold-coord-benchmark-2026-08-06/manifold-coord-benchmark-results.json`
