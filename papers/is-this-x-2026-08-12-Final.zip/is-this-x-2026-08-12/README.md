# Wave-2 bundle — corrected record, Hodge channel, standard-candle skill, IS-THIS-X map

**Generated 2026-08-12.** This is the successor deliverable to the wave-1 memos. It
carries four things:

1. **The corrected record.** The wave-1 curveball null for the yubiOS 2286×9
   coverage matrix (0.8005 ± 0.0017, z = −45.8) does **not** reproduce and its sign
   is wrong. The corrected fixed-margin null is **0.7089 ± 0.0014**; the real matrix
   sits **above** it at **ΔV₂ = +0.0144, z ≈ +12.3**. Two independent provably-uniform
   samplers agree. The Y₃³ constant and the "N_c ≈ 40 critical point" are corrected
   here too (see the corrections table below).
2. **The Hodge channel.** Combinatorial Hodge decomposition of the A1 dominance flow
   on four graph constructions, with two nulls (matrix-level curveball and
   degree-rewired graph). Headline: ρ_grad = 0.9996 and the corpus is far *less*
   cyclic and *less* holey than its degree-matched null (β₁ z = −312.5). All three
   pre-stated Hodge predictions are falsified in the form stated; the falsification
   is the result.
3. **The standard-candle skill.** `curved-corpus-create` v1.0.0 — generates corpora
   with prescribed curvature, matched nulls, a calibration pack (power + FPR +
   detection threshold), and the IS-THIS-X placement map with exclusion-only
   verdicts. Its selftest is the regression gate for everything above.
4. **The IS-THIS-X map.** Sufficient-statistic placement of any N×d binary matrix
   against generated reference families, with `excluded` / `not-excluded` /
   `not-tested` verdicts and no "compatible with" language.

Every number in `proofs/PROOFS.md` is machine-produced and cites the artifact it
came from. Where a wave-1 claim failed to reproduce, that is recorded as a failure,
not silently replaced.

---

## How to verify

```bash
bash proofs/VERIFY.sh
```

Runs from any working directory (paths resolve relative to the script). Requires
`bash` and a `python3` with `numpy` and `scipy`; ~15 s single-core, well under the
5-minute budget. Exit code 0 iff all four checks pass.

| check | what it asserts |
|---|---|
| 1 | `curved-corpus-create --selftest` exits 0 (SELFTEST GREEN, 7 blocks) |
| 2 | V₂ recomputed from the master matrix = 0.723529, \|Δ\| < 1e−4 |
| 3 | a fresh 20-rep curveball null (10N trades) has mean in [0.700, 0.718] |
| 4 | `hodge_decompose.py` imports; hexagon control if exposed, else a 20-node smoke decomposition with orthogonality residuals < 1e−8 |

Outputs are preserved at `proofs/selftest.out` and `proofs/verify-recompute.json`.

To regenerate the figures:

```bash
python3 timeseries/plot_series.py     # needs matplotlib
```

---

## Directory map

```
bundle/
├── README.md                     this file
├── MANIFEST.json                 every file with size + sha256
├── proofs/
│   ├── VERIFY.sh                 one-shot reproduction (exit 0 = all pass)
│   ├── PROOFS.md                 P1–P7: claim, artifact, numbers, re-check command
│   ├── selftest.out              captured selftest log from the last VERIFY run
│   └── verify-recompute.json     live-recomputed V₂ / null / ΔV₂ / z
├── skills/curved-corpus-create/  the standard-candle skill (CORRECTED, see below)
│   ├── SKILL.md
│   ├── references/calibration-example.md
│   └── scripts/create_corpus.py  `--selftest` exits 0 only when GREEN
├── data/real/
│   └── per_row_coverage_v3.json  the master 2286×9 binary coverage matrix
├── scripts/                      wave-2 analysis code (common, nulls, Hodge, ladder, …)
├── results/                      wave-2 machine-produced result JSON + SUMMARY.md
│                                 + E1-hodge-nulls-report.md
├── timeseries/
│   ├── INDEX.json                unified index: legacy + new series + corrections
│   ├── legacy-34-cycles.json     wave-1 B-timeseries.json (34 cycles)
│   ├── new-series/               ladder-VD, scaling-VN, signal-recovery, gwtc-new, INDEX
│   ├── plot_series.py            renders the two figures
│   └── graphs/
│       ├── legacy-v2-trajectory.png   34-cycle V₂ trajectory + corrected null band
│       └── signal-recovery.png        ΔV₂z vs planted amplitude, per (N, d)
└── wave1-analyses/               the wave-1 memos, kept verbatim as the prior record
    ├── A-papers-digest.md  C-hodge-pivot.md  D-big-picture.md  B-timeseries.json
```

`wave1-analyses/D-big-picture.md` is retained **unedited** and still contains the
retracted 0.8005 / z = −45.8 figure. It is kept as the primary source of the claim
being corrected; read it against `proofs/PROOFS.md` P3, never on its own.

---

## Corrections table

| # | Claim (as previously published) | Status | Corrected value | Evidence |
|---|---|---|---|---|
| 1 | curveball null = **0.8005 ± 0.0017**, yubiOS at **z = −45.8** (below its null) | **retracted** | null **0.7089 ± 0.0014**; yubiOS **above** it at **ΔV₂ = +0.0144, z ≈ +12.3** (+12.13 at sd 0.00118, +12.35 in the N-ladder run) | `results/A-v2-nulls.json`, `results/A2-curveball-audit.json`, `results/validation.json`, `results/validation-curveball-sampler.json`, `results/finite_size.json` |
| 2 | Y₃³ constant `K = √(245/(64π)) = 1.10387` | **corrected** | real-orthonormal **`√(70/(64π)) = 0.590044`** (legacy = √(7/2) × this, 245/70 = 3.5); complex **`√(35/(64π)) = 0.417224`** (legacy = √7 × this, 245/35 = 7) | `results/validation.json` → `sh_constants`; skill selftest block 4 |
| 3 | `N_c ≈ 40` critical point / "+0.4664 phase transition" | **not a transition under null subtraction** | ΔV₂ flat at +0.0135…+0.0175 for **N ≥ 79**; raw V₂ falls only because the null falls (`V2_null(N) = 2/D + 0.5252·(D/N)^0.01673`). The "+0.4664" pair is a D-change on identical rows: D=9 → 0.7235, D=24 → 0.2940 | `results/finite_size.json`, `results/scaling_VN.json`, `results/ladder_VD.json` |
| 4 | `PC1+PC2 = 1.0000` reported as fit quality (7-D and 384-D series) | **rank artifact** | 1.0000 with r_eff = 2.000 on **all seven** corpora including pure noise (s = 0) at both `2_pca` and `384_variant2_l384_m3` | `results/ladder_VD.json` |
| 5 | Hodge predictions P-H1 / P-H2 / P-H3 | **all three falsified as stated** | P-H1: ρ_h *rises* inside the predicted collapse band (N=40 → 80). P-H2: Spearman = **−0.4545**, p = 0.160 (predicted ≥ +0.6). P-H3: defect lift **0.0** (0.205 on the band graph), predicted ≥ 2. What survives: the corpus is anti-cyclic vs its degree-matched null | `results/C-predictions.json`, `results/E1-hodge-nulls-report.md` |

### Corrections applied to the skill in this bundle

`skills/curved-corpus-create/` is a **corrected copy** of the wave-2 skill:

* **Red-flags table** — the row for "`dV2z` large and negative" kept its generic
  warning but replaced the yubiOS `z = −45.8` example with the corrected fact
  (null 0.7089 ± 0.0014, z = +12.3, ΔV₂ = +0.0144) and now cites the retraction as
  the cautionary tale for under-mixed nulls.
* **Y₃³ section** — now states *both* ratios explicitly (legacy = √7 × complex
  constant `√(35/(64π))`, legacy = √(7/2) × real-orthonormal `√(70/(64π))`), so the
  regime's "off by √7" shorthand and this skill's √(7/2) assertion are reconciled
  rather than contradictory. Same clause added to the changelog and to
  `references/calibration-example.md` step 6.
* **Stale `V_sat ≈ 0.78` / "curveball null at ~0.80"** — replaced by the measured
  0.7089 ± 0.0014 in the gate-failure table and in guideline 1.
* **`references/calibration-example.md` step 2** — the yubiOS sentence (V₂ = 0.7235
  against a curveball null of 0.8005, z = −45.8) rewritten to the corrected figures
  with the retraction noted.

The skill's `scripts/create_corpus.py` is unmodified; its `--selftest` still exits 0
(**SELFTEST GREEN**, all 7 blocks) in this bundle.

---

## Provenance

* **Generated:** 2026-08-12. Wave-2 master seed **20260812**; per-run seeds are
  recorded inside every record of `results/*.json` and `timeseries/new-series/*.json`
  (`seed` field per run) and in `timeseries/new-series/INDEX.json` → `provenance`.
  Generated sample matrices carry their own `MANIFEST.json` in the wave-2 data
  directory; the seeds there are the ones reproduced by these scripts.
* **Master matrix:** `data/real/per_row_coverage_v3.json` — the 2286×9 binary
  coverage matrix, copied verbatim from
  `session/extracted/guided-curve-ideate-iteration-cycles-with-34-492025d7/cycle-20/per_row_coverage_v3.json`.
  V₂ = 0.723529373073, reproducing the published cycle-20 value exactly.
* **Environment of record:** Python 3.12, numpy 2.5.1, scipy 1.18.0 (matplotlib only
  for the figures). The skill itself is stdlib + numpy only, by design.
* **Nulls:** fixed-margin curveball at 10N trades for binary matrices (row *and*
  column sums preserved); independent column permutation for continuous ones;
  degree-rewired edge null for graph-level Hodge statistics.
* **Integrity:** `MANIFEST.json` lists every file in the bundle with its byte size
  and SHA-256.
