# E1 — Null models + combinatorial Hodge theory on the real corpora

**Date:** 2026-08-12 · **Master seed:** `20260812` · **Python** 3.12.x, numpy 2.5.1, scipy 1.18.0
**Scripts:** `../scripts/{hodge_decompose,null_models,run_real_corpora,audit_curveball_discrepancy}.py`
**Every number below is machine-produced.** Nothing is estimated, rounded from memory, or carried over from a prior memo. Where a claimed number failed to reproduce, that is reported as a failure, not silently replaced.

---

## 0. Headline

1. **V₂ = 0.723529373073 reproduces exactly** (published 0.723529). The pipeline is comparable to the one that produced the published numbers.
2. **The curveball result in `D-big-picture.md` does NOT reproduce, and its sign is wrong.** A curveball sampler *proved uniform on the exact row+column-marginal fibre* and *converged in mixing* gives null = **0.709180 ± 0.001183**, so the real matrix is **z = +12.13 ABOVE** its matched-marginal null — not `0.8005 ± 0.0017`, z = −45.8 below it. Two of that memo's three other nulls (col-perm, mass-only) reproduce to ~0.001 with the same code, which localises the error to its curveball implementation.
3. **The A1 dominance flow is near-degenerate on this corpus.** ρ_g = 0.9996 on the primary graph: ≥99% of comparison energy is a pure potential. This is exactly the binary-data degeneracy `C-hodge-pivot.md` §4.4 warned about, realised.
4. **All three Hodge predictions P-H1/P-H2/P-H3 are FALSIFIED** in the forms stated. What survives is a different, real, construction-invariant finding: the corpus is **massively *less* cyclic and *less* holey than its own degree-matched null** (ρ_h z = −19 to −63; β₁ z = −16 to −313 across four constructions).

---

## 1. Reproduction and the corrected null (task a)

`results/A-v2-nulls.json`, `results/A2-curveball-audit.json`, `results/validation-curveball-sampler.json`

V₂ = top-2 eigenvalue share of the 9×9 **correlation** matrix.

| quantity | value |
|---|---|
| real V₂ (2286×9) | **0.7235293730732693** |
| published (cycle-20) | 0.723529 → **reproduces exactly** |
| curveball null, 200 samples × 228 600 trades | **0.709180 ± 0.001183** |
| **z (real vs curveball)** | **+12.13** |
| column-permutation null | 0.239933 ± 0.002369 → z = +204.2 |
| iid Bernoulli (column-matched) null | 0.239831 ± 0.002642 → z = +183.1 |
| row-permutation control | 0.723529 ± 0.0 (V₂ invariant, as it must be) |
| Marchenko–Pastur baseline (q = 0.003937) | λ₋ = 0.878446, λ₊ = 1.129428, predicted top-2 share **0.241375** |

The MP prediction (0.2414) sits on top of the col-perm and Bernoulli nulls (0.2399, 0.2398) — the destroyed-dependence nulls behave exactly as random-matrix theory says they must. That is an independent check that the pipeline is sound.

### 1.1 Why the −45.8 does not stand

| claim in `D-big-picture.md` | reproduced here | verdict |
|---|---|---|
| col-perm null = 0.2410 | 0.239733 ± 0.002 | ✅ reproduces |
| "mass-only" null = 0.6709 | row-marginal-only null = **0.670800 ± 0.001** | ✅ reproduces |
| curveball null = 0.8005 ± 0.0017 (z = −45.8) | **0.709180 ± 0.001183 (z = +12.13)** | ❌ **does not reproduce** |
| curveball null = 0.7613 (same memo, N-sweep table, same N) | — | the memo is also internally inconsistent with itself |

Evidence that *this* curveball is the correct one:

* **Sampler validation (exhaustive).** On a 5×4 matrix the complete fibre of binary matrices with identical row **and** column sums has **120** elements. 300 000 draws hit all 120, hit nothing outside, and are uniform: **χ² = 123.758, df = 119, p = 0.364**.
* **Marginals asserted exactly** on every one of the 2286×9 draws (row sums and column sums identical to the real matrix).
* **Mixing converged** — V₂ null vs trades: 1N → 0.715314, 5N → 0.710096, 20N → 0.708886, 100N → 0.708878, 400N → 0.709364. Flat from 20N onward; 0.8005 is not reachable by longer mixing.

**Consequence.** The kill-criterion in `D-big-picture.md` ("|z| < 3 ⇒ withdraw *phase transition* etc.") is not met, but neither is its stated conclusion. The corpus is **modestly but significantly above** its matched-marginal null (z ≈ +12), i.e. it carries ~1.4 percentage points of top-2 concentration that row+column marginals alone do not explain. That is a far weaker claim than the program's original one and a *different* claim from the memo's reversal.

### 1.2 Per-corpus V₂ vs curveball (all corpora, 50 samples each)

| corpus | N | V₂ | curveball null | **z** | col-perm null | MP pred. |
|---|---|---|---|---|---|---|
| yubiOS whole | 2286 | 0.723529 | 0.7098 ± 0.0011 | **+12.12** | 0.2399 | 0.2414 |
| yubiOS eligible (c ≥ 5) | 1322 | 0.425567 | 0.3824 ± 0.0051 | +8.41 | 0.2461 | 0.2475 |
| yubiOS deferred (1 ≤ c ≤ 4) | 760 | 0.311625 | 0.2596 ± 0.0045 | +11.65 | 0.2527 | 0.2558 |
| yubiOS refused (c = 0) | 204 | — | — | — | — | — |
| yubiOS skills | 474 | 0.581825 | 0.5559 ± 0.0122 | +2.12 | 0.2619 | 0.2650 |
| yubiOS docs | 126 | 0.607322 | 0.6080 ± 0.0064 | **−0.10** | 0.2965 | 0.3073 |
| yubiOS refs | 791 | 0.648135 | 0.5801 ± 0.0059 | +11.51 | 0.2532 | 0.2551 |
| yubiOS self | 895 | 0.406537 | 0.3863 ± 0.0035 | +5.81 | 0.2506 | 0.2531 |
| yubiOS 1391 (cycle-18) | 1391 | 0.640256 | 0.5882 ± 0.0046 | +11.28 | 0.2456 | 0.2469 |
| CIS 447 (dev-sec InSpec) | 447 | 0.331961 | 0.2667 ± 0.0044 | +14.93 | 0.2635 | 0.2663 |
| SCAP SSG 2107 | 2107 | 0.384629 | 0.3422 ± 0.0020 | +21.54 | 0.2411 | 0.2422 |
| SCAP SSG rules-dir 700 | 700 | 0.368366 | 0.3274 ± 0.0032 | +12.92 | 0.2550 | 0.2572 |

* The **refused regime is vacuous**: all 204 rows are identically zero, every column has zero variance, V₂ and the Hodge flow are both undefined. Reported as a skip, not as 0.0. (`within_regime_pc1pc2.json` recording "pc1pc2 = 0.0" for this regime is a division-by-zero artefact, not a measurement.)
* **`docs` (N = 126) is indistinguishable from its own null (z = −0.10).** The smallest corpus carries no matched-marginal-excess concentration at all.
* Regime split verified: the cycle-18 rule (`regime_threshold_k = 5`) reproduces 1294/212/38 on the cycle-18 1544-row file exactly.

---

## 2. Hodge on yubiOS, with both nulls (task b)

`results/B-hodge-yubios.json` — Construction A1, k-NN k = 8, Jaccard, seed 20260812.

| quantity | value |
|---|---|
| N, \|E\|, \|T\| | 2286, 16 438, 13 799 |
| distinct rows in M | **176** (of 512 possible) — massive tie degeneracy |
| ρ_grad | **0.99961366** |
| ρ_curl | **0.00013059** |
| ρ_harm | **0.00025575** |
| β₀, β₁, β₂ | 6, **6756**, 6397 |
| rank B₁, rank B₂ | 2280, 7402 |
| Euler check χ = β₀ − β₁ + β₂ | −353 = −353 ✅ |
| ⟨grad,curl⟩/‖Y‖² | −5.4 × 10⁻²⁰ |
| ⟨grad,harm⟩/‖Y‖² | −6.9 × 10⁻¹⁶ |
| ⟨curl,harm⟩/‖Y‖² | −1.1 × 10⁻²⁰ |
| ρ_g+ρ_c+ρ_h − 1 | 1.3 × 10⁻¹⁵ |
| ‖div R‖/‖div Y‖, ‖curl h‖/‖curl Y‖ | 9.8 × 10⁻¹⁴, 9.6 × 10⁻¹² |
| B₂B₁ max\|·\| (closedness) | **0.0 exactly** |
| hexagon control | β₁ = 1 ✅ |
| GF(2) vs exact-SVD rank(B₂) cross-check | agreed wherever the dense SVD was feasible (synthetic N = 300: 991 = 991; band graph: 2829 = 2829) |

**Null-standardised (this is the part that matters):**

| statistic | real | curveball-M, same construction (n=50) | z | degree-rewired G, same M (n=50) | **z** |
|---|---|---|---|---|---|
| ρ_grad | 0.999614 | 0.999636 ± 0.000077 | −0.29 | 0.974942 ± 0.000418 | **+59.04** |
| ρ_curl | 0.000131 | 0.000181 ± 0.000044 | −1.12 | 0.001038 ± 0.000114 | **−7.98** |
| ρ_harm | 0.000256 | 0.000183 ± 0.000051 | +1.39 | 0.024020 ± 0.000447 | **−53.14** |
| β₁ | 6756 | 6562 ± 57 | +2.47 | 13 678 ± 22 | **−312.54** |

**Reading.** Against the *matrix* null (curveball, graph rebuilt identically) every Hodge quantity is within ~2.5σ — the coverage matrix's own marginals fully explain its Hodge profile. Against the *graph* null (Kahle-warning null: same M, same degrees, rewired edges) the corpus is dramatically **less** cyclic and **less** holey than chance. So the Hodge signal here is a statement about **which items are near which items** (the metric structure survives), not about latent capability organisation beyond marginals.

**Harmonic support** (`results/E-harmonic-support.json`): the harmonic flow is extremely concentrated — **26 edges carry 50%** and **369 edges carry 90%** of harmonic energy (of 16 438); only **712 of 14 158** fundamental cycles have non-zero circulation. In the coverage-band construction it is diffuse instead (672 edges for 50%, 12 623/17 715 cycles non-zero). Concentration of harmonic support is therefore *not* construction-invariant and cannot be used as a corpus property.

---

## 3. The three predictions (task c)

`results/C-predictions.json`

### P-H1 — "ρ_h collapses across N_c ≈ 40–200, beyond the graph null" → **FALSIFIED as stated**

k = 8 held fixed, 20 independent subsamples per N, degree-rewired null at each N.

| N | ρ_h (real) ± SEM | ρ_h (rewired null) ± SEM | z real−null | edge density | \|T\|/\|E\| |
|---|---|---|---|---|---|
| 40 | 0.001405 ± 0.000270 | 0.001389 ± 0.000240 | +0.04 | 0.30449 | 2.252 |
| 80 | 0.003567 ± 0.000805 | 0.008364 ± 0.000518 | −5.01 | 0.15821 | 1.882 |
| 160 | 0.002412 ± 0.000291 | 0.013918 ± 0.000518 | −19.36 | 0.07981 | 1.654 |
| 320 | 0.002520 ± 0.000173 | 0.018142 ± 0.000310 | −44.00 | 0.04201 | 1.440 |
| 640 | 0.001445 ± 0.000117 | 0.020895 ± 0.000275 | −64.98 | 0.02151 | 1.182 |
| 1280 | 0.000496 ± 0.000026 | 0.022727 ± 0.000245 | −90.14 | 0.01105 | 1.001 |
| 2286 | 0.000258 ± 0.000001 | 0.023971 ± 0.000067 | −353.32 | 0.00630 | 0.849 |

* The prediction requires ρ_h to **decrease monotonically** and to drop by ≥3σ **as N crosses 40–200**. It does the opposite there: ρ_h **rises** from 0.001405 (N=40) to 0.003567 (N=80), a +2.5σ *increase*, and at N=160 (0.002412) it is still **+2.6σ above** N=40. There is no N_c collapse.
* The monotone decline only begins after N ≈ 320 and is smooth, tracking edge density (0.042 → 0.0063) rather than any critical band.
* **However**, the null does *not* show the same behaviour — it rises monotonically 0.0014 → 0.0240. So the real ρ_h decline is **not** a Kahle-window sampling artefact. The prediction's *mechanism check* passes while its *stated phenomenon* fails: there is a real, enormous, N-growing separation from the null, but it is not a transition at N_c.
* **Verdict: falsified.** ρ_h is flat-then-declining, not collapsing at N_c ≈ 40–200. Per the prediction's own terms ("Falsified if ρ_h is flat/increasing" over the band), this decides against the P1 form. Note this also removes the "load-bearing" status the memo assigned to the pivot on P1's outcome.

### P-H2 — "ρ_c tracks 1 − V₂ with Spearman ρ_s ≥ 0.6" → **FALSIFIED (wrong sign)**

11 corpora / subcorpora, k-NN k = 8, seed 20260812.

| corpus | N | V₂ | 1 − V₂ | ρ_curl | ρ_harm | β₁ |
|---|---|---|---|---|---|---|
| yubiOS 2286 | 2286 | 0.7235 | 0.2765 | 0.000131 | 0.000256 | 6756 |
| yubiOS eligible | 1322 | 0.4256 | 0.5744 | 0.000373 | 0.000121 | 5256 |
| yubiOS deferred | 760 | 0.3116 | 0.6884 | 0.000074 | 0.000191 | 594 |
| yubiOS skills | 474 | 0.5818 | 0.4182 | 0.003423 | 0.001668 | 1966 |
| yubiOS docs | 126 | 0.6073 | 0.3927 | **0.011903** | 0.000726 | 37 |
| yubiOS refs | 791 | 0.6481 | 0.3519 | 0.002414 | 0.001515 | 2022 |
| yubiOS self | 895 | 0.4065 | 0.5935 | 0.000201 | 0.000679 | 1311 |
| yubiOS 1391 (c-18) | 1391 | 0.6403 | 0.3597 | 0.000841 | 0.001737 | 5293 |
| CIS 447 | 447 | 0.3320 | 0.6680 | 0.000245 | 0.000621 | 104 |
| SCAP SSG 2107 | 2107 | 0.3846 | 0.6154 | 0.000065 | 0.000092 | 2670 |
| SCAP SSG rules-dir | 700 | 0.3684 | 0.6316 | 0.000817 | 0.000526 | 338 |

* **Spearman(1 − V₂, ρ_curl) = −0.4545, p = 0.160** (n = 11). Predicted ≥ +0.6; observed is negative and not significant.
* Spearman(1 − V₂, ρ_harm) = −0.4727, p = 0.142.
* The curl maximum is **`docs` (N = 126)**, the smallest corpus — ρ_c tracks N (small corpus ⇒ denser graph ⇒ more triangles per edge) far more visibly than it tracks 1 − V₂. The prediction's second clause (24-D variant is the curl maximum) is **untestable here**: only the 9-D coverage matrices exist in the shipped data; there is no 24-D matrix to run.
* **Verdict: falsified.** The prediction's own two-sided reading applies in the least useful direction — ρ_c is not redundant with V₂ (|ρ_s| < 0.95), but neither does it track it. It appears to be mostly a graph-density statistic.

### P-H3 — "defect rows carry harmonic support, lift ≥ 2" → **FALSIFIED, decisively**

| corpus / graph | defect rows | defect-incident edges | edge share | harmonic-energy share | **lift** |
|---|---|---|---|---|---|
| yubiOS 2286, k-NN k=8 | 204 | 1607 | 0.09776 | **0.0** | **0.0** |
| yubiOS 2286, k-NN k=16 | 204 | 3140 | 0.09792 | 0.0 | **0.0** |
| yubiOS 2286, threshold τ=0.35 | 204 | 488 | 0.02440 | 0.0 | **0.0** |
| yubiOS 2286, coverage-band b=1 | 204 | 2055 | 0.10275 | 0.021101 | **0.2054** |
| yubiOS 1391 (cycle-18), k-NN k=8 | **14** | 77 | 0.00752 | 0.0 | **0.0** |
| curveball null (row sums preserved ⇒ defects stay defects), n=60 | — | — | — | 0.0 | **0.0 ± 0.0** |

* The brief specified "the 14 strict-defect / zero-coverage rows". That count is correct for the **cycle-18 1391-row** file (`refused_count = 14`); the **cycle-20 2286-row master matrix has 204 zero-coverage rows**. Both were tested; both give lift 0.
* Mechanism: the 204 zero rows are *mutually identical*, so k-NN links them only to each other. On those edges |mᵢ ∨ mⱼ| = 0 and the A1 flow Y is identically zero, so they carry no comparison energy at all — they form isolated components (β₀ = 6 at k = 8; 221 at the threshold graph).
* Even on the coverage-band graph, where defect rows *do* connect to the rest, lift = **0.205** — the calibration synthetic in `C-hodge-pivot.md` gave 0.17 for *randomly placed* zero rows. The real defect rows are indistinguishable from random ones.
* **Verdict: falsified.** Lift ≥ 2 is refuted by a factor of ≥10. Harmonic support is diffuse w.r.t. defects, so the "vortex core = defect row" reading dies on evidence. Clause (ii) (quantised S² azimuthal winding) was **not tested**: no S² embedding coordinates are present in the shipped inputs, so it remains unproven rather than refuted — reported as untested, not as a pass.

---

## 4. Construction sensitivity (task d)

`results/D-construction-sensitivity.json` — same M, four graphs, degree-rewire null of each.

| construction | \|E\| | β₀ | β₁ | ρ_grad | ρ_curl | ρ_harm | z(ρ_c) | **z(ρ_h)** | **z(β₁)** | defect lift |
|---|---|---|---|---|---|---|---|---|---|---|
| k-NN k = 8 | 16 438 | 6 | 6756 | 0.999614 | 0.000131 | 0.000256 | −7.98 | **−53.14** | **−312.5** | 0.0 |
| k-NN k = 16 | 32 068 | 2 | 7222 | 0.998833 | 0.000542 | 0.000624 | −22.09 | **−62.68** | **−298.8** | 0.0 |
| threshold τ = 0.35 (cap 20 000) | 20 000 | 221 | 13 286 | 0.999441 | 0.000141 | 0.000418 | −1.91 | **−19.12** | **−16.1** | 0.0 |
| coverage-band b = 1 (cap 20 000) | 20 000 | 1 | 14 886 | 0.990753 | 0.001099 | 0.008148 | +1.29 | **−26.34** | **−37.3** | 0.2054 |

**Construction-INVARIANT (all four):**
1. ρ_grad > 0.99 — the A1 flow is dominated by a potential; the corpus is *near-totally ordered* by coverage. (The §4.4 degeneracy warning is realised, not avoided.)
2. ρ_harm is far **below** the degree-matched null (z between −19 and −63). The corpus is less globally cyclic than its own rewiring.
3. β₁ is far **below** the degree-matched null (z between −16 and −313).
4. P-H3 defect lift ≪ 2 (max 0.205).
5. Orthogonality residuals < 10⁻¹⁵ and the Euler identity holds in every run.

**NOT construction-invariant (do not report these as corpus properties):**
1. ρ_harm magnitude spans **32×** (0.000256 → 0.008148).
2. β₁ spans **2.2×** (6756 → 14 886); β₀ spans 1 → 221.
3. ρ_curl's null verdict flips sign: significantly *below* null at k-NN (z = −7.98, −22.09), indistinguishable at threshold (−1.91), *above* null at coverage-band (+1.29).
4. Harmonic-support concentration (26 edges for 50% at k-NN vs 672 at band).

**Verdict:** the *directional* conclusions (2)–(4) above are construction-invariant and safe to report. Every *numerical value* of ρ_h, ρ_c, β₀, β₁ is a property of the graph, exactly as `C-hodge-pivot.md` §4.1 predicted. Any use of these as corpus scalars would be an artefact.

---

## 5. Failures and untested items (nothing hidden)

* **`D-big-picture.md`'s curveball null (0.8005 ± 0.0017, z = −45.8) failed to reproduce.** Corrected value 0.709180 ± 0.001183, z = +12.13. The memo is additionally self-inconsistent (0.8005 in one table, 0.7613 in another for the same N).
* **`yubios_refused` (204 rows) cannot be analysed.** All-zero matrix: V₂ undefined (zero-variance columns), A1 flow identically zero, `hodge_decompose` raises `RuntimeError("flow Y is identically zero")` by design rather than returning a fake 0.
* **P-H3 clause (ii)** (quantised azimuthal S² winding n(σ) ∈ ℤ) was **not run** — the shipped inputs contain no S² embedding coordinates. Untested, not passed.
* **P-H2's 24-D clause** was **not run** — no 24-D coverage matrix exists in the shipped data; only 9-D.
* **β₁ uses GF(2) elimination for rank(B₂)** on large graphs. It was cross-checked against exact real rank (dense SVD) wherever the dense matrix fit (synthetic N=300: 991 = 991; coverage-band graph: 2829 = 2829) and agreed. On the k-NN k=8/k=16 and threshold graphs the dense check was infeasible; if the clique complex carried 2-torsion the GF(2) β₁ would differ from the rational one. No disagreement was observed anywhere it could be checked.
* **Triangle/edge caps.** Threshold and coverage-band graphs are uniformly subsampled to 20 000 edges (`edge_cap`); no run hit the triangle cap (`triangles_truncated: false` throughout).
* Curveball-matrix nulls for Hodge used n = 50 (not 200) and degree-rewire nulls n = 50 with 3 swaps/edge, to fit the sandbox's 10-minute per-call limit. The V₂ curveball null used the full n = 200 as specified.

---

## 6. Bottom line for the pivot

* The pivot's **machinery works and is verified** (exact closedness, 10⁻¹⁵ orthogonality, hexagon control, GF(2)/SVD rank agreement, uniform curveball sampler).
* The pivot's **three falsifiable predictions all fail**, and the load-bearing one (P-H1) fails on its own stated criterion.
* What replaces them is a cleaner and more defensible claim: **against a degree-matched null of the same graph, this corpus is strongly *anti-cyclic* — ρ_h and β₁ sit 19–313σ *below* chance, invariantly across four constructions.** That is a genuine, null-anchored, chart-independent finding. It is also the opposite of a vortex story: there are far *fewer* holes than a random graph of the same shape would have, and the harmonic mass avoids the defect rows entirely.
* Against the **matrix** null, however, every Hodge quantity is within ~2.5σ. Combined with ρ_grad ≈ 0.9996, the honest summary is: **the coverage matrix's row and column marginals, plus the graph you choose, jointly determine the entire Hodge profile.** The Ginzburg–Landau vortex bridge should be retired on this evidence, as §7 of `C-hodge-pivot.md` allowed for.
