#!/usr/bin/env python3
"""plot_series.py — render the two bundle time-series figures.

    python3 timeseries/plot_series.py

Writes:
    timeseries/graphs/legacy-v2-trajectory.png
    timeseries/graphs/signal-recovery.png

Inputs (resolved relative to this file):
    timeseries/legacy-34-cycles.json          cycles[].pc1pc2 (nulls skipped)
    timeseries/new-series/signal-recovery.json  planted-amplitude sweep

The corrected fixed-margin (curveball) null band 0.7089 +- 0.0014 is overlaid on
figure 1. That value replaces the retracted 0.8005 / z = -45.8 wave-1 figure; see
bundle/proofs/PROOFS.md P3.
"""
import json
import os
from collections import defaultdict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
GRAPHS = os.path.join(HERE, "graphs")
os.makedirs(GRAPHS, exist_ok=True)

NULL_MEAN = 0.7089
NULL_SD = 0.0014


def fig_legacy():
    d = json.load(open(os.path.join(HERE, "legacy-34-cycles.json")))
    xs, ys, labels = [], [], []
    for c in d["cycles"]:
        v = c.get("pc1pc2")
        if v is None:
            continue
        xs.append(c["cycle"])
        ys.append(float(v))
        labels.append(c.get("date", ""))
    fig, ax = plt.subplots(figsize=(10, 5.2), dpi=150)
    ax.axhspan(NULL_MEAN - NULL_SD, NULL_MEAN + NULL_SD, color="#d62728", alpha=0.18,
               label=f"corrected curveball null {NULL_MEAN} ± {NULL_SD}")
    ax.axhline(NULL_MEAN, color="#d62728", lw=1.2, ls="--")
    ax.axhline(2.0 / 9.0, color="#7f7f7f", lw=1.0, ls=":", label="V_floor = 2/9 = 0.2222")
    ax.plot(xs, ys, "o-", color="#1f77b4", lw=1.6, ms=5,
            label=f"measured V₂ (PC1+PC2), {len(xs)} of {len(d['cycles'])} cycles reported a value")
    ax.set_xlabel("cycle")
    ax.set_ylabel("V₂ = PC1+PC2 (correlation-matrix top-2 share)")
    ax.set_title("Legacy 34-cycle V₂ trajectory vs the corrected fixed-margin null\n"
                 "(wave-1 B-timeseries.json; cycles with no measured value are skipped)")
    ax.grid(alpha=0.25)
    ax.legend(loc="best", fontsize=8)
    fig.tight_layout()
    out = os.path.join(GRAPHS, "legacy-v2-trajectory.png")
    fig.savefig(out)
    plt.close(fig)
    print(f"wrote {out}  ({len(xs)} plotted points, cycles {min(xs)}..{max(xs)})")
    return out, len(xs)


def fig_recovery():
    d = json.load(open(os.path.join(HERE, "new-series", "signal-recovery.json")))
    recs = d["records"]
    agg = defaultdict(list)
    for r in recs:
        s = r.get("params", {}).get("s")
        z = r.get("z")
        if s is None or z is None:
            continue
        agg[(r["N"], r["d"], float(s))].append(float(z))
    groups = defaultdict(list)
    for (N, dd, s), zs in agg.items():
        groups[(N, dd)].append((s, sum(zs) / len(zs), len(zs)))

    fig, ax = plt.subplots(figsize=(9, 5.4), dpi=150)
    for key in sorted(groups):
        pts = sorted(groups[key])
        ax.plot([p[0] for p in pts], [p[1] for p in pts], "o-", lw=1.6, ms=5,
                label=f"N={key[0]}, d={key[1]}")
    ax.axhline(0, color="#7f7f7f", lw=1.0)
    ax.axhline(1.645, color="#d62728", ls="--", lw=1.0, label="z = 1.645 (one-sided 0.05)")
    ax.set_xlabel("planted amplitude s")
    ax.set_ylabel("ΔV₂ z-score vs matched curveball null")
    ax.set_title("Signal recovery: mean ΔV₂z vs planted amplitude\n"
                 "(new-series/signal-recovery.json, mean over reps per (s, N, d))")
    ax.grid(alpha=0.25)
    ax.legend(loc="upper left", fontsize=8)
    fig.tight_layout()
    out = os.path.join(GRAPHS, "signal-recovery.png")
    fig.savefig(out)
    plt.close(fig)
    n = sum(len(v) for v in groups.values())
    print(f"wrote {out}  ({len(groups)} (N,d) groups, {n} aggregated points)")
    return out, n


if __name__ == "__main__":
    fig_legacy()
    fig_recovery()
