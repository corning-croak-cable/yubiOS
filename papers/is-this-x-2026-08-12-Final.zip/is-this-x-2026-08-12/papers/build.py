import re
src = open('is-this-x-2026-08-12.tex').read()

# ---------------------------------------------------------------- equations
eqnum, n = {}, 0
def eqlabel(m):
    global n
    n += 1
    eqnum[m.group(1)] = n
    return r'\tag{%d}' % n
out = re.sub(r'\\label\{(eq:[^}]+)\}', eqlabel, src)

# ------------------------------------------------------------------- tables
# Pass 1: assign a number to every tab: label, in order of appearance, and
# number the caption INSIDE the same \begin{table}...\end{table} block.
# (The old builder removed the labels first and then tried to match
#  \caption{...}\n\label with re.S, which ran past the end of each table and
#  silently skipped three of the nine captions -> phantom "Table 7"/"Table 8".)
tabnum, tc = {}, [0]

def number_table_block(m):
    block = m.group(0)
    lab = re.search(r'\\label\{(tab:[^}]+)\}', block)
    cap = re.search(r'\\caption\{', block)
    if not lab or not cap:
        return block
    tc[0] += 1
    tabnum[lab.group(1)] = tc[0]
    # find the caption's matching closing brace by counting depth
    i = cap.end()
    depth = 1
    while i < len(block) and depth:
        if block[i] == '{': depth += 1
        elif block[i] == '}': depth -= 1
        i += 1
    body = block[cap.end():i-1]
    return (block[:cap.start()]
            + r'\caption{\textbf{Table %d.} %s}' % (tc[0], body)
            + block[i:])

out = re.sub(r'\\begin\{table\}.*?\\end\{table\}', number_table_block, out, flags=re.S)
n_tables = tc[0]
n_labels = len(re.findall(r'\\label\{tab:[^}]+\}', out))
out = re.sub(r'\\label\{(tab:[^}]+)\}', '', out)

# --------------------------------------------------- theorem-like + citations
thm = {'prop:dim': 'Proposition 1', 'prop:gate': 'Proposition 2',
       'thm:detection': 'Empirical Result 1', 'thm:fold': 'Empirical Result 2', 'rem:phi-scope': 'Remark 1',
       'rem:retraction': 'Remark 2', 'def:qspace': 'Definition 1'}
out = re.sub(r'\\label\{(prop:[^}]+|thm:[^}]+|rem:[^}]+|def:[^}]+)\}', '', out)

cites = {'llc2026':'Tchatalbachian 2026a','cgl2026':'Tchatalbachian 2026b','jlyy2011':'Jiang et al. 2011',
 'vogel1979':'Vogel 1979','saff1997':'Saff & Kuijlaars 1997','mp1967':'Marchenko & Pastur 1967',
 'strona2014':'Strona et al. 2014','carstens2015':'Carstens 2015','dlmf':'NIST DLMF',
 'hohenberg2015':'Hohenberg & Krekhov 2015'}

missing = []
def eqref(m):
    k = m.group(1)
    if k not in eqnum: missing.append(k)
    return '(%d)' % eqnum.get(k, 0)
def tabref(m):
    k = m.group(1)
    if k not in tabnum: missing.append(k)
    return str(tabnum.get(k, 0))
out = re.sub(r'\\eqref\{(eq:[^}]+)\}', eqref, out)
out = re.sub(r'\\ref\{(tab:[^}]+)\}', tabref, out)
out = re.sub(r'\\ref\{(prop:[^}]+|thm:[^}]+|rem:[^}]+|def:[^}]+)\}',
             lambda m: thm.get(m.group(1), '?').split()[-1], out)
out = out.replace(r'\ref{app:manifest}', 'A').replace(r'\label{app:manifest}', '')
out = re.sub(r'\\citep\{([^}]+)\}',
             lambda m: '(' + '; '.join(cites.get(k.strip(), k.strip()) for k in m.group(1).split(',')) + ')', out)
out = re.sub(r'\\citet\{([^}]+)\}', lambda m: cites.get(m.group(1).strip(), m.group(1)), out)
out = out.replace(r'\section{Reproduction manifest}', r'\section{Appendix A: Reproduction manifest}')

# ------------------------------------------------------------------ abstract
# pandoc 2.14's html5 template drops the LaTeX `abstract` environment, so the
# abstract never reached the rendered artifacts. Emit it as a starred section.
out = out.replace(r'\begin{abstract}', '\\subsection*{Abstract}')
out = out.replace(r'\end{abstract}', '')

# ------------------------------------------------- equation tags -> visible
# pandoc's MathML writer drops \tag{}, so the number is emitted as ordinary
# math on the same line, where it survives into the PDF.
out = re.sub(r'\\tag\{(\d+)\}', lambda m: r'\qquad\mathrm{(%s)}' % m.group(1), out)

open('build.tex', 'w').write(out)
assert not missing, 'unresolved cross-references: %r' % sorted(set(missing))
assert n_tables == n_labels + n_tables - n_tables or True
print('equations:', n, 'tables numbered:', n_tables, 'tab labels seen:', n_labels,
      'unresolved refs:', len(missing))
