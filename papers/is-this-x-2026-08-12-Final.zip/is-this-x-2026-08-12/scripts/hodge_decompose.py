#!/usr/bin/env python3.12
"""
hodge_decompose.py — combinatorial Hodge / Helmholtz decomposition of a
Jaccard-normalized dominance flow on an item graph built from an N x d binary
coverage matrix.

Implements Construction A1 of C-hodge-pivot.md:

    Y_ij = (c_j - c_i) / |m_i OR m_j|          (edge oriented i<j)
    w_ij = |m_i OR m_j|                         (JLYY capacity weighting)

Operators (JLYY Defs 2.1/2.2, 4.1-4.5):
    B1 in R^{|E| x N}    (delta_0)  : B1[e,i] = -1, B1[e,j] = +1  for e=(i<j)
    B2 in R^{|T| x |E|}  (delta_1)  : +1 on (i,j), +1 on (j,k), -1 on (i,k)
    => B2 @ B1 == 0 exactly (closedness, verified at runtime).

Inner products: <X,Y>_w = sum_e w_e X_e Y_e on C^1; unweighted on C^0, C^2.
Hence curl* Phi = W^{-1} B2^T Phi, and the two least-squares problems are

    s    = argmin || W^{1/2} (B1 s - Y) ||_2
    Phi  = argmin || W^{-1/2} B2^T Phi - W^{1/2} R ||_2 ,  R = Y - B1 s
    h    = R - W^{-1} B2^T Phi

giving the orthogonal splitting Y = grad + curl + harm with
rho_g + rho_c + rho_h = 1 (weighted norms).

Betti numbers:  beta_0 = N - rank(B1) = #components
                beta_1 = |E| - rank(B1) - rank(B2)
rank(B1) is exact (= N - #components). rank(B2) is computed by GF(2) sparse
elimination with Python big-int bitsets (fast, exact over F_2); on graphs small
enough it is cross-checked against the exact real rank via dense SVD, and the
agreement is reported in the output (`beta1_rank_check`). GF(2) rank equals the
rational rank unless the clique complex carries 2-torsion; the cross-check is
what licenses the number, and any disagreement is reported, never hidden.

Graph constructions:
    knn    : symmetrized k-NN under Jaccard distance (seeded tie-breaking --
             mandatory here because the d=9 binary rows take only 176 distinct
             values over 2286 items, so k-NN ties are pervasive)
    thresh : Jaccard distance <= tau, uniformly subsampled to an edge cap
    band   : coverage-band graph, |c_i - c_j| <= band, subsampled to an edge cap

CLI:
    python3.12 hodge_decompose.py --input per_row_coverage_v3.json \
        --graph knn --k 8 --seed 20260812 --out results/hodge_yubios_knn8.json
"""

from __future__ import annotations

import argparse
import json
import sys
import time

import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg import lsmr

# --------------------------------------------------------------------------
# data loading
# --------------------------------------------------------------------------


def load_coverage_json(path: str):
    """Load a per_row_coverage*.json into (M, meta_rows, primitives)."""
    with open(path) as fh:
        d = json.load(fh)
    rows = d["rows"]
    M = np.array([r["covered"] for r in rows], dtype=np.int8)
    prim = d.get("primitives", [f"p{i}" for i in range(M.shape[1])])
    meta = [{k: v for k, v in r.items() if k != "covered"} for r in rows]
    return M, meta, prim


# --------------------------------------------------------------------------
# graph construction
# --------------------------------------------------------------------------


def _pack_codes(M: np.ndarray):
    """Map rows to integer codes; return codes, unique codes, inverse index."""
    d = M.shape[1]
    powers = (1 << np.arange(d)).astype(np.int64)
    codes = (M.astype(np.int64) * powers).sum(1)
    uniq, inv = np.unique(codes, return_inverse=True)
    return codes, uniq, inv


def _jaccard_dist_matrix(uniq: np.ndarray, d: int) -> np.ndarray:
    """Pairwise Jaccard distance between unique binary codes."""
    U = ((uniq[:, None] >> np.arange(d)[None, :]) & 1).astype(np.float64)
    inter = U @ U.T
    sums = U.sum(1)
    union = sums[:, None] + sums[None, :] - inter
    with np.errstate(divide="ignore", invalid="ignore"):
        sim = np.where(union > 0, inter / np.maximum(union, 1e-30), 1.0)
    return 1.0 - sim


def build_graph(
    M: np.ndarray,
    method: str = "knn",
    k: int = 8,
    tau: float = 0.35,
    band: int = 1,
    edge_cap: int = 60000,
    seed: int = 20260812,
):
    """Return (edges, info) with edges an (|E|,2) int array of sorted (i<j) pairs."""
    rng = np.random.default_rng(seed)
    N, d = M.shape
    codes, uniq, inv = _pack_codes(M)
    D = _jaccard_dist_matrix(uniq, d)
    groups = [np.flatnonzero(inv == g) for g in range(len(uniq))]

    pairs: set[tuple[int, int]] = set()

    if method == "knn":
        order = np.argsort(D, axis=1, kind="stable")
        for i in range(N):
            gi = inv[i]
            picked: list[int] = []
            for g in order[gi]:
                cand = groups[g]
                if g == gi:
                    cand = cand[cand != i]
                need = k - len(picked)
                if need <= 0:
                    break
                if len(cand) <= need:
                    picked.extend(cand.tolist())
                else:
                    picked.extend(rng.choice(cand, size=need, replace=False).tolist())
            for j in picked:
                a, b = (i, int(j)) if i < j else (int(j), i)
                if a != b:
                    pairs.add((a, b))
    elif method in ("thresh", "band"):
        # candidate pairs at the group level, then sample inside groups
        cand_groups = []
        for a in range(len(uniq)):
            for b in range(a, len(uniq)):
                if method == "thresh":
                    ok = D[a, b] <= tau
                else:
                    ca = bin(int(uniq[a])).count("1")
                    cb = bin(int(uniq[b])).count("1")
                    ok = abs(ca - cb) <= band
                if ok:
                    cand_groups.append((a, b))
        # expected number of item pairs
        weights = []
        for a, b in cand_groups:
            na, nb = len(groups[a]), len(groups[b])
            weights.append(na * (na - 1) // 2 if a == b else na * nb)
        weights = np.array(weights, dtype=np.float64)
        total = weights.sum()
        if total == 0:
            raise RuntimeError("threshold/band graph produced no candidate pairs")
        target = min(edge_cap, int(total))
        probs = weights / total
        # draw group-pairs proportional to their item-pair count, then a random
        # item pair inside; rejection of duplicates keeps the sample uniform
        tries = 0
        while len(pairs) < target and tries < 60 * target:
            gi = rng.choice(len(cand_groups), p=probs)
            a, b = cand_groups[gi]
            i = int(rng.choice(groups[a]))
            j = int(rng.choice(groups[b]))
            tries += 1
            if i == j:
                continue
            pairs.add((min(i, j), max(i, j)))
    else:
        raise ValueError(f"unknown graph method {method!r}")

    edges = np.array(sorted(pairs), dtype=np.int64) if pairs else np.zeros((0, 2), np.int64)

    if len(edges) > edge_cap:
        sel = rng.choice(len(edges), size=edge_cap, replace=False)
        edges = edges[np.sort(sel)]

    info = {
        "method": method,
        "k": k if method == "knn" else None,
        "tau": tau if method == "thresh" else None,
        "band": band if method == "band" else None,
        "n_nodes": int(N),
        "n_edges": int(len(edges)),
        "edge_cap": edge_cap,
        "n_distinct_rows": int(len(uniq)),
        "edge_density": float(2.0 * len(edges) / (N * (N - 1))) if N > 1 else 0.0,
        "mean_degree": float(2.0 * len(edges) / N) if N else 0.0,
        "seed": seed,
    }
    return edges, info


def enumerate_triangles(edges: np.ndarray, N: int, tri_cap: int = 400000, seed: int = 0):
    """All 3-cliques (i<j<k). Returns (|T|,3) array, plus a truncation flag."""
    adj = [set() for _ in range(N)]
    for i, j in edges:
        adj[int(i)].add(int(j))
        adj[int(j)].add(int(i))
    tris = []
    truncated = False
    for i, j in edges:
        i, j = int(i), int(j)
        for kk in adj[i] & adj[j]:
            if kk > j and j > i:
                tris.append((i, j, kk))
            elif i < kk < j:
                tris.append((i, kk, j))
            elif kk < i:
                tris.append((kk, i, j))
        if len(tris) > 3 * tri_cap:
            truncated = True
            break
    tris = sorted(set(tris))
    if len(tris) > tri_cap:
        rng = np.random.default_rng(seed)
        sel = np.sort(rng.choice(len(tris), size=tri_cap, replace=False))
        tris = [tris[s] for s in sel]
        truncated = True
    T = np.array(tris, dtype=np.int64) if tris else np.zeros((0, 3), np.int64)
    return T, truncated


# --------------------------------------------------------------------------
# operators
# --------------------------------------------------------------------------


def build_B1(edges: np.ndarray, N: int) -> sp.csr_matrix:
    E = len(edges)
    rows = np.repeat(np.arange(E), 2)
    cols = edges.reshape(-1)
    vals = np.tile(np.array([-1.0, 1.0]), E)
    return sp.csr_matrix((vals, (rows, cols)), shape=(E, N))


def build_B2(tris: np.ndarray, edges: np.ndarray, N: int) -> sp.csr_matrix:
    E = len(edges)
    if len(tris) == 0:
        return sp.csr_matrix((0, E))
    eidx = {(int(a), int(b)): n for n, (a, b) in enumerate(edges)}
    rows, cols, vals = [], [], []
    for t, (i, j, k) in enumerate(tris):
        i, j, k = int(i), int(j), int(k)
        for (a, b), v in (((i, j), 1.0), ((j, k), 1.0), ((i, k), -1.0)):
            rows.append(t)
            cols.append(eidx[(a, b)])
            vals.append(v)
    return sp.csr_matrix((vals, (rows, cols)), shape=(len(tris), E))


def flow_A1(M: np.ndarray, edges: np.ndarray):
    """Construction A1: Y_e = (c_j - c_i)/|m_i OR m_j|, w_e = |m_i OR m_j|."""
    c = M.sum(1).astype(np.float64)
    i, j = edges[:, 0], edges[:, 1]
    union = (np.bitwise_or(M[i], M[j])).sum(1).astype(np.float64)
    w = np.where(union > 0, union, 1.0)  # both-empty rows: capacity 1, flow 0
    Y = (c[j] - c[i]) / w
    Y = np.where(union > 0, Y, 0.0)
    return Y, w


# --------------------------------------------------------------------------
# ranks / Betti numbers
# --------------------------------------------------------------------------


def n_components(edges: np.ndarray, N: int) -> int:
    if len(edges) == 0:
        return N
    g = sp.coo_matrix(
        (np.ones(len(edges)), (edges[:, 0], edges[:, 1])), shape=(N, N)
    )
    from scipy.sparse.csgraph import connected_components

    ncomp, _ = connected_components(g, directed=False)
    return int(ncomp)


def gf2_rank_from_rows(rows_bits: list[int]) -> int:
    """Exact GF(2) rank of a sparse 0/1 matrix given as big-int bitmask rows."""
    pivots: dict[int, int] = {}
    for r in rows_bits:
        cur = r
        while cur:
            p = cur.bit_length() - 1
            q = pivots.get(p)
            if q is None:
                pivots[p] = cur
                break
            cur ^= q
    return len(pivots)


def rank_B2_gf2(tris: np.ndarray, edges: np.ndarray) -> int:
    if len(tris) == 0:
        return 0
    eidx = {(int(a), int(b)): n for n, (a, b) in enumerate(edges)}
    rows_bits = []
    for i, j, k in tris:
        i, j, k = int(i), int(j), int(k)
        b = (1 << eidx[(i, j)]) ^ (1 << eidx[(j, k)]) ^ (1 << eidx[(i, k)])
        rows_bits.append(b)
    return gf2_rank_from_rows(rows_bits)


def rank_dense_exact(A: sp.spmatrix, max_cells: int = 60_000_000):
    """Exact numerical rank via dense SVD, or None if too large."""
    if A.shape[0] * A.shape[1] > max_cells or min(A.shape) == 0:
        return None
    return int(np.linalg.matrix_rank(np.asarray(A.todense(), dtype=np.float64)))


# --------------------------------------------------------------------------
# the decomposition
# --------------------------------------------------------------------------


def hodge_decompose(
    M: np.ndarray,
    edges: np.ndarray,
    tris: np.ndarray,
    compute_betti: bool = True,
    lsmr_atol: float = 1e-13,
    lsmr_iter: int = 20000,
):
    N = M.shape[0]
    E = len(edges)
    Y, w = flow_A1(M, edges)
    B1 = build_B1(edges, N)
    B2 = build_B2(tris, edges, N)

    # closedness check B2 @ B1 == 0
    closed = 0.0
    if B2.shape[0]:
        closed = float(np.abs((B2 @ B1).toarray() if B2.shape[0] < 500 else (B2 @ B1).data).max()) if (B2 @ B1).nnz else 0.0

    sw = np.sqrt(w)
    Wh = sp.diags(sw)
    Wmh = sp.diags(1.0 / sw)

    def wnorm2(x):
        return float(np.sum(w * x * x))

    normY2 = wnorm2(Y)
    if normY2 == 0:
        raise RuntimeError("flow Y is identically zero -- decomposition undefined")

    # 1. gradient / potential:  min_s || W^1/2 (B1 s - Y) ||
    r1 = lsmr(Wh @ B1, sw * Y, atol=lsmr_atol, btol=lsmr_atol, maxiter=lsmr_iter)
    s = r1[0]
    grad = B1 @ s
    R = Y - grad

    # 2. curl component: min_Phi || W^-1/2 B2^T Phi - W^1/2 R ||
    if B2.shape[0]:
        A = Wmh @ B2.T
        r2 = lsmr(A, sw * R, atol=lsmr_atol, btol=lsmr_atol, maxiter=lsmr_iter)
        phi = r2[0]
        curl = (B2.T @ phi) / w
        lsmr2_istop, lsmr2_iters = int(r2[1]), int(r2[2])
    else:
        phi = np.zeros(0)
        curl = np.zeros(E)
        lsmr2_istop, lsmr2_iters = -1, 0
    harm = R - curl

    rho_g = wnorm2(grad) / normY2
    rho_c = wnorm2(curl) / normY2
    rho_h = wnorm2(harm) / normY2

    def wdot(a, b):
        return float(np.sum(w * a * b))

    orth = {
        "grad_curl": wdot(grad, curl) / normY2,
        "grad_harm": wdot(grad, harm) / normY2,
        "curl_harm": wdot(curl, harm) / normY2,
        "sum_rho_minus_1": rho_g + rho_c + rho_h - 1.0,
        "div_of_residual_rel": float(np.abs(B1.T @ (w * R)).max()) / max(float(np.abs(B1.T @ (w * Y)).max()), 1e-30),
        "curl_of_harm_rel": (
            float(np.abs(B2 @ harm).max()) / max(float(np.abs(B2 @ Y).max()), 1e-30)
            if B2.shape[0] else 0.0
        ),
        "B2B1_max_abs": closed,
    }

    out = {
        "N": int(N),
        "n_edges": int(E),
        "n_triangles": int(len(tris)),
        "norm_Y2_w": normY2,
        "rho_grad": rho_g,
        "rho_curl": rho_c,
        "rho_harm": rho_h,
        "orthogonality": orth,
        "lsmr": {
            "grad_istop": int(r1[1]),
            "grad_iters": int(r1[2]),
            "curl_istop": lsmr2_istop,
            "curl_iters": lsmr2_iters,
        },
    }

    if compute_betti:
        ncomp = n_components(edges, N)
        rank_B1 = N - ncomp
        t0 = time.time()
        rB2 = rank_B2_gf2(tris, edges)
        gf2_secs = time.time() - t0
        beta0 = ncomp
        beta1 = E - rank_B1 - rB2
        beta2 = len(tris) - rB2
        chi = N - E + len(tris)
        check = None
        exact = rank_dense_exact(B2)
        if exact is not None:
            check = {"rank_B2_gf2": int(rB2), "rank_B2_exact_svd": int(exact),
                     "agree": bool(exact == rB2)}
        out["betti"] = {
            "beta0": int(beta0),
            "beta1": int(beta1),
            "beta2": int(beta2),
            "rank_B1": int(rank_B1),
            "rank_B2": int(rB2),
            "euler_chi": int(chi),
            "euler_identity_ok": bool(chi == beta0 - beta1 + beta2),
            "gf2_seconds": gf2_secs,
            "beta1_rank_check": check,
        }

    return out, {"Y": Y, "w": w, "s": s, "grad": grad, "curl": curl, "harm": harm,
                 "B1": B1, "B2": B2}


def harmonic_lift(edges, harm, w, defect_rows: np.ndarray) -> dict:
    """P-H3 statistic: harmonic energy share on defect-incident edges / edge share."""
    dset = set(int(x) for x in defect_rows)
    inc = np.array([(int(i) in dset) or (int(j) in dset) for i, j in edges])
    tot = float(np.sum(w * harm * harm))
    if tot <= 0 or inc.sum() == 0:
        return {"n_defect_rows": int(len(dset)), "n_defect_edges": int(inc.sum()),
                "edge_share": float(inc.mean()) if len(edges) else 0.0,
                "harm_share": None, "lift": None}
    hs = float(np.sum(w[inc] * harm[inc] ** 2)) / tot
    es = float(inc.mean())
    return {"n_defect_rows": int(len(dset)), "n_defect_edges": int(inc.sum()),
            "edge_share": es, "harm_share": hs, "lift": hs / es if es > 0 else None}


def run_full(M, graph="knn", k=8, tau=0.35, band=1, edge_cap=60000,
             tri_cap=400000, seed=20260812, compute_betti=True):
    edges, ginfo = build_graph(M, graph, k=k, tau=tau, band=band,
                               edge_cap=edge_cap, seed=seed)
    tris, trunc = enumerate_triangles(edges, M.shape[0], tri_cap=tri_cap, seed=seed)
    res, arrays = hodge_decompose(M, edges, tris, compute_betti=compute_betti)
    ginfo["triangles_truncated"] = bool(trunc)
    res["graph"] = ginfo
    return res, arrays, edges, tris


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--graph", default="knn", choices=["knn", "thresh", "band"])
    ap.add_argument("--k", type=int, default=8)
    ap.add_argument("--tau", type=float, default=0.35)
    ap.add_argument("--band", type=int, default=1)
    ap.add_argument("--edge-cap", type=int, default=60000)
    ap.add_argument("--tri-cap", type=int, default=400000)
    ap.add_argument("--seed", type=int, default=20260812)
    ap.add_argument("--no-betti", action="store_true")
    a = ap.parse_args(argv)

    M, meta, prim = load_coverage_json(a.input)
    res, arrays, edges, tris = run_full(
        M, graph=a.graph, k=a.k, tau=a.tau, band=a.band, edge_cap=a.edge_cap,
        tri_cap=a.tri_cap, seed=a.seed, compute_betti=not a.no_betti)
    c = M.sum(1)
    res["p_h3_zero_coverage_lift"] = harmonic_lift(
        edges, arrays["harm"], arrays["w"], np.flatnonzero(c == 0))
    res["input"] = a.input
    res["primitives"] = prim
    with open(a.out, "w") as fh:
        json.dump(res, fh, indent=2)
    print(json.dumps({kk: vv for kk, vv in res.items()
                      if kk in ("rho_grad", "rho_curl", "rho_harm", "betti",
                                "graph", "orthogonality")}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
