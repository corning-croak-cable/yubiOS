#!/usr/bin/env python3.12
"""
real_gwtc_pipeline.py — the REAL GWTC application (paper section 6,
"Real-catalog application: GWTC").

Reads the cached GWOSC eventapi superset at

    data/real/gwtc-real-gwosc.json          (default; no network)
    --fetch                                  refetch from gwosc.org instead

builds the 269 x 9 continuous parameter matrix, and reproduces every number in
results/real-gwtc-results.json:

  * V2 = PC1 + PC2 of the 9x9 correlation matrix           (0.835294)
  * column-shuffle null (200 reps) and its z               (0.275263 +- 0.008355, z = +67.0)
  * sphere fit via the skill's own protocol                (R2 = 0.7992, cond = 1.0034)
  * Parseval per-degree energy shares and the Y_3^3 share  (l=1 0.6464 ...; Y33 0.00334)
  * the Y_3^3 null (column shuffle) and its z              (0.00832 +- 0.00427, z = -1.17)

Null convention.  The matrix is CONTINUOUS, so the fixed-margin curveball null
of the binary pipeline is inapplicable; the matched null is the independent
per-column permutation, which destroys cross-column dependence while preserving
every column's own empirical marginal exactly.

Parseval convention (paper section 5, "Parseval energy shares").  z-score all
columns (log first on luminosity_distance) -> PCA top-2 scores -> divide by the
scalar sd of the score array -> inverse stereographic lift from the south pole
onto S^2 -> 16 real spherical harmonics (L = 3) at each item's own S^2 point ->
closed-form ridge (lambda = 1e-3) onto the 9 z-scored columns.  Because the
design is near-orthonormal, per-mode energy  ||B_m||^2 * ||C_m||^2  partitions
the total fitted energy, and the shares are scale-free along any constant-ratio
amplitude fold.

Seeds.  Master seed 20260812 (the bundle-wide seed).  The null RNG is
np.random.default_rng(--seed); with the default the 200-rep null reproduces
0.275263 +- 0.008355 exactly.  All paths are resolved relative to THIS FILE, so
the script runs from anywhere.

    python3.12 scripts/real_gwtc_pipeline.py
    python3.12 scripts/real_gwtc_pipeline.py --reps 200 --out results/real-gwtc-results.json
    python3.12 scripts/real_gwtc_pipeline.py --fetch          # refetch GWOSC
"""

import argparse
import importlib.util
import json
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

MASTER_SEED = 20260812
RIDGE_LAMBDA = 1e-3

FIELDS = ["mass_1_source", "mass_2_source", "chirp_mass_source",
          "total_mass_source", "luminosity_distance", "chi_eff",
          "redshift", "final_mass_source", "network_matched_filter_snr"]
LOG_FIELDS = {"luminosity_distance"}

# real_sh_basis column order, (l, m)
LM = [(0, 0), (1, -1), (1, 0), (1, 1),
      (2, -2), (2, -1), (2, 0), (2, 1), (2, 2),
      (3, -3), (3, -2), (3, -1), (3, 0), (3, 1), (3, 2), (3, 3)]
DEG = np.array([l for l, _ in LM])
Y33_COL = 15

GWOSC_URL = "https://gwosc.org/eventapi/json/GWTC/"


def load_skill():
    """Import the instrument (skills/curved-corpus-create) by relative path."""
    path = os.path.join(ROOT, "skills", "curved-corpus-create",
                        "scripts", "create_corpus.py")
    spec = importlib.util.spec_from_file_location("create_corpus", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# ---------------------------------------------------------------- input


def fetch_gwosc(dest):
    import urllib.request
    with urllib.request.urlopen(GWOSC_URL, timeout=120) as fh:
        payload = json.loads(fh.read().decode("utf-8"))
    with open(dest, "w") as fh:
        json.dump(payload, fh)
    return payload


def build_matrix(payload):
    """269 x 9 matrix of events carrying ALL nine fields, plus catalog counts."""
    events = payload["events"]
    rows, names, cats = [], [], {}
    for key, ev in events.items():
        if any(ev.get(f) is None for f in FIELDS):
            continue
        rows.append([float(ev[f]) for f in FIELDS])
        names.append(ev.get("commonName", key))
        c = ev.get("catalog.shortName", "?")
        cats[c] = cats.get(c, 0) + 1
    return np.asarray(rows, dtype=float), names, cats, len(events)


def transform(M):
    """log on luminosity_distance, then z-score every column."""
    X = M.copy()
    for j, f in enumerate(FIELDS):
        if f in LOG_FIELDS:
            X[:, j] = np.log(X[:, j])
    return (X - X.mean(axis=0)) / X.std(axis=0, ddof=0)


# ---------------------------------------------------------------- statistics


def eigs(Z):
    C = np.corrcoef(Z, rowvar=False)
    return np.sort(np.linalg.eigvalsh(C))[::-1]


def v2_of(Z):
    ev = eigs(Z)
    return float(ev[:2].sum() / ev.sum())


def colperm(Z, rng):
    B = Z.copy()
    for j in range(B.shape[1]):
        B[:, j] = B[rng.permutation(B.shape[0]), j]
    return B


def stereographic_lift(scores):
    """South-pole inverse stereographic lift of scores scaled by their sd."""
    a = scores / scores.std()
    r2 = (a ** 2).sum(axis=1)
    den = 1.0 + r2
    P = np.column_stack([2.0 * a[:, 0] / den, 2.0 * a[:, 1] / den,
                         (r2 - 1.0) / den])
    return P / np.linalg.norm(P, axis=1, keepdims=True)


def parseval_shares(Z, cc):
    """Per-mode fitted-energy shares over the 16 real SH of L = 3."""
    xc = Z - Z.mean(axis=0)
    u, s, _ = np.linalg.svd(xc, full_matrices=False)
    P = stereographic_lift(u[:, :2] * s[:2])
    B = cc.real_sh_basis(P)
    C = np.linalg.solve(B.T @ B + RIDGE_LAMBDA * np.eye(16), B.T @ Z)
    e = (B ** 2).sum(axis=0) * (C ** 2).sum(axis=1)
    return e / e.sum()


# ---------------------------------------------------------------- main


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--gwosc", default=os.path.join(ROOT, "data", "real",
                                                    "gwtc-real-gwosc.json"),
                    help="cached GWOSC eventapi JSON (default: data/real/gwtc-real-gwosc.json)")
    ap.add_argument("--fetch", action="store_true",
                    help="refetch the GWTC superset from gwosc.org and overwrite --gwosc")
    ap.add_argument("--reps", type=int, default=200,
                    help="column-shuffle null replicates (default 200)")
    ap.add_argument("--seed", type=int, default=MASTER_SEED,
                    help="null RNG seed (default 20260812)")
    ap.add_argument("--matrix-out", default=None,
                    help="optional path to write the N x 9 matrix as CSV")
    ap.add_argument("--out", default=None, help="optional JSON output path")
    a = ap.parse_args(argv)

    cc = load_skill()

    if a.fetch:
        print("fetching %s ..." % GWOSC_URL)
        payload = fetch_gwosc(a.gwosc)
    else:
        payload = json.load(open(a.gwosc))

    M, names, cats, n_all = build_matrix(payload)
    print("GWOSC events: %d total, %d with all %d fields" % (n_all, M.shape[0], len(FIELDS)))
    print("catalogs: %s" % json.dumps(cats, sort_keys=True))

    if a.matrix_out:
        np.savetxt(a.matrix_out, M, delimiter=",", header=",".join(FIELDS), comments="")
        print("matrix written: %s" % a.matrix_out)

    Z = transform(M)
    ev = eigs(Z)
    V2 = float(ev[:2].sum() / ev.sum())
    pc1, pc2 = float(ev[0] / ev.sum()), float(ev[1] / ev.sum())
    print("\nV2   = %.6f   (PC1 = %.4f, PC2 = %.4f)" % (V2, pc1, pc2))
    print("eigenvalues: %s" % np.round(ev, 4).tolist())

    rng = np.random.default_rng(a.seed)
    nulls = np.empty(a.reps)
    y33n = np.empty(a.reps)
    for r in range(a.reps):
        S = colperm(Z, rng)
        nulls[r] = v2_of(S)
        y33n[r] = parseval_shares(S, cc)[Y33_COL]
    nm, nsd = float(nulls.mean()), float(nulls.std(ddof=1))
    z = (V2 - nm) / nsd
    print("column-shuffle null (%d reps): %.6f +- %.6f   z = %+.1f" % (a.reps, nm, nsd, z))

    sf = cc.sphere_fit(Z)
    print("sphere fit: R2 = %.4f  chordal mean = %.4f  p95 = %.4f  cond = %.4f  rank = %d"
          % (sf["sphere_r2"], sf["chordal_resid_mean"], sf["chordal_resid_p95"],
             sf["design_cond"], sf["design_numrank"]))

    sh = parseval_shares(Z, cc)
    per_l = {int(l): float(sh[DEG == l].sum()) for l in range(4)}
    y33 = float(sh[Y33_COL])
    ym, ysd = float(y33n.mean()), float(y33n.std(ddof=1))
    yz = (y33 - ym) / ysd
    print("Parseval per-degree shares: " +
          "  ".join("l=%d %.4f" % (l, per_l[l]) for l in range(4)))
    top5 = sorted(range(16), key=lambda m: -sh[m])[:5]
    print("top-5 modes: %s" % [(LM[m], round(float(sh[m]), 5)) for m in top5])
    print("Y_3^3 share = %.5f   null %.5f +- %.5f   z = %+.2f  -> %s"
          % (y33, ym, ysd, yz, "NOT significant" if abs(yz) < 1.645 else "significant"))

    out = {
        "source": "GWOSC eventapi GWTC superset",
        "n_events": int(M.shape[0]), "catalogs": cats, "fields": FIELDS,
        "transform": "log on luminosity_distance; z-score all",
        "V2": round(V2, 6), "PC1": round(pc1, 4), "PC2": round(pc2, 4),
        "eigenvalues": [round(float(x), 4) for x in ev],
        "colperm_null": {"mean": round(nm, 6), "std": round(nsd, 6),
                         "z": round(z, 1), "reps": a.reps},
        "sphere_fit": {k: sf[k] for k in ("pc12", "sphere_r2", "chordal_resid_mean",
                                          "chordal_resid_p95", "design_cond",
                                          "design_numrank")},
        "parseval": {"per_l_shares": per_l, "y33_share": y33,
                     "y33_null_mean": ym, "y33_null_std": ysd, "y33_z": yz,
                     "top5_modes": [[list(LM[m]), float(sh[m])] for m in top5]},
        "seed": a.seed,
        "event_names_first10": names[:10],
    }
    if a.out:
        with open(a.out, "w") as fh:
            json.dump(out, fh, indent=1)
        print("\nwritten: %s" % a.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
