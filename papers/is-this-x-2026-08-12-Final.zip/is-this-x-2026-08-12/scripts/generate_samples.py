"""
generate_samples.py — three NEW seeded sample families for the wave-2 study.

All data is generated fresh (user-approved "make new samples"). Every corpus
carries its generative model, its parameters and its seed in the manifest.

FAMILY (i)  latent_class  — two-population binary mixture reproducing yubiOS's
            U-shaped row-mass histogram, plus 1-class and 3-class controls.
              row class c ~ Categorical(pi);  X_ij ~ Bernoulli(p_c,j)
              2-class: pi_high rows at p_high~0.9, rest at p_low~0.15
              1-class: single p vector matched to the 2-class column marginals
                       (== the iid/no-row-structure control)
              3-class: p in {0.9, 0.5, 0.15}
            Per-column jitter U(-0.04, +0.04) on each p, seeded.

FAMILY (ii) curved — rows are POINTS ON A SPHERE and the columns are smooth
            fields on that sphere, so the latent structure IS a spherical curve:
              x_i  = Fibonacci/golden-angle point:  z_i = 1-(2i+1)/N,
                                                    phi_i = 2*pi*i/phi_golden
              gamma_j(x) = sum_lm a^{(j)}_lm Y_lm(x)   (real SH, L=3, 16 fns,
                           CORRECTED Y_3^3 constant sqrt(70/(64 pi)))
              P(X_ij=1) = sigmoid( s * gammahat_j(x_i) + b_j )
            gammahat_j is standardised over the sample, so s is exactly the
            log-odds swing per 1 sd of planted field: s=0 is an exact null
            (independent columns, no latent geometry).

FAMILY (iii) gwtc_like — synthetic BBH parameter matrices (138x9, 1000x9),
            3-component primary-mass mixture (10 / 35 / power-law tail),
            realistic derived correlations (Mc, Mtot, q from m1,m2) and spin
            alignment structure, plus a column-shuffled null with identical
            marginals. Seeds are NEW (base 20260812xx != 20260811).

Outputs
  data/samples/family_i_latent_class.npz
  data/samples/family_ii_curved.npz
  data/samples/family_iii_gwtc.npz
  data/samples/MANIFEST.json
"""

import argparse
import math
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402

# --- portable paths -------------------------------------------------------
# Defaults resolve relative to THIS FILE's location inside the bundle, so the
# bundle runs wherever it is unpacked. Override with the CLI flags in main().
HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
DATA = os.path.join(BUNDLE, "data", "samples")   # --out-root/samples

BASE_SEED_I = 20260812_100
BASE_SEED_II = 20260812_200
BASE_SEED_III = 20260812_300

P_HIGH, P_LOW, P_MID = 0.90, 0.15, 0.50
PI_HIGH = 0.45


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


# ---------------------------------------------------------------- family (i)
def gen_latent_class(N, d, n_classes, seed):
    rng = np.random.default_rng(seed)
    if n_classes == 2:
        pis = np.array([PI_HIGH, 1.0 - PI_HIGH])
        base = np.array([P_HIGH, P_LOW])
    elif n_classes == 3:
        pis = np.array([0.35, 0.30, 0.35])
        base = np.array([P_HIGH, P_MID, P_LOW])
    elif n_classes == 1:
        pis = np.array([1.0])
        base = np.array([PI_HIGH * P_HIGH + (1 - PI_HIGH) * P_LOW])
    else:
        raise ValueError(n_classes)
    Pmat = np.clip(base[:, None] + rng.uniform(-0.04, 0.04, size=(n_classes, d)), 0.01, 0.99)
    cls = rng.choice(n_classes, size=N, p=pis)
    X = (rng.random((N, d)) < Pmat[cls]).astype(np.uint8)
    params = dict(
        n_classes=n_classes, pi=[float(v) for v in pis],
        p_base=[float(v) for v in base], p_high=P_HIGH, p_low=P_LOW,
        jitter="U(-0.04,0.04) per column", class_counts=[int((cls == k).sum()) for k in range(n_classes)],
    )
    return X, params


# --------------------------------------------------------------- family (ii)
def gen_curved(N, d, s, seed, target_rate_lo=0.30, target_rate_hi=0.70):
    rng = np.random.default_rng(seed)
    theta, phi = C.fibonacci_sphere(N)
    B = C.real_sh_L3(theta, phi)                      # N x 16
    A = rng.normal(size=(16, d))                      # planted coefficients
    G = B @ A                                         # N x d planted fields
    G = (G - G.mean(axis=0)) / (G.std(axis=0) + 1e-12)   # standardise -> s is log-odds/sd
    rates = rng.uniform(target_rate_lo, target_rate_hi, size=d)
    b = np.log(rates / (1.0 - rates))
    Pr = sigmoid(s * G + b[None, :])
    X = (rng.random((N, d)) < Pr).astype(np.uint8)
    P_true = np.column_stack([
        np.sin(theta) * np.cos(phi), np.sin(theta) * np.sin(phi), np.cos(theta)
    ])
    params = dict(
        s=float(s), basis="real SH L=3 (16 fns), corrected Y_3^3 = sqrt(70/(64pi))",
        sampling="fibonacci golden-angle: z=1-(2i+1)/N, phi=2*pi*i/phi_golden",
        link="logistic", base_rates=[float(v) for v in rates],
        coeff_dist="N(0,1) per (harmonic, column), fields standardised to unit sd",
    )
    return X, params, P_true


# -------------------------------------------------------------- family (iii)
GWTC_COLS = ["m1", "m2", "Mchirp", "Mtot", "q", "chi_eff", "chi_p", "z", "dL"]


def gen_gwtc(N, seed):
    """3-component primary-mass mixture + physically derived correlations."""
    rng = np.random.default_rng(seed)
    w = np.array([0.40, 0.35, 0.25])                     # 10 Msun peak / 35 peak / tail
    comp = rng.choice(3, size=N, p=w)
    m1 = np.empty(N)
    k0 = comp == 0
    k1 = comp == 1
    k2 = comp == 2
    m1[k0] = np.clip(rng.normal(10.0, 1.8, k0.sum()), 5.0, None)
    m1[k1] = np.clip(rng.normal(34.0, 5.0, k1.sum()), 5.0, None)
    u = rng.random(k2.sum())
    a, lo, hi = 3.5, 5.0, 90.0                            # power law p(m) ~ m^-a
    m1[k2] = (lo ** (1 - a) + u * (hi ** (1 - a) - lo ** (1 - a))) ** (1.0 / (1 - a))
    q = np.clip(rng.beta(6.0, 2.0, N), 0.08, 1.0)          # mass ratio, peaked near 1
    m2 = m1 * q
    Mtot = m1 + m2
    Mchirp = (m1 * m2) ** 0.6 / Mtot ** 0.2
    # spins: aligned components correlated with q (heavier, asymmetric -> broader chi_eff)
    a1 = rng.beta(2.0, 5.0, N)
    a2 = rng.beta(2.0, 5.0, N)
    ct1 = np.clip(rng.normal(0.35, 0.55, N), -1, 1)
    ct2 = np.clip(rng.normal(0.20, 0.60, N), -1, 1)
    chi_eff = (m1 * a1 * ct1 + m2 * a2 * ct2) / Mtot
    chi_p = np.maximum(a1 * np.sqrt(np.clip(1 - ct1 ** 2, 0, 1)),
                       (4 * q + 3) / (3 * q + 4) * q * a2 * np.sqrt(np.clip(1 - ct2 ** 2, 0, 1)))
    # redshift: detection-weighted, louder (heavier) systems seen further
    z = np.clip(rng.gamma(2.0, 0.16, N) * (Mchirp / 25.0) ** 0.55, 0.01, 2.5)
    dL = 4300.0 * z * (1.0 + 0.42 * z)                     # smooth monotone D_L(z) proxy [Mpc]
    X = np.column_stack([m1, m2, Mchirp, Mtot, q, chi_eff, chi_p, z, dL])
    params = dict(
        columns=GWTC_COLS, mixture_weights=[float(v) for v in w],
        components=["N(10,1.8)", "N(34,5.0)", "powerlaw a=3.5 on [5,90]"],
        q_dist="Beta(6,2)", spin="a~Beta(2,5), cos_tilt1~N(0.35,0.55), cos_tilt2~N(0.20,0.60)",
        z_dist="Gamma(2,0.16) * (Mchirp/25)^0.55", dL="4300*z*(1+0.42z) Mpc",
        component_counts=[int(k0.sum()), int(k1.sum()), int(k2.sum())],
    )
    return X, params


def gwtc_null(X, seed):
    rng = np.random.default_rng(seed)
    return C.colperm(X, rng)


# ------------------------------------------------------------------- driver
def main(argv=None):
    global DATA
    ap = argparse.ArgumentParser(description="Generate the planted / mixture / null sample corpora.")
    ap.add_argument("--out-root", default=os.path.join(BUNDLE, "data"),
                    help="directory to write samples/ into (default: <bundle>/data)")
    a = ap.parse_args(argv)
    DATA = os.path.join(a.out_root, "samples")
    t0 = time.time()
    C.ensure_dir(DATA)
    manifest = dict(created=C.now_iso(), families={}, seeds_base=dict(
        family_i=BASE_SEED_I, family_ii=BASE_SEED_II, family_iii=BASE_SEED_III))

    # ---- family (i)
    arrs_i, meta_i = {}, []
    d_grid = [5, 9, 16, 24]
    n_grid = [40, 79, 160, 320, 640, 1280, 2560, 4096]
    k = 0
    for n_classes in (1, 2, 3):
        for d in d_grid:
            k += 1
            seed = BASE_SEED_I + k
            X, p = gen_latent_class(2286, d, n_classes, seed)
            rid = f"lc{n_classes}_N2286_d{d}"
            arrs_i[rid] = X
            meta_i.append(dict(run_id=rid, seed=seed, generator="latent_class", N=2286, d=d,
                               params=p, sweep="dimension"))
        for N in n_grid:
            k += 1
            seed = BASE_SEED_I + k
            X, p = gen_latent_class(N, 9, n_classes, seed)
            rid = f"lc{n_classes}_N{N}_d9"
            arrs_i[rid] = X
            meta_i.append(dict(run_id=rid, seed=seed, generator="latent_class", N=N, d=9,
                               params=p, sweep="scaling"))
    np.savez_compressed(os.path.join(DATA, "family_i_latent_class.npz"), **arrs_i)
    manifest["families"]["i_latent_class"] = meta_i
    print(f"[i]   {len(arrs_i)} corpora  ({time.time()-t0:.1f}s)")

    # ---- family (ii)
    arrs_ii, meta_ii = {}, []
    k = 0
    cells = [(N, d, s) for N in (128, 512, 2048) for d in (9, 16)
             for s in (0.0, 0.25, 0.5, 1.0, 2.0)]
    for (N, d, s) in cells:
        reps = 12 if N < 2048 else 8
        for r in range(reps):
            k += 1
            seed = BASE_SEED_II + k
            X, p, Pt = gen_curved(N, d, s, seed)
            rid = f"cv_N{N}_d{d}_s{s}_r{r}"
            arrs_ii[rid] = X
            arrs_ii[rid + "__Ptrue"] = Pt.astype(np.float32)
            meta_ii.append(dict(run_id=rid, seed=seed, generator="curved_sh_logistic",
                                N=N, d=d, s=float(s), rep=r, params=p, sweep="signal_recovery"))
    # extra s=0 replicates for the calibrated false-positive-rate check
    for r in range(48):
        k += 1
        seed = BASE_SEED_II + k
        X, p, Pt = gen_curved(512, 9, 0.0, seed)
        rid = f"fpr_N512_d9_s0.0_r{r}"
        arrs_ii[rid] = X
        arrs_ii[rid + "__Ptrue"] = Pt.astype(np.float32)
        meta_ii.append(dict(run_id=rid, seed=seed, generator="curved_sh_logistic",
                            N=512, d=9, s=0.0, rep=r, params=p, sweep="fpr_calibration"))
    np.savez_compressed(os.path.join(DATA, "family_ii_curved.npz"), **arrs_ii)
    manifest["families"]["ii_curved"] = meta_ii
    print(f"[ii]  {len(meta_ii)} corpora  ({time.time()-t0:.1f}s)")

    # ---- family (iii)
    arrs_iii, meta_iii = {}, []
    for i, N in enumerate((138, 1000)):
        seed = BASE_SEED_III + 11 + i
        X, p = gen_gwtc(N, seed)
        rid = f"gwtc_N{N}"
        arrs_iii[rid] = X
        meta_iii.append(dict(run_id=rid, seed=seed, generator="gwtc_like_bbh", N=N, d=9,
                             params=p, sweep="gwtc"))
        nseed = seed + 500
        arrs_iii[f"gwtc_N{N}_null"] = gwtc_null(X, nseed)
        meta_iii.append(dict(run_id=f"gwtc_N{N}_null", seed=nseed,
                             generator="gwtc_like_bbh_colperm_null", N=N, d=9,
                             params=dict(note="independent columns, marginals identical to gwtc_N%d" % N),
                             sweep="gwtc"))
    np.savez_compressed(os.path.join(DATA, "family_iii_gwtc.npz"), **arrs_iii)
    manifest["families"]["iii_gwtc"] = meta_iii
    print(f"[iii] {len(meta_iii)} corpora  ({time.time()-t0:.1f}s)")

    C.dump_json(os.path.join(DATA, "MANIFEST.json"), manifest)
    n = len(meta_i) + len(meta_ii) + len(meta_iii)
    print(f"TOTAL {n} corpora written to {DATA} in {time.time()-t0:.1f}s")


if __name__ == "__main__":
    main()
