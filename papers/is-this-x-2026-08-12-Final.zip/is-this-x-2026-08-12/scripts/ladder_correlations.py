"""
ladder_correlations.py — the definitive 2/3/5/7/9/16/24/384-D correlation study,
run on BOTH the real yubiOS matrix and the wave-2 generated corpora.

Parts
  V  validation      : curveball uniformity (exhaustive small-case chi^2) and an
                       independent swap-chain cross-check of the fixed-margin null
  A  V2(D)           : the same rows re-embedded at D = 2,3,7,9,16,24,384
  B  V2(N) | null    : scaling with the curveball null SUBTRACTED (generated data,
                       ground truth known)
  C  signal recovery : Delta V2, z, sphere-fit R^2 vs planted amplitude s, plus a
                       calibrated false-positive-rate check at s = 0
  D  finite size     : V2(N) for the null itself, real-minus-null, N_c re-analysis
  E  gwtc            : new synthetic BBH matrices vs their independent-column null

Every null is the fixed-margin (curveball) ensemble for binary matrices and the
independent column permutation for matrices with continuous columns.
"""

import argparse
import json
import math
import os
import sys
import time
import itertools

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402

# --- portable paths -------------------------------------------------------
# Defaults resolve relative to THIS FILE's location inside the bundle, so the
# bundle runs wherever it is unpacked. Override with the CLI flags in main().
HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
DATA = os.path.join(BUNDLE, "data", "samples")        # --data-root/samples
RES = os.path.join(BUNDLE, "results")                 # --out-root
# the 2286x9 master coverage matrix ships with the bundle:
REAL = os.path.join(BUNDLE, "data", "real", "per_row_coverage_v3.json")  # --real

TRADE_MULT = 10          # curveball trades = TRADE_MULT * N  (mixing verified in part V)
T0 = time.time()


def log(msg):
    print(f"[{time.time()-T0:7.1f}s] {msg}", flush=True)


def is_binary(M):
    u = np.unique(M)
    return u.size <= 2 and np.all(np.isin(u, (0.0, 1.0)))


def null_stats(M, reps, seed, kind=None, with_fit=0):
    """Null distribution of V2 (+ optionally of the sphere-fit statistics)."""
    kind = kind or ("curveball" if is_binary(M) else "colperm")
    N = M.shape[0]
    v, r2cv, r2p = [], [], []
    for i in range(reps):
        if kind == "curveball":
            Y = C.curveball_fast(M, seed * 1000003 + i, n_trades=TRADE_MULT * N)
        else:
            Y = C.colperm(M, np.random.default_rng(seed * 1000003 + i))
        v.append(C.v2(Y))
        if i < with_fit:
            try:
                P = C.stereographic_lift(C.pca_scores(Y, 2))
                r2cv.append(C.sphere_fit_cv(P, seed=i)["R2_cv"])
                r2p.append(C.sphere_fit_paper(P)["R2"])
            except Exception:
                pass
    v = np.asarray(v, float)
    v = v[np.isfinite(v)]
    out = dict(kind=kind, reps=int(reps), trades_mult=TRADE_MULT, seed=int(seed),
               mean=float(v.mean()), std=float(v.std(ddof=1)) if v.size > 1 else float("nan"))
    if r2cv:
        out["R2_cv_mean"] = float(np.mean(r2cv))
        out["R2_cv_std"] = float(np.std(r2cv, ddof=1)) if len(r2cv) > 1 else float("nan")
        out["R2_paper_mean"] = float(np.mean(r2p))
    return out


def z_of(val, ns):
    if not np.isfinite(ns.get("std", np.nan)) or ns["std"] <= 0:
        return float("nan")
    return float((val - ns["mean"]) / ns["std"])


# ==========================================================================
# PART V — validation of the null machinery
# ==========================================================================
def part_V():
    log("PART V: null validation")
    rng = np.random.default_rng(7)
    X0 = (rng.random((6, 4)) < 0.5).astype(float)
    rs, cs = X0.sum(1), X0.sum(0)
    ens = {}
    for bits in itertools.product([0, 1], repeat=24):
        M = np.array(bits, dtype=float).reshape(6, 4)
        if np.array_equal(M.sum(1), rs) and np.array_equal(M.sum(0), cs):
            ens[M.tobytes()] = len(ens)
    draws = 20000
    cnt = np.zeros(len(ens))
    for s in range(draws):
        cnt[ens[C.curveball_fast(X0, s, n_trades=60).tobytes()]] += 1
    exp = draws / len(ens)
    chi2 = float(((cnt - exp) ** 2 / exp).sum())
    df = len(ens) - 1
    try:
        from scipy.stats import chi2 as _c2
        p = float(1 - _c2.cdf(chi2, df))
    except Exception:
        p = float("nan")

    X, prim, _ = C.load_real_matrix(REAL)
    N = len(X)
    conv = {}
    for mult in (1, 4, 10, 25, 100):
        vs = [C.v2(C.curveball_fast(X, 900 + i, n_trades=mult * N)) for i in range(6)]
        conv[f"{mult}N"] = dict(mean=float(np.mean(vs)), std=float(np.std(vs, ddof=1)))
    sw = [C.v2(C.swap_chain_null(X, s, n_swaps_mult=300)) for s in range(6)]
    cb = [C.v2(C.curveball_fast(X, 1000 + s, n_trades=TRADE_MULT * N)) for s in range(6)]
    out = dict(
        uniformity=dict(ensemble_size=len(ens), draws=draws, chi2=chi2, df=df, p_value=p,
                        verdict="uniform" if p > 0.01 else "NOT uniform"),
        curveball_mixing_vs_trades=conv,
        cross_check_real_matrix=dict(
            real_V2=C.v2(X),
            curveball_mean=float(np.mean(cb)), curveball_std=float(np.std(cb, ddof=1)),
            swap_chain_mean=float(np.mean(sw)), swap_chain_std=float(np.std(sw, ddof=1)),
            wave1_reported_curveball=0.8005,
            note=("two independent fixed-margin samplers agree; the wave-1 value 0.8005 "
                  "is NOT reproduced. Real sits ABOVE its fixed-margin null, not below.")),
        sh_constants=C.sh_constants(),
    )
    C.dump_json(os.path.join(RES, "validation.json"), out)
    log(f"  uniformity p={p:.3f}; curveball {np.mean(cb):.4f} vs swap-chain {np.mean(sw):.4f}")
    return out


# ==========================================================================
# PART A — the dimension ladder
# ==========================================================================
def fib_lobe_basis(theta, phi, variant):
    """Reconstruction of the paper's 384-D Fibonacci-lobe basis sin^l(theta)cos(m phi),
    m = 3k. Three variants, matching the three published numbers as hypotheses."""
    st = np.sin(theta)
    if variant == "native_384_independent":
        # 384 distinct azimuthal modes m = 3k, k = 1..384, single polar profile sin^3
        return np.column_stack([st ** 3 * np.cos(3 * k * phi) for k in range(1, 385)])
    if variant == "native_384_replicated":
        # 128 azimuthal modes m = 3k, each emitted as 3 rescaled copies
        # (hypothesis for the published native value 0.015631 == 2/128)
        cols = []
        for k in range(1, 129):
            base = st ** 3 * np.cos(3 * k * phi)
            cols += [base, 2.0 * base, 0.5 * base]
        return np.column_stack(cols)
    if variant == "variant1_l128":
        return np.column_stack([st ** 128 * np.cos(3 * k * phi) for k in range(1, 385)])
    if variant == "variant2_l384_m3":
        # one azimuthal mode m=3 under a fixed polar profile, 384 phase offsets:
        # spans span{cos 3phi, sin 3phi} -> rank exactly 2 -> V2 == 1 by construction
        return np.column_stack([st ** 384 * np.cos(3 * phi + 2 * math.pi * k / 384)
                                for k in range(384)])
    raise ValueError(variant)


def build_ladder(X, seed):
    """Same rows, many feature spaces."""
    rng = np.random.default_rng(seed)
    N, d0 = X.shape
    sc = C.pca_scores(X, 2)
    P = C.stereographic_lift(sc)
    theta, phi = C.sphere_angles(P)
    mass = X.sum(axis=1)
    mass_n = (mass - mass.min()) / max(1e-12, (mass.max() - mass.min()))

    nss_indep = (rng.random((N, 12)) < rng.uniform(0.15, 0.6, size=12)[None, :]).astype(float)
    nss_mass = (rng.random((N, 12)) < (0.15 + 0.70 * mass_n)[:, None]).astype(float)
    meta = np.column_stack([
        0.6 * mass_n + rng.normal(0, 0.8, N),          # size_log (mass-correlated)
        rng.normal(0, 1, N),                            # age_log
        (rng.random(N) < 0.2).astype(float),            # is_rsi
    ])

    lad = {}
    lad["2_pca"] = sc
    lad["3_sphere_lift"] = P
    lad["7_subset"] = X[:, :7] if d0 >= 7 else None
    lad["9_native"] = X if d0 == 9 else X[:, :9] if d0 > 9 else None
    lad["16_sh_L3"] = C.real_sh_L3(theta, phi)
    base9 = lad["9_native"] if lad["9_native"] is not None else X
    lad["24_indep_nuisance"] = np.column_stack([base9, nss_indep, meta])
    lad["24_masscorr_nuisance"] = np.column_stack([base9, nss_mass, meta])
    for v in ("native_384_independent", "native_384_replicated", "variant1_l128", "variant2_l384_m3"):
        lad[f"384_{v}"] = fib_lobe_basis(theta, phi, v)
    return {k: v for k, v in lad.items() if v is not None}


def part_A(corpora, reps=100):
    log("PART A: V2(D) ladder")
    rows = []
    for name, (X, seed) in corpora.items():
        lad = build_ladder(X, seed)
        for dim_key, M in lad.items():
            D = M.shape[1]
            f = C.v2_full(M)
            rec = dict(corpus=name, dim_key=dim_key, D=D, N=int(M.shape[0]),
                       V2=f["V2"], r_eff=f["r_eff"], d_eff=f["d_eff"],
                       eigs_top6=f["eigs"][:6], two_over_D=2.0 / D,
                       two_over_deff=(2.0 / f["d_eff"] if f["d_eff"] else float("nan")))
            if dim_key in ("7_subset", "9_native", "24_indep_nuisance", "24_masscorr_nuisance"):
                ns = null_stats(M, reps if D <= 24 else 30, seed + D)
                rec["null"] = ns
                rec["dV2"] = f["V2"] - ns["mean"]
                rec["z"] = z_of(f["V2"], ns)
            rows.append(rec)
            log(f"  {name:22s} {dim_key:26s} D={D:4d} V2={f['V2']:.4f} r_eff={f['r_eff']:.2f}")
    C.dump_json(os.path.join(RES, "ladder_VD.json"), dict(created=C.now_iso(), rows=rows))
    return rows


# ==========================================================================
# PART B — V2(N) with the null subtracted (generated corpora)
# ==========================================================================
def part_B():
    log("PART B: V2(N) with null subtracted (latent-class family)")
    z = np.load(os.path.join(DATA, "family_i_latent_class.npz"))
    man = json.load(open(os.path.join(DATA, "MANIFEST.json")))
    meta = {m["run_id"]: m for m in man["families"]["i_latent_class"]}
    rows = []
    for rid in sorted(z.files):
        m = meta[rid]
        if m["sweep"] != "scaling":
            continue
        X = z[rid].astype(float)
        N = X.shape[0]
        reps = 200 if N <= 640 else (100 if N <= 2560 else 60)
        ns = null_stats(X, reps, m["seed"])
        f = C.v2_full(X)
        rows.append(dict(run_id=rid, generator=m["generator"], seed=m["seed"],
                         n_classes=m["params"]["n_classes"], N=N, D=int(X.shape[1]),
                         V2=f["V2"], r_eff=f["r_eff"],
                         V2_null_mean=ns["mean"], V2_null_std=ns["std"], null_reps=reps,
                         dV2=f["V2"] - ns["mean"], z=z_of(f["V2"], ns)))
        log(f"  {rid:18s} V2={f['V2']:.4f} null={ns['mean']:.4f} dV2={rows[-1]['dV2']:+.4f} z={rows[-1]['z']:+7.1f}")
    C.dump_json(os.path.join(RES, "scaling_VN.json"), dict(created=C.now_iso(), rows=rows))
    return rows


# ==========================================================================
# PART C — signal recovery on the curved family
# ==========================================================================
def analyse_curved(X, P_true, seed, null_reps, fit_nulls):
    N, d = X.shape
    f = C.v2_full(X)
    ns = null_stats(X, null_reps, seed, with_fit=fit_nulls)
    P = C.stereographic_lift(C.pca_scores(X, 2))
    paper = C.sphere_fit_paper(P)
    cv = C.sphere_fit_cv(P, seed=seed % 1000)
    rec = dict(N=N, d=d, V2=f["V2"], r_eff=f["r_eff"],
               V2_null_mean=ns["mean"], V2_null_std=ns["std"],
               dV2=f["V2"] - ns["mean"], z=z_of(f["V2"], ns),
               R2_paper=paper["R2"], median_chordal_residual=paper["median_chordal_residual"],
               R2_cv=cv["R2_cv"], median_chordal_residual_cv=cv["median_chordal_residual_cv"],
               embedding_recovery=C.embedding_recovery(P, P_true))
    if "R2_cv_mean" in ns:
        rec["R2_cv_null_mean"] = ns["R2_cv_mean"]
        rec["R2_cv_null_std"] = ns["R2_cv_std"]
        rec["dR2_cv"] = cv["R2_cv"] - ns["R2_cv_mean"]
        rec["z_R2cv"] = ((cv["R2_cv"] - ns["R2_cv_mean"]) / ns["R2_cv_std"]
                         if ns["R2_cv_std"] and np.isfinite(ns["R2_cv_std"]) and ns["R2_cv_std"] > 0
                         else float("nan"))
        rec["R2_paper_null_mean"] = ns["R2_paper_mean"]
    return rec


def part_C(max_reps_small=8, max_reps_big=4):
    log("PART C: signal recovery (curved family)")
    z = np.load(os.path.join(DATA, "family_ii_curved.npz"))
    man = json.load(open(os.path.join(DATA, "MANIFEST.json")))
    meta = [m for m in man["families"]["ii_curved"]]
    rows = []
    for m in meta:
        rid = m["run_id"]
        N = m["N"]
        if m["sweep"] == "signal_recovery":
            cap = max_reps_small if N < 2048 else max_reps_big
            if m["rep"] >= cap:
                continue
            null_reps, fit_nulls = (100 if N == 128 else 50 if N == 512 else 25), 15
        else:  # fpr_calibration
            null_reps, fit_nulls = 60, 30
        X = z[rid].astype(float)
        Pt = z[rid + "__Ptrue"].astype(float)
        rec = analyse_curved(X, Pt, m["seed"], null_reps, fit_nulls)
        rec.update(run_id=rid, seed=m["seed"], generator=m["generator"], s=m["s"],
                   rep=m["rep"], sweep=m["sweep"], null_reps=null_reps)
        rows.append(rec)
        if len(rows) % 20 == 0:
            log(f"  ...{len(rows)} corpora analysed")
    C.dump_json(os.path.join(RES, "signal_recovery.json"), dict(created=C.now_iso(), rows=rows))
    log(f"  {len(rows)} curved corpora analysed")
    return rows


# ==========================================================================
# PART D — finite-size scaling done right + N_c re-analysis
# ==========================================================================
def part_D(n_sub=8):
    log("PART D: finite-size scaling / N_c re-analysis")
    X, _, _ = C.load_real_matrix(REAL)
    Ns = [40, 79, 160, 320, 640, 1280, 2286]
    rows = []
    for N in Ns:
        reps = 200 if N <= 320 else (120 if N <= 1280 else 80)
        subs = n_sub if N < len(X) else 1
        vr, vn, vns = [], [], []
        for s in range(subs):
            rng = np.random.default_rng(424242 + 97 * N + s)
            idx = rng.choice(len(X), size=N, replace=False) if N < len(X) else np.arange(len(X))
            Xs = X[idx]
            ns = null_stats(Xs, reps, 5150 + 13 * N + s)
            vr.append(C.v2(Xs))
            vn.append(ns["mean"])
            vns.append(ns["std"])
        rows.append(dict(N=N, subsamples=subs, null_reps=reps,
                         V2_real=float(np.mean(vr)),
                         V2_real_sd_over_subsamples=float(np.std(vr, ddof=1)) if subs > 1 else 0.0,
                         V2_null_mean=float(np.mean(vn)),
                         V2_null_std=float(np.mean(vns)),
                         dV2=float(np.mean(vr) - np.mean(vn)),
                         z=float((np.mean(vr) - np.mean(vn)) / np.mean(vns)),
                         two_over_D=2.0 / 9.0))
        log(f"  N={N:5d} real={rows[-1]['V2_real']:.4f} null={rows[-1]['V2_null_mean']:.4f} "
            f"dV2={rows[-1]['dV2']:+.4f} z={rows[-1]['z']:+.1f}")

    def slopes(key):
        out = []
        for i in range(1, len(rows)):
            dl = math.log(rows[i]["N"]) - math.log(rows[i - 1]["N"])
            out.append(dict(N_lo=rows[i - 1]["N"], N_hi=rows[i]["N"],
                            midpoint_N=math.sqrt(rows[i]["N"] * rows[i - 1]["N"]),
                            slope=(rows[i][key] - rows[i - 1][key]) / dl))
        return out

    sl_raw, sl_null, sl_d = slopes("V2_real"), slopes("V2_null_mean"), slopes("dV2")
    amax = lambda s: max(s, key=lambda r: abs(r["slope"]))
    # finite-size law for the null: V2_null ~ 2/D + c (D/N)^alpha
    Nn = np.array([r["N"] for r in rows], float)
    yn = np.array([r["V2_null_mean"] for r in rows], float) - 2.0 / 9.0
    A = np.column_stack([np.ones(len(Nn)), np.log(9.0 / Nn)])
    coef, *_ = np.linalg.lstsq(A, np.log(np.clip(yn, 1e-9, None)), rcond=None)
    out = dict(created=C.now_iso(), rows=rows,
               dV2_dlogN=dict(raw_real=sl_raw, null=sl_null, null_subtracted=sl_d),
               max_slope=dict(raw_real=amax(sl_raw), null=amax(sl_null), null_subtracted=amax(sl_d)),
               null_finite_size_fit=dict(model="V2_null(N) = 2/D + c*(D/N)^alpha",
                                         c=float(math.exp(coef[0])), alpha=float(coef[1]),
                                         asymptote=2.0 / 9.0))
    C.dump_json(os.path.join(RES, "finite_size.json"), out)
    return out



# ==========================================================================
# PART D2 — finite-size behaviour of the two nulls separately
#   colperm null = the Marchenko-Pastur / iid ensemble (row structure destroyed)
#   curveball null = fixed margins (row mass preserved)
# ==========================================================================
def part_D2(n_sub=8):
    log("PART D2: finite-size of colperm (MP) null vs curveball null")
    X, _, _ = C.load_real_matrix(REAL)
    Ns = [40, 79, 160, 320, 640, 1280, 2286]
    rows = []
    for N in Ns:
        reps = 200 if N <= 640 else 120
        subs = n_sub if N < len(X) else 1
        cp, cb = [], []
        for s in range(subs):
            rng = np.random.default_rng(424242 + 97 * N + s)
            idx = rng.choice(len(X), size=N, replace=False) if N < len(X) else np.arange(len(X))
            Xs = X[idx]
            cp.append(null_stats(Xs, reps, 7000 + 13 * N + s, kind="colperm")["mean"])
            cb.append(null_stats(Xs, max(30, reps // 4), 8000 + 13 * N + s, kind="curveball")["mean"])
        rows.append(dict(N=N, subsamples=subs, colperm_null=float(np.mean(cp)),
                         curveball_null=float(np.mean(cb)), two_over_D=2.0 / 9.0))
        log(f"  N={N:5d} colperm(MP)={rows[-1]['colperm_null']:.4f} curveball={rows[-1]['curveball_null']:.4f}")
    Nn = np.array([r["N"] for r in rows], float)
    y = np.array([r["colperm_null"] for r in rows], float) - 2.0 / 9.0
    A = np.column_stack([np.ones(len(Nn)), np.log(9.0 / Nn)])
    coef, *_ = np.linalg.lstsq(A, np.log(np.clip(y, 1e-9, None)), rcond=None)
    pred = 2.0 / 9.0 + math.exp(coef[0]) * (9.0 / Nn) ** coef[1]
    ss = 1 - ((np.array([r["colperm_null"] for r in rows]) - pred) ** 2).sum() / \
        ((np.array([r["colperm_null"] for r in rows]) - np.mean([r["colperm_null"] for r in rows])) ** 2).sum()
    out = dict(created=C.now_iso(), rows=rows,
               colperm_fit=dict(model="V2 = 2/D + c*(D/N)^alpha", c=float(math.exp(coef[0])),
                                alpha=float(coef[1]), R2=float(ss), asymptote=2.0 / 9.0),
               note=("wave-1 attributed the N-dependence to Marchenko-Pastur inflation of the "
                     "null; that inflation belongs to the colperm/iid ensemble only. The "
                     "fixed-margin (curveball) null does NOT relax toward 2/D because row "
                     "masses are held fixed."))
    C.dump_json(os.path.join(RES, "finite_size_colperm.json"), out)
    return out


# ==========================================================================
# PART E — GWTC-like samples
# ==========================================================================
def part_E():
    log("PART E: GWTC-like samples")
    z = np.load(os.path.join(DATA, "family_iii_gwtc.npz"))
    man = json.load(open(os.path.join(DATA, "MANIFEST.json")))
    meta = {m["run_id"]: m for m in man["families"]["iii_gwtc"]}
    rows = []
    for rid in sorted(z.files):
        X = z[rid].astype(float)
        m = meta[rid]
        f = C.v2_full(X)
        ns = null_stats(X, 200, m["seed"], kind="colperm")
        P = C.stereographic_lift(C.pca_scores(X, 2))
        rows.append(dict(run_id=rid, seed=m["seed"], generator=m["generator"],
                         N=int(X.shape[0]), D=int(X.shape[1]), V2=f["V2"], r_eff=f["r_eff"],
                         eigs_top6=f["eigs"][:6],
                         V2_null_mean=ns["mean"], V2_null_std=ns["std"],
                         dV2=f["V2"] - ns["mean"], z=z_of(f["V2"], ns),
                         sphere_fit=dict(**C.sphere_fit_paper(P), **C.sphere_fit_cv(P, seed=3))))
        log(f"  {rid:18s} V2={f['V2']:.4f} null={ns['mean']:.4f} z={rows[-1]['z']:+.1f}")
    C.dump_json(os.path.join(RES, "gwtc.json"), dict(created=C.now_iso(), rows=rows))
    return rows


# ==========================================================================
def main(argv=None):
    global DATA, RES, REAL
    ap = argparse.ArgumentParser(description="Ladder / null / sensitivity analyses (parts V, A-E).")
    ap.add_argument("which", nargs="?", default="all",
                    choices=["all", "V", "A", "B", "C", "D", "D2", "E"],
                    help="which part to run (default: all)")
    ap.add_argument("--data-root", default=os.path.join(BUNDLE, "data"),
                    help="root holding samples/ and real/ (default: <bundle>/data)")
    ap.add_argument("--out-root", default=os.path.join(BUNDLE, "results"),
                    help="where result JSON is written (default: <bundle>/results)")
    ap.add_argument("--real", default=None,
                    help="path to the real coverage matrix JSON "
                         "(default: <data-root>/real/per_row_coverage_v3.json)")
    a = ap.parse_args(argv)
    DATA = os.path.join(a.data_root, "samples")
    RES = a.out_root
    REAL = a.real or os.path.join(a.data_root, "real", "per_row_coverage_v3.json")
    C.ensure_dir(RES)
    which = a.which
    if which in ("all", "V"):
        part_V()

    X, _, _ = C.load_real_matrix(REAL)
    zi = np.load(os.path.join(DATA, "family_i_latent_class.npz"))
    zii = np.load(os.path.join(DATA, "family_ii_curved.npz"))
    ziii = np.load(os.path.join(DATA, "family_iii_gwtc.npz"))
    corpora = {
        "real_yubios_2286x9": (X, 11),
        "gen_latent2class_2286x9": (zi["lc2_N2286_d9"].astype(float), 21),
        "gen_latent1class_2286x9": (zi["lc1_N2286_d9"].astype(float), 31),
        "gen_latent3class_2286x9": (zi["lc3_N2286_d9"].astype(float), 41),
        "gen_curved_s1_2048x9": (zii["cv_N2048_d9_s1.0_r0"].astype(float), 51),
        "gen_curved_s0_2048x9": (zii["cv_N2048_d9_s0.0_r0"].astype(float), 61),
        "gen_gwtc_1000x9": (ziii["gwtc_N1000"].astype(float), 71),
    }
    if which in ("all", "A"):
        part_A(corpora)
    if which in ("all", "B"):
        part_B()
    if which in ("all", "C"):
        part_C()
    if which in ("all", "D"):
        part_D()
    if which in ("all", "D2"):
        part_D2()
    if which in ("all", "E"):
        part_E()
    log("DONE " + which)


if __name__ == "__main__":
    main()
