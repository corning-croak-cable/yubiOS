"""
timeseries_build.py — merge every wave-2 result into NEW time series under
data/new-series/, with one uniform record schema, plus results/SUMMARY.md.

Record schema (all series):
  {run_id, seed, generator, params, N, d, V2, V2_null_mean, V2_null_std, z, r_eff,
   sphere_fit: {pc1pc2, R2, median_chordal_residual}, timestamp}

Series
  INDEX.json          catalogue + provenance + aggregate verdicts
  ladder-VD.json      V2 vs feature-space dimension D, real and generated
  scaling-VN.json     V2 vs N with the fixed-margin null subtracted
  signal-recovery.json  planted-amplitude sweep + calibrated false-positive check
  gwtc-new.json       new synthetic BBH matrices and their independent-column null
"""

import argparse
import json
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402
import ladder_correlations as L  # noqa: E402

# --- portable paths -------------------------------------------------------
# Defaults resolve relative to THIS FILE's location inside the bundle, so the
# bundle runs wherever it is unpacked. Override with the CLI flags in main().
HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
RES = os.path.join(BUNDLE, "results")                  # --out-root
DATA = os.path.join(BUNDLE, "data")                   # --data-root
# consolidated series ship under timeseries/new-series/ in the bundle:
OUT = os.path.join(BUNDLE, "timeseries", "new-series")
SAMP = os.path.join(DATA, "samples")
TS = C.now_iso()


def rd(name):
    with open(os.path.join(RES, name)) as fh:
        return json.load(fh)


def rec(run_id, seed, generator, params, N, d, V2, nm, nsd, r_eff, fit):
    z = (V2 - nm) / nsd if (nm is not None and nsd not in (None, 0) and np.isfinite(nsd or np.nan)) else None
    return dict(run_id=run_id, seed=seed, generator=generator, params=params, N=int(N), d=int(d),
                V2=V2, V2_null_mean=nm, V2_null_std=nsd, z=z, r_eff=r_eff,
                sphere_fit=fit, timestamp=TS)


def sphere_fit_of(M, seed=0):
    try:
        P = C.stereographic_lift(C.pca_scores(np.asarray(M, float), 2))
        p = C.sphere_fit_paper(P)
        return dict(pc1pc2=C.v2(M), R2=p["R2"],
                    median_chordal_residual=p["median_chordal_residual"],
                    R2_cv_L23=C.sphere_fit_cv(P, seed=seed)["R2_cv"])
    except Exception as e:  # pragma: no cover
        return dict(pc1pc2=None, R2=None, median_chordal_residual=None, error=str(e))


def build_ladder():
    lad = rd("ladder_VD.json")["rows"]
    X, _, _ = C.load_real_matrix(L.REAL)
    zi = np.load(os.path.join(SAMP, "family_i_latent_class.npz"))
    zii = np.load(os.path.join(SAMP, "family_ii_curved.npz"))
    ziii = np.load(os.path.join(SAMP, "family_iii_gwtc.npz"))
    corpora = {
        "real_yubios_2286x9": (X, 11),
        "gen_latent2class_2286x9": (zi["lc2_N2286_d9"].astype(float), 21),
        "gen_latent1class_2286x9": (zi["lc1_N2286_d9"].astype(float), 31),
        "gen_latent3class_2286x9": (zi["lc3_N2286_d9"].astype(float), 41),
        "gen_curved_s1_2048x9": (zii["cv_N2048_d9_s1.0_r0"].astype(float), 51),
        "gen_curved_s0_2048x9": (zii["cv_N2048_d9_s0.0_r0"].astype(float), 61),
        "gen_gwtc_1000x9": (ziii["gwtc_N1000"].astype(float), 71),
    }
    emb = {k: L.build_ladder(v[0], v[1]) for k, v in corpora.items()}
    out = []
    for r in lad:
        M = emb[r["corpus"]][r["dim_key"]]
        ns = r.get("null") or {}
        out.append(rec(f"{r['corpus']}::{r['dim_key']}", corpora[r["corpus"]][1],
                       "ladder_embedding",
                       dict(corpus=r["corpus"], dim_key=r["dim_key"], D=r["D"],
                            d_eff=r["d_eff"], two_over_D=r["two_over_D"],
                            eigs_top6=r["eigs_top6"], null_kind=ns.get("kind"),
                            null_reps=ns.get("reps")),
                       r["N"], r["D"], r["V2"], ns.get("mean"), ns.get("std"),
                       r["r_eff"], sphere_fit_of(M)))
    C.dump_json(os.path.join(OUT, "ladder-VD.json"),
                dict(created=TS, schema="wave2-v1", n=len(out), records=out))
    return lad, out


def build_scaling():
    rows = rd("scaling_VN.json")["rows"]
    fs = rd("finite_size.json")
    man = json.load(open(os.path.join(SAMP, "MANIFEST.json")))
    meta = {m["run_id"]: m for m in man["families"]["i_latent_class"]}
    zi = np.load(os.path.join(SAMP, "family_i_latent_class.npz"))
    out = []
    for r in rows:
        m = meta[r["run_id"]]
        out.append(rec(r["run_id"], r["seed"], r["generator"], m["params"], r["N"], r["D"],
                       r["V2"], r["V2_null_mean"], r["V2_null_std"], r["r_eff"],
                       sphere_fit_of(zi[r["run_id"]].astype(float))))
    X, _, _ = C.load_real_matrix(L.REAL)
    for r in fs["rows"]:
        idx = np.random.default_rng(424242 + 97 * r["N"]).choice(len(X), size=min(r["N"], len(X)),
                                                                 replace=False)
        out.append(rec(f"real_subsample_N{r['N']}", 424242, "real_yubios_rowsubsample",
                       dict(subsamples=r["subsamples"], null_reps=r["null_reps"],
                            source="cycle-20/per_row_coverage_v3.json"),
                       r["N"], 9, r["V2_real"], r["V2_null_mean"], r["V2_null_std"],
                       2.0 / r["V2_real"], sphere_fit_of(X[idx])))
    C.dump_json(os.path.join(OUT, "scaling-VN.json"),
                dict(created=TS, schema="wave2-v1", n=len(out), records=out,
                     null_finite_size_fit=fs["null_finite_size_fit"],
                     dV2_dlogN=fs["dV2_dlogN"], max_slope=fs["max_slope"]))
    return rows, fs, out


def build_signal():
    rows = rd("signal_recovery.json")["rows"]
    man = json.load(open(os.path.join(SAMP, "MANIFEST.json")))
    meta = {m["run_id"]: m for m in man["families"]["ii_curved"]}
    out = []
    for r in rows:
        p = dict(meta[r["run_id"]]["params"])
        p.update(sweep=r["sweep"], rep=r["rep"], null_reps=r["null_reps"],
                 dV2=r["dV2"], dR2_cv=r.get("dR2_cv"), z_R2cv=r.get("z_R2cv"),
                 R2_cv=r["R2_cv"], R2_cv_null_mean=r.get("R2_cv_null_mean"),
                 embedding_recovery=r["embedding_recovery"])
        out.append(rec(r["run_id"], r["seed"], r["generator"], p, r["N"], r["d"],
                       r["V2"], r["V2_null_mean"], r["V2_null_std"], r["r_eff"],
                       dict(pc1pc2=r["V2"], R2=r["R2_paper"],
                            median_chordal_residual=r["median_chordal_residual"],
                            R2_cv_L23=r["R2_cv"])))
    C.dump_json(os.path.join(OUT, "signal-recovery.json"),
                dict(created=TS, schema="wave2-v1", n=len(out), records=out))
    return rows, out


def build_gwtc():
    rows = rd("gwtc.json")["rows"]
    man = json.load(open(os.path.join(SAMP, "MANIFEST.json")))
    meta = {m["run_id"]: m for m in man["families"]["iii_gwtc"]}
    out = []
    for r in rows:
        sf = r["sphere_fit"]
        out.append(rec(r["run_id"], r["seed"], r["generator"], meta[r["run_id"]]["params"],
                       r["N"], r["D"], r["V2"], r["V2_null_mean"], r["V2_null_std"], r["r_eff"],
                       dict(pc1pc2=r["V2"], R2=sf["R2"],
                            median_chordal_residual=sf["median_chordal_residual"],
                            R2_cv_L23=sf["R2_cv"])))
    C.dump_json(os.path.join(OUT, "gwtc-new.json"),
                dict(created=TS, schema="wave2-v1", n=len(out), records=out))
    return rows, out


# ------------------------------------------------------------------ aggregates
def agg_signal(rows):
    cells = {}
    for r in rows:
        if r["sweep"] != "signal_recovery":
            continue
        k = (r["N"], r["d"], r["s"])
        cells.setdefault(k, []).append(r)
    table = []
    for k in sorted(cells):
        g = cells[k]
        f = lambda key: np.array([x[key] for x in g if x.get(key) is not None], float)
        table.append(dict(
            N=k[0], d=k[1], s=k[2], reps=len(g),
            V2=float(f("V2").mean()), V2_null=float(f("V2_null_mean").mean()),
            dV2=float(f("dV2").mean()), dV2_sd=float(f("dV2").std(ddof=1)),
            z=float(f("z").mean()), z_sd=float(f("z").std(ddof=1)),
            det_rate_z=float((f("z") > 1.645).mean()),
            R2_paper=float(f("R2_paper").mean()),
            R2_cv=float(f("R2_cv").mean()), R2_cv_null=float(f("R2_cv_null_mean").mean()),
            dR2_cv=float(f("dR2_cv").mean()), z_R2cv=float(f("z_R2cv").mean()),
            det_rate_zR2=float((f("z_R2cv") > 1.645).mean()),
            embedding_recovery=float(f("embedding_recovery").mean()),
        ))
    fpr = [r for r in rows if r["sweep"] == "fpr_calibration"]
    zz = np.array([r["z"] for r in fpr], float)
    zr = np.array([r["z_R2cv"] for r in fpr], float)
    fprd = dict(
        n=len(fpr), N=512, d=9, s=0.0,
        z_mean=float(zz.mean()), z_sd=float(zz.std(ddof=1)),
        fpr_one_sided_z_gt_1_645=float((zz > 1.645).mean()),
        fpr_two_sided_absz_gt_1_96=float((np.abs(zz) > 1.96).mean()),
        zR2_mean=float(zr.mean()), zR2_sd=float(zr.std(ddof=1)),
        fpr_one_sided_zR2_gt_1_645=float((zr > 1.645).mean()),
        fpr_two_sided_abszR2_gt_1_96=float((np.abs(zr) > 1.96).mean()),
    )
    return table, fprd


def md_table(headers, rows_):
    s = "| " + " | ".join(headers) + " |\n|" + "|".join(["---"] * len(headers)) + "|\n"
    for r in rows_:
        s += "| " + " | ".join(str(x) for x in r) + " |\n"
    return s


def main(argv=None):
    global RES, DATA, OUT, SAMP
    ap = argparse.ArgumentParser(description="Consolidate results into the timeseries INDEX + SUMMARY.")
    ap.add_argument("--data-root", default=os.path.join(BUNDLE, "data"),
                    help="root holding samples/ (default: <bundle>/data)")
    ap.add_argument("--out-root", default=os.path.join(BUNDLE, "results"),
                    help="root holding results JSON (default: <bundle>/results)")
    ap.add_argument("--series-out", default=os.path.join(BUNDLE, "timeseries", "new-series"),
                    help="where the consolidated series are written")
    a = ap.parse_args(argv)
    DATA, RES, OUT = a.data_root, a.out_root, a.series_out
    SAMP = os.path.join(DATA, "samples")
    C.ensure_dir(OUT)
    lad, lad_rec = build_ladder()
    sc, fs, sc_rec = build_scaling()
    sig, sig_rec = build_signal()
    gw, gw_rec = build_gwtc()
    val = rd("validation.json")
    fsc = rd("finite_size_colperm.json")
    table, fprd = agg_signal(sig)

    index = dict(
        created=TS, schema="wave2-v1",
        provenance=dict(
            scripts=[f"{ROOT}/scripts/{n}" for n in
                     ("common.py", "generate_samples.py", "ladder_correlations.py",
                      "timeseries_build.py")],
            generated_data=f"{ROOT}/data/samples",
            raw_results=RES,
            real_matrix=L.REAL,
            null="fixed-margin curveball (binary) / independent column permutation (continuous)",
            curveball_trades=f"{L.TRADE_MULT}N",
        ),
        series={
            "ladder-VD.json": dict(n=len(lad_rec), description="V2 vs feature-space dimension D"),
            "scaling-VN.json": dict(n=len(sc_rec), description="V2 vs N, null-subtracted"),
            "signal-recovery.json": dict(n=len(sig_rec), description="planted-amplitude sweep + FPR"),
            "gwtc-new.json": dict(n=len(gw_rec), description="new synthetic BBH matrices + null"),
        },
        validation=val["uniformity"] | dict(cross_check=val["cross_check_real_matrix"]),
        signal_recovery_table=table,
        false_positive_check=fprd,
        finite_size=dict(rows=fs["rows"], max_slope=fs["max_slope"],
                         null_fit=fs["null_finite_size_fit"],
                         null_ensembles_vs_N=fsc["rows"], colperm_fit=fsc["colperm_fit"],
                         note=fsc["note"]),
        sh_constants=C.sh_constants(),
    )
    C.dump_json(os.path.join(OUT, "INDEX.json"), index)

    # ------------------------------------------------------------- SUMMARY.md
    L_by = {}
    for r in lad:
        L_by.setdefault(r["dim_key"], {})[r["corpus"]] = r
    order = ["2_pca", "3_sphere_lift", "7_subset", "9_native", "16_sh_L3",
             "24_indep_nuisance", "24_masscorr_nuisance", "384_native_384_independent",
             "384_native_384_replicated", "384_variant1_l128", "384_variant2_l384_m3"]
    cols = ["real_yubios_2286x9", "gen_latent2class_2286x9", "gen_latent1class_2286x9",
            "gen_latent3class_2286x9", "gen_curved_s1_2048x9", "gen_gwtc_1000x9"]
    t1 = md_table(["dim_key", "D", "2/D"] + [c.replace("gen_", "").replace("_2286x9", "").replace("_2048x9", "").replace("_1000x9", "") for c in cols],
                  [[k, L_by[k][cols[0]]["D"], f"{2.0/L_by[k][cols[0]]['D']:.4f}"] +
                   [f"{L_by[k][c]['V2']:.4f} (r={L_by[k][c]['r_eff']:.2f})" for c in cols]
                   for k in order])
    t2 = md_table(["N", "d", "s", "reps", "V2", "V2_null", "dV2", "z", "det@z>1.645",
                   "R2_paper", "R2_cv", "dR2_cv", "z_R2cv", "emb_recovery"],
                  [[r["N"], r["d"], r["s"], r["reps"], f"{r['V2']:.4f}", f"{r['V2_null']:.4f}",
                    f"{r['dV2']:+.4f}", f"{r['z']:+.2f}", f"{r['det_rate_z']:.2f}",
                    f"{r['R2_paper']:.4f}", f"{r['R2_cv']:.4f}", f"{r['dR2_cv']:+.4f}",
                    f"{r['z_R2cv']:+.2f}", f"{r['embedding_recovery']:.4f}"] for r in table])
    t3 = md_table(["N", "V2_real", "V2_null", "dV2", "z", "2/D"],
                  [[r["N"], f"{r['V2_real']:.4f}", f"{r['V2_null_mean']:.4f}",
                    f"{r['dV2']:+.4f}", f"{r['z']:+.1f}", f"{r['two_over_D']:.4f}"]
                   for r in fs["rows"]])
    t4 = md_table(["window", "d(raw V2)/dlogN", "d(null V2)/dlogN", "d(dV2)/dlogN"],
                  [[f"{a['N_lo']}-{a['N_hi']}", f"{a['slope']:+.4f}", f"{b['slope']:+.4f}",
                    f"{c['slope']:+.4f}"]
                   for a, b, c in zip(fs["dV2_dlogN"]["raw_real"], fs["dV2_dlogN"]["null"],
                                      fs["dV2_dlogN"]["null_subtracted"])])
    t5 = md_table(["run_id", "N", "V2", "null", "z", "r_eff", "R2_paper", "R2_cv"],
                  [[r["run_id"], r["N"], f"{r['V2']:.4f}", f"{r['V2_null_mean']:.4f}",
                    f"{r['z']:+.1f}", f"{r['r_eff']:.2f}", f"{r['sphere_fit']['R2']:.4f}",
                    f"{r['sphere_fit']['R2_cv']:.4f}"] for r in gw])
    t6 = md_table(["run_id", "classes", "N", "V2", "null", "dV2", "z"],
                  [[r["run_id"], r["n_classes"], r["N"], f"{r['V2']:.4f}",
                    f"{r['V2_null_mean']:.4f}", f"{r['dV2']:+.4f}", f"{r['z']:+.1f}"]
                   for r in sorted(sc, key=lambda x: (x["n_classes"], x["N"]))])

    t3b = md_table(["N", "colperm (MP/iid) null", "curveball (fixed-margin) null", "2/D"],
                   [[r["N"], f"{r['colperm_null']:.4f}", f"{r['curveball_null']:.4f}",
                     f"{r['two_over_D']:.4f}"] for r in fsc["rows"]])
    cc = val["cross_check_real_matrix"]
    body = f"""# Wave-2 results summary

Generated {TS}. Null = fixed-margin curveball ({L.TRADE_MULT}N trades) for binary
matrices, independent column permutation for continuous ones.

## 0. Null validation
- Curveball uniformity, exhaustive 6x4 ensemble ({val['uniformity']['ensemble_size']} matrices,
  {val['uniformity']['draws']} draws): chi2 = {val['uniformity']['chi2']:.1f},
  df = {val['uniformity']['df']}, p = {val['uniformity']['p_value']:.3f} -> {val['uniformity']['verdict']}.
- Real 2286x9: V2 = {cc['real_V2']:.4f}; curveball {cc['curveball_mean']:.4f} +- {cc['curveball_std']:.4f};
  independent swap chain {cc['swap_chain_mean']:.4f} +- {cc['swap_chain_std']:.4f}.
  Wave-1 reported {cc['wave1_reported_curveball']} for the same null: NOT reproduced.

## 1. Ladder: V2(D), same rows, changing feature space
{t1}

## 2. Signal recovery vs planted amplitude s
{t2}

### Calibrated false-positive check (s = 0, N = 512, d = 9, {fprd['n']} fresh corpora)
- z(dV2): mean {fprd['z_mean']:+.3f} sd {fprd['z_sd']:.3f};
  one-sided FPR at z > 1.645 = {fprd['fpr_one_sided_z_gt_1_645']:.3f};
  two-sided at |z| > 1.96 = {fprd['fpr_two_sided_absz_gt_1_96']:.3f}
- z(dR2_cv): mean {fprd['zR2_mean']:+.3f} sd {fprd['zR2_sd']:.3f};
  one-sided FPR = {fprd['fpr_one_sided_zR2_gt_1_645']:.3f};
  two-sided = {fprd['fpr_two_sided_abszR2_gt_1_96']:.3f}

## 3. Finite-size scaling and the N_c ~ 40 claim
{t3}
Null finite-size law fit: V2_null(N) = 2/D + {fs['null_finite_size_fit']['c']:.4f} * (D/N)^{fs['null_finite_size_fit']['alpha']:.4f}
(asymptote 2/D = {fs['null_finite_size_fit']['asymptote']:.4f}).

{t4}

### Which null carries the N-dependence
{t3b}
Column-permutation (MP/iid) null fit: V2 = 2/D + {fsc['colperm_fit']['c']:.4f}*(D/N)^{fsc['colperm_fit']['alpha']:.4f},
R2 = {fsc['colperm_fit']['R2']:.4f}. The fixed-margin null does NOT relax toward 2/D
(row masses are held fixed), so the wave-1 "MP inflation" story applies only to the iid ensemble.

Largest |slope|: raw {fs['max_slope']['raw_real']['N_lo']}-{fs['max_slope']['raw_real']['N_hi']}
({fs['max_slope']['raw_real']['slope']:+.4f}); null {fs['max_slope']['null']['N_lo']}-{fs['max_slope']['null']['N_hi']}
({fs['max_slope']['null']['slope']:+.4f}); null-subtracted {fs['max_slope']['null_subtracted']['N_lo']}-{fs['max_slope']['null_subtracted']['N_hi']}
({fs['max_slope']['null_subtracted']['slope']:+.4f}).

## 4. Latent-class scaling (generated, ground truth known)
{t6}

## 5. GWTC-like new samples
{t5}

## 6. Y_3^3 constants
complex sqrt(35/(64pi)) = {C.sh_constants()['complex_correct']:.6f};
real-orthonormal sqrt(70/(64pi)) = {C.sh_constants()['real_orthonormal_correct']:.6f};
published sqrt(245/(64pi)) = {C.sh_constants()['published_wrong']:.6f}
(ratio {C.sh_constants()['ratio_wrong_over_complex']:.6f} = sqrt(7)).
"""
    with open(os.path.join(RES, "SUMMARY.md"), "w") as fh:
        fh.write(body)
    print("wrote", os.path.join(OUT, "INDEX.json"), "and", os.path.join(RES, "SUMMARY.md"))
    print(f"series sizes: ladder={len(lad_rec)} scaling={len(sc_rec)} signal={len(sig_rec)} gwtc={len(gw_rec)}")


if __name__ == "__main__":
    main()
