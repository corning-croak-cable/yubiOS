#!/usr/bin/env python3.12
"""
p4_variance_ratio.py -- calibrated re-aggregation of the GL P4 fluctuation sweep.

Advisor risk R1: Var[dV2](N) computed by row-subsampling a single finite corpus
carries a built-in decay proportional to the finite-population factor
(1/N - 1/N_tot); the raw sweep therefore has no calibrated baseline and an
apparent "no peak" can be an artefact of that decay.

This script re-runs the P4 sweep and reports, at each N:

  * Var_meas(N)  = Var over reps of  dV2 = V2(subsample) - mean(V2 curveball null)
  * Var_null(N)  = variance of V2 across the curveball draws themselves at the
                   same N, pooled over reps (the calibrated null fluctuation)
  * ratio(N)     = Var_meas(N) / Var_null(N)            <-- the R1 statistic
  * base(N)      = (1/N - 1/N_tot), the finite-population subsampling baseline,
                   printed beside the measured column (normalised at the first N)

N = N_tot is deliberately NOT on the grid: subsampling N_tot of N_tot is
deterministic, so its residual spread is null-estimator noise only and it must
not enter a monotonicity claim.

Paths are bundle-relative. Every seed used is logged into the output JSON.

Usage:
    python3.12 scripts/p4_variance_ratio.py --bundle . --out results/p4-variance-ratio.json
"""

import argparse
import json
import os
import sys
import time

import numpy as np

T0 = time.time()


def log(msg):
    print(f"[{time.time() - T0:7.1f}s] {msg}", flush=True)


def load_common(bundle):
    sys.path.insert(0, os.path.join(bundle, "scripts"))
    import common as C
    return C


def sweep(C, X, Ns, reps, null_reps, seed):
    """One row per N. Returns list of dicts."""
    N_tot = len(X)
    rows = []
    for N in Ns:
        d_vals, null_var_per_rep, null_all = [], [], []
        for s_ in range(reps):
            rng = np.random.default_rng(seed + 97 * N + s_)
            idx = (rng.choice(N_tot, size=N, replace=False)
                   if N < N_tot else np.arange(N_tot))
            Xs = X[idx]
            v = C.v2(Xs)
            nseed = seed + 13 * N + s_
            nulls = [C.v2(C.curveball_fast(Xs, nseed * 1000003 + i,
                                           n_trades=10 * N))
                     for i in range(null_reps)]
            nulls = np.asarray([x for x in nulls if np.isfinite(x)], float)
            d_vals.append(float(v - nulls.mean()))
            null_var_per_rep.append(float(nulls.var(ddof=1)))
            null_all.extend(float(x) for x in nulls)

        d = np.asarray(d_vals, float)
        var_meas = float(d.var(ddof=1))
        var_null_within = float(np.mean(null_var_per_rep))
        var_null_pooled = float(np.asarray(null_all, float).var(ddof=1))

        bs = np.random.default_rng(90000 + N)
        bv = np.array([d[bs.integers(0, len(d), len(d))].var(ddof=1)
                       for _ in range(4000)])
        lo, hi = (float(x) for x in np.percentile(bv, [2.5, 97.5]))

        rows.append(dict(
            N=int(N), reps=int(reps), null_reps=int(null_reps),
            dV2_mean=float(d.mean()),
            var_meas=var_meas,
            var_meas_ci95=[lo, hi],
            var_null_within_rep=var_null_within,
            var_null_pooled=var_null_pooled,
            ratio_within=var_meas / var_null_within,
            ratio_within_ci95=[lo / var_null_within, hi / var_null_within],
            ratio_pooled=var_meas / var_null_pooled,
            fp_baseline=float(1.0 / N - 1.0 / N_tot),
            dV2_values=[float(x) for x in d],
            null_var_per_rep=null_var_per_rep,
        ))
        log(f"  N={N:5d} Var_meas={var_meas:.3e} Var_null={var_null_within:.3e} "
            f"ratio={rows[-1]['ratio_within']:.3f} "
            f"CI95=[{rows[-1]['ratio_within_ci95'][0]:.3f},"
            f"{rows[-1]['ratio_within_ci95'][1]:.3f}] "
            f"fp_base={rows[-1]['fp_baseline']:.3e}")
    return rows


def verdict(rows):
    r = np.array([x["ratio_within"] for x in rows])
    i = int(np.argmax(r))
    interior = bool(0 < i < len(r) - 1)
    out = {
        "argmax_index": i,
        "argmax_N": rows[i]["N"],
        "argmax_ratio": float(r[i]),
        "is_interior": interior,
        "ratio_min": float(r.min()),
        "ratio_max": float(r.max()),
        "ratio_max_over_min": float(r.max() / r.min()),
        "ratio_monotone_decreasing": bool(np.all(np.diff(r) < 0)),
    }
    if interior:
        lo_i = rows[i]["ratio_within_ci95"][0]
        out["beats_left_neighbour"] = bool(lo_i > rows[i - 1]["ratio_within_ci95"][1])
        out["beats_right_neighbour"] = bool(lo_i > rows[i + 1]["ratio_within_ci95"][1])
        out["significant_interior_peak"] = bool(
            out["beats_left_neighbour"] and out["beats_right_neighbour"])
    else:
        out["significant_interior_peak"] = False
    # excess of the low-N band (40-79) over the high-N plateau (>=160)
    lowband = r[:2]
    plateau = r[2:]
    out["low_band_mean_ratio"] = float(lowband.mean())
    out["plateau_mean_ratio"] = float(plateau.mean())
    out["low_band_excess_factor"] = float(lowband.mean() / plateau.mean())
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--bundle", default=".",
                    help="bundle root (contains scripts/, data/, results/)")
    ap.add_argument("--out", default="results/p4-variance-ratio.json",
                    help="output path, bundle-relative unless absolute")
    ap.add_argument("--grid", default="40,79,160,320,640,1280")
    ap.add_argument("--reps", type=int, default=40)
    ap.add_argument("--null-reps", type=int, default=20)
    ap.add_argument("--seed", type=int, default=424242,
                    help="master seed; matches the original P4 sweep")
    a = ap.parse_args(argv)

    bundle = os.path.abspath(a.bundle)
    C = load_common(bundle)
    real = os.path.join(bundle, "data", "real", "per_row_coverage_v3.json")
    X, prim, _ = C.load_real_matrix(real)
    Ns = [int(x) for x in a.grid.split(",")]

    log(f"bundle={bundle} matrix={X.shape} seed={a.seed} "
        f"reps={a.reps} null_reps={a.null_reps} grid={Ns}")
    rows = sweep(C, X, Ns, a.reps, a.null_reps, a.seed)
    v = verdict(rows)

    res = {
        "created": C.now_iso(),
        "script": "scripts/p4_variance_ratio.py",
        "purpose": ("advisor R1: Var[dV2](N) normalised by the curveball-null "
                    "variance at the same N, with the (1/N - 1/N_tot) "
                    "finite-population baseline printed alongside"),
        "matrix": {"path": os.path.relpath(real, bundle),
                   "shape": list(X.shape), "primitives": prim},
        "seeds": {"master": a.seed,
                  "subsample_rng": "default_rng(seed + 97*N + rep)",
                  "null_rng": "curveball_fast(seed + 13*N + rep, *1000003 + i)",
                  "bootstrap_rng": "default_rng(90000 + N)"},
        "grid": Ns,
        "N_total": int(len(X)),
        "N_2286_excluded": True,
        "N_2286_exclusion_reason": ("subsampling 2286 of 2286 is deterministic; "
                                    "residual spread is null-estimator noise and "
                                    "cannot enter a monotonicity claim"),
        "reps": a.reps, "null_reps": a.null_reps,
        "rows": rows,
        "verdict": v,
        "runtime_seconds": round(time.time() - T0, 1),
    }
    out = a.out if os.path.isabs(a.out) else os.path.join(bundle, a.out)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w") as fh:
        json.dump(res, fh, indent=2)
    log(f"wrote {out} ({res['runtime_seconds']}s)")

    print("\n N     Var_meas    Var_null    ratio    ratio CI95           "
          "fp_base(1/N-1/2286)  fp_base_norm  Var_meas_norm")
    b0 = rows[0]["fp_baseline"]
    m0 = rows[0]["var_meas"]
    for r in rows:
        print(f"{r['N']:5d}  {r['var_meas']:.4e}  {r['var_null_within_rep']:.4e}  "
              f"{r['ratio_within']:6.3f}  "
              f"[{r['ratio_within_ci95'][0]:.3f},{r['ratio_within_ci95'][1]:.3f}]   "
              f"{r['fp_baseline']:.4e}           "
              f"{r['fp_baseline']/b0:6.3f}        {r['var_meas']/m0:6.3f}")
    print(f"\nverdict: {json.dumps(v, indent=2)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
