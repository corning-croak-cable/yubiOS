#!/usr/bin/env python3.12
"""
run_real_corpora.py — runs the full null-model + Hodge battery on the real
corpora and writes every number to results/*.json.

Corpora
-------
yubiOS 2286      cycle-20/per_row_coverage_v3.json (the master matrix)
  whole, per regime (eligible c>=5 / deferred 1<=c<=4 / refused c==0,
  the cycle-18 regime_threshold_k=5 rule, verified to reproduce 1294/212/38
  on the cycle-18 1544-row file), per corpus (skills/docs/refs/self)
yubiOS 1391      cycle-18/per_row_coverage.json
CIS 447          dev-sec InSpec .rb control blocks, cycle-30-l122/work
SCAP SSG 2107    ComplianceAsCode rule.yml, .tmp/l112/ssg_full_extract
SCAP SSG 385     .tmp/l112/ssg/rules/*.yml (the ssg_v2_results.json subset)

CIS and SSG are scored with the program's own 9-primitive keyword mapping,
reused by direct import from cycle-34-l142/l142_compute.py so that the scoring
function is byte-identical to the one that produced the published numbers.

Stages (--stage):
  a   V2 reproduction + 4 matrix nulls + Marchenko-Pastur baseline
  b   Hodge on yubiOS + curveball-matrix null + degree-rewired-graph null
  c   P-H1 (rho_h vs N), P-H2 (rho_c vs 1-V2 across corpora), P-H3 (defect lift)
  d   construction sensitivity (knn k=8, knn k=16, threshold, coverage band)
  all everything

    python3.12 run_real_corpora.py --stage all --out-dir ../results
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from hodge_decompose import (  # noqa: E402
    build_graph, enumerate_triangles, hodge_decompose, harmonic_lift,
    load_coverage_json, run_full,
)
from null_models import (  # noqa: E402
    curveball, degree_rewire, mp_baseline, null_distribution, stat_V2,
    stat_V2_cov,
)

# --- portable paths -------------------------------------------------------
# Defaults resolve relative to THIS FILE's location inside the bundle, so the
# bundle runs wherever it is unpacked. Override with the CLI flags in main().
HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
# The 2286x9 master ships with the bundle. Overridable with --master.
MASTER = os.path.join(BUNDLE, "data", "real", "per_row_coverage_v3.json")
# EXTERNAL INPUTS -- not shipped in this bundle. These three defaults point at
# the authoring workspace and will not exist elsewhere; the corpora that need
# them are skipped with a recorded load failure unless the path is supplied on
# the command line (--cycle18 / --l142 / --ssg-dir).
CYCLE18 = os.environ.get("CYCLE18_JSON", "/var/workspace/session/extracted/"
                         "guided-curve-ideate-iteration-cycles-with-34-492025d7/cycle-18/"
                         "per_row_coverage.json")
L142 = "/var/workspace/documents/personal-WbtUgeUv/cycle-34-l142/l142_compute.py"
SSG385_DIR = "/var/workspace/documents/personal-WbtUgeUv/.tmp/l112/ssg/rules"

SEED = 20260812


# --------------------------------------------------------------------------
# corpora
# --------------------------------------------------------------------------


def _l142():
    spec = importlib.util.spec_from_file_location("l142", L142)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def load_all_corpora(verbose=True) -> dict:
    out: dict[str, dict] = {}
    failures: dict[str, str] = {}

    M, meta, prim = load_coverage_json(MASTER)
    c = M.sum(1)
    out["yubios_2286"] = {"M": M, "source": MASTER}
    out["yubios_eligible"] = {"M": M[c >= 5], "source": MASTER + " [c>=5]"}
    out["yubios_deferred"] = {"M": M[(c >= 1) & (c <= 4)], "source": MASTER + " [1<=c<=4]"}
    out["yubios_refused"] = {"M": M[c == 0], "source": MASTER + " [c==0]"}
    for corp in ("skills", "docs", "refs", "self"):
        sel = np.array([r["corpus"] == corp for r in meta])
        out[f"yubios_{corp}"] = {"M": M[sel], "source": MASTER + f" [corpus={corp}]"}

    try:
        M18, meta18, _ = load_coverage_json(CYCLE18)
        out["yubios_1391_cycle18"] = {"M": M18, "source": CYCLE18}
    except Exception as e:  # pragma: no cover
        failures["yubios_1391_cycle18"] = repr(e)

    try:
        m = _l142()
        Mc, _ = m.load_cis()
        out["cis_447"] = {"M": Mc, "source": "cycle-30-l122/work/*.rb (dev-sec InSpec)"}
        Ms, _ = m.load_scap_ssg()
        out["scap_ssg_2107"] = {"M": Ms, "source": ".tmp/l112/ssg_full_extract .../rule.yml"}
        # 385-rule subset used by ssg_v2_results.json
        try:
            from pathlib import Path
            texts = []
            for f in sorted(Path(SSG385_DIR).glob("*.yml")):
                d = m.parse_yaml_simple(f.read_text(errors="ignore"))
                txt = " ".join(str(d.get(k, "")) for k in
                               ("title", "description", "rationale"))
                txt = m.strip_jinja_html(txt).strip()
                if txt:
                    texts.append(txt)
            if texts:
                out["scap_ssg_rules_dir"] = {
                    "M": m.build_coverage(texts),
                    "source": SSG385_DIR + "/*.yml"}
        except Exception as e:
            failures["scap_ssg_rules_dir"] = repr(e)
    except Exception as e:
        failures["external_corpora"] = repr(e)

    for k, v in out.items():
        v["N"] = int(v["M"].shape[0])
        v["colsums"] = v["M"].sum(0).tolist()
        v["n_zero_rows"] = int((v["M"].sum(1) == 0).sum())
    if verbose:
        for k, v in out.items():
            print(f"  corpus {k:26s} N={v['N']:5d} zero-rows={v['n_zero_rows']}",
                  file=sys.stderr)
        for k, v in failures.items():
            print(f"  FAILED  {k}: {v}", file=sys.stderr)
    return out, failures


# --------------------------------------------------------------------------
# Hodge statistic as a function of M (rebuilds the graph -- the correct null
# per the Kahle warning: the null must go through the SAME construction)
# --------------------------------------------------------------------------


def hodge_stat_factory(graph="knn", k=8, tau=0.35, band=1, edge_cap=60000,
                       tri_cap=400000, seed=SEED, betti=True):
    counter = {"n": 0}

    def fn(M):
        counter["n"] += 1
        s = seed + 1000 * counter["n"]
        try:
            res, arrays, edges, tris = run_full(
                M, graph, k=k, tau=tau, band=band, edge_cap=edge_cap,
                tri_cap=tri_cap, seed=s, compute_betti=betti)
        except RuntimeError:
            return {"rho_grad": None, "rho_curl": None, "rho_harm": None,
                    "beta1": None, "n_edges": None, "n_triangles": None}
        d = {"rho_grad": res["rho_grad"], "rho_curl": res["rho_curl"],
             "rho_harm": res["rho_harm"], "n_edges": float(res["n_edges"]),
             "n_triangles": float(res["n_triangles"])}
        d["beta1"] = float(res["betti"]["beta1"]) if betti else None
        return d

    return fn


def hodge_with_graph_null(M, graph="knn", k=8, tau=0.35, band=1,
                          edge_cap=60000, tri_cap=400000, nsamp=50,
                          seed=SEED, betti=True, n_swaps_per_edge=3):
    """Real run + degree-preserving rewiring null of the SAME graph (Kahle null)."""
    edges, ginfo = build_graph(M, graph, k=k, tau=tau, band=band,
                               edge_cap=edge_cap, seed=seed)
    tris, trunc = enumerate_triangles(edges, M.shape[0], tri_cap=tri_cap, seed=seed)
    real, arrays = hodge_decompose(M, edges, tris, compute_betti=betti)
    ginfo["triangles_truncated"] = bool(trunc)
    real["graph"] = ginfo

    rng = np.random.default_rng(seed + 7)
    samples = []
    for b in range(nsamp):
        e2, sw = degree_rewire(edges, n_swaps_per_edge=n_swaps_per_edge, rng=rng)
        t2, _ = enumerate_triangles(e2, M.shape[0], tri_cap=tri_cap, seed=seed + b)
        try:
            r2, _a = hodge_decompose(M, e2, t2, compute_betti=betti)
        except RuntimeError:
            continue
        samples.append({"rho_grad": r2["rho_grad"], "rho_curl": r2["rho_curl"],
                        "rho_harm": r2["rho_harm"],
                        "beta1": float(r2["betti"]["beta1"]) if betti else None,
                        "n_triangles": float(r2["n_triangles"])})
    return real, samples, arrays, edges


def zsum(realv, vals):
    vals = np.asarray([v for v in vals if v is not None], dtype=float)
    if realv is None or len(vals) < 2:
        return {"real": realv, "null_mean": None, "null_sd": None, "z": None,
                "n_samples": int(len(vals))}
    mu, sd = float(vals.mean()), float(vals.std(ddof=1))
    return {"real": float(realv), "null_mean": mu, "null_sd": sd,
            "z": float((realv - mu) / sd) if sd > 0 else None,
            "null_p2.5": float(np.percentile(vals, 2.5)),
            "null_p97.5": float(np.percentile(vals, 97.5)),
            "n_samples": int(len(vals))}


def spearman(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    from scipy.stats import spearmanr
    r = spearmanr(x, y)
    return float(r.statistic), float(r.pvalue)


# --------------------------------------------------------------------------
# stages
# --------------------------------------------------------------------------


def stage_a(corpora, out_dir, nsamp=200):
    print("[a] V2 + matrix nulls", file=sys.stderr)
    res = {"seed": SEED, "nsamp": nsamp, "stage": "a", "corpora": {}}
    for name, cv in corpora.items():
        M = cv["M"]
        if M.shape[0] < 10 or M.std(0).sum() == 0:
            res["corpora"][name] = {"N": int(M.shape[0]),
                                    "skipped": "degenerate (N<10 or zero-variance columns)",
                                    "V2": None}
            continue
        entry = {"N": int(M.shape[0]), "source": cv["source"],
                 "V2_corr": stat_V2(M), "V2_cov": stat_V2_cov(M),
                 "colsums": cv["colsums"], "n_zero_rows": cv["n_zero_rows"],
                 "mp_baseline": mp_baseline(*M.shape)}
        ns = nsamp if name == "yubios_2286" else max(50, nsamp // 4)
        for null in ("curveball", "colperm", "bernoulli", "rowperm"):
            t0 = time.time()
            entry[f"null_{null}"] = null_distribution(
                M, stat_V2, null=null, nsamp=ns, seed=SEED)
            entry[f"null_{null}"]["seconds"] = time.time() - t0
        res["corpora"][name] = entry
        print(f"    {name}: V2={entry['V2_corr']:.6f} "
              f"curveball z={entry['null_curveball']['z']}", file=sys.stderr)
    with open(f"{out_dir}/A-v2-nulls.json", "w") as fh:
        json.dump(res, fh, indent=2)
    return res


def stage_b(corpora, out_dir, nsamp_matrix=50, nsamp_graph=50):
    print("[b] Hodge on yubiOS + nulls", file=sys.stderr)
    M = corpora["yubios_2286"]["M"]
    real, gsamples, arrays, edges = hodge_with_graph_null(
        M, "knn", k=8, nsamp=nsamp_graph, seed=SEED, betti=True)
    fn = hodge_stat_factory("knn", k=8, seed=SEED, betti=True)
    t0 = time.time()
    mnull = null_distribution(M, fn, null="curveball", nsamp=nsamp_matrix,
                             seed=SEED, progress=True)
    res = {
        "stage": "b", "seed": SEED, "construction": "knn k=8, Construction A1",
        "real": real,
        "null_curveball_matrix_same_construction": mnull,
        "null_degree_rewire_same_graph": {
            k: zsum(real[k] if k in real else real["betti"]["beta1"],
                    [s[k] for s in gsamples])
            for k in ("rho_grad", "rho_curl", "rho_harm", "beta1")
        },
        "n_graph_null_samples": len(gsamples),
        "matrix_null_seconds": time.time() - t0,
    }
    res["null_degree_rewire_same_graph"]["beta1"] = zsum(
        float(real["betti"]["beta1"]), [s["beta1"] for s in gsamples])
    with open(f"{out_dir}/B-hodge-yubios.json", "w") as fh:
        json.dump(res, fh, indent=2)
    return res


def stage_c(corpora, out_dir, ph1_reps=20, ph3_nsamp=60):
    print("[c] P-H1 / P-H2 / P-H3", file=sys.stderr)
    M = corpora["yubios_2286"]["M"]
    rng = np.random.default_rng(SEED)
    out = {"stage": "c", "seed": SEED}

    # ---- P-H1: rho_h vs N at fixed k -------------------------------------
    grid = [40, 80, 160, 320, 640, 1280, 2286]
    ph1 = []
    for N in grid:
        reals, nulls, dens, tri = [], [], [], []
        for rep in range(ph1_reps):
            idx = rng.choice(len(M), size=min(N, len(M)), replace=False)
            Ms = M[idx]
            s = SEED + 97 * rep + N
            try:
                edges, ginfo = build_graph(Ms, "knn", k=8, seed=s)
                tris, _ = enumerate_triangles(edges, Ms.shape[0], seed=s)
                r, _a = hodge_decompose(Ms, edges, tris, compute_betti=False)
                reals.append(r["rho_harm"])
                dens.append(ginfo["edge_density"])
                tri.append(r["n_triangles"] / max(r["n_edges"], 1))
                e2, _sw = degree_rewire(edges, n_swaps_per_edge=3,
                                        rng=np.random.default_rng(s + 5))
                t2, _ = enumerate_triangles(e2, Ms.shape[0], seed=s)
                r2, _b = hodge_decompose(Ms, e2, t2, compute_betti=False)
                nulls.append(r2["rho_harm"])
            except RuntimeError as e:
                print(f"    P-H1 N={N} rep={rep} FAILED: {e}", file=sys.stderr)
        def st(v):
            v = np.asarray(v, float)
            return {"mean": float(v.mean()), "sd": float(v.std(ddof=1)),
                    "sem": float(v.std(ddof=1) / np.sqrt(len(v))), "n": len(v)}
        row = {"N": N, "reps": len(reals), "real": st(reals),
               "degree_rewire_null": st(nulls),
               "edge_density": st(dens), "triangles_per_edge": st(tri)}
        a, b = np.asarray(reals), np.asarray(nulls)
        row["real_minus_null"] = float(a.mean() - b.mean())
        row["z_vs_null"] = float((a.mean() - b.mean()) /
                                 np.sqrt(a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b)))
        ph1.append(row)
        print(f"    P-H1 N={N:5d} rho_h={row['real']['mean']:.6f} "
              f"+-{row['real']['sem']:.6f} null={row['degree_rewire_null']['mean']:.6f}",
              file=sys.stderr)
    out["P_H1"] = {"grid": grid, "k": 8, "reps_per_N": ph1_reps, "rows": ph1}

    # ---- P-H2: rho_c vs 1 - V2 across corpora -----------------------------
    ph2 = []
    for name, cv in corpora.items():
        Mi = cv["M"]
        if Mi.shape[0] < 30 or Mi.std(0).sum() == 0:
            ph2.append({"corpus": name, "N": int(Mi.shape[0]),
                        "skipped": "N<30 or zero-variance columns"})
            continue
        try:
            r, _a, _e, _t = run_full(Mi, "knn", k=8, seed=SEED, compute_betti=True)
        except RuntimeError as e:
            ph2.append({"corpus": name, "N": int(Mi.shape[0]), "failed": str(e)})
            continue
        v2 = stat_V2(Mi)
        ph2.append({"corpus": name, "N": int(Mi.shape[0]), "V2": v2,
                    "one_minus_V2": 1 - v2, "rho_curl": r["rho_curl"],
                    "rho_harm": r["rho_harm"], "rho_grad": r["rho_grad"],
                    "beta1": r["betti"]["beta1"], "n_edges": r["n_edges"],
                    "n_triangles": r["n_triangles"]})
    ok = [p for p in ph2 if "rho_curl" in p]
    sc, pc = spearman([p["one_minus_V2"] for p in ok], [p["rho_curl"] for p in ok])
    sh, ph = spearman([p["one_minus_V2"] for p in ok], [p["rho_harm"] for p in ok])
    out["P_H2"] = {"rows": ph2, "n_corpora": len(ok),
                   "spearman_1mV2_vs_rho_curl": {"rho_s": sc, "p": pc},
                   "spearman_1mV2_vs_rho_harm": {"rho_s": sh, "p": ph}}
    print(f"    P-H2 spearman(1-V2, rho_c) = {sc:.4f} (p={pc:.4g}), n={len(ok)}",
          file=sys.stderr)

    # ---- P-H3: defect-row harmonic lift ------------------------------------
    ph3 = {}
    for label, Mi in (("yubios_2286", M),
                      ("yubios_1391_cycle18",
                       corpora.get("yubios_1391_cycle18", {}).get("M"))):
        if Mi is None:
            ph3[label] = {"failed": "corpus not loaded"}
            continue
        ci = Mi.sum(1)
        defects = np.flatnonzero(ci == 0)
        edges, ginfo = build_graph(Mi, "knn", k=8, seed=SEED)
        tris, _ = enumerate_triangles(edges, Mi.shape[0], seed=SEED)
        r, arr = hodge_decompose(Mi, edges, tris, compute_betti=False)
        lift = harmonic_lift(edges, arr["harm"], arr["w"], defects)
        # curveball null preserves row sums, so the defect rows STAY defects:
        # the correct null for this statistic.
        rngl = np.random.default_rng(SEED + 11)
        nl = []
        for b in range(ph3_nsamp):
            Mb = curveball(Mi, rng=rngl)
            eb, _g = build_graph(Mb, "knn", k=8, seed=SEED + 3 * b)
            tb, _ = enumerate_triangles(eb, Mb.shape[0], seed=SEED + 3 * b)
            try:
                rb, ab = hodge_decompose(Mb, eb, tb, compute_betti=False)
            except RuntimeError:
                continue
            lb = harmonic_lift(eb, ab["harm"], ab["w"], np.flatnonzero(Mb.sum(1) == 0))
            if lb["lift"] is not None:
                nl.append(lb["lift"])
        ph3[label] = {"n_defect_rows": int(len(defects)),
                      "real_lift": lift,
                      "curveball_null_lift": zsum(lift["lift"], nl),
                      "graph": ginfo}
        print(f"    P-H3 {label}: lift={lift['lift']} "
              f"null={ph3[label]['curveball_null_lift']['null_mean']}", file=sys.stderr)
    out["P_H3"] = ph3

    with open(f"{out_dir}/C-predictions.json", "w") as fh:
        json.dump(out, fh, indent=2)
    return out


def stage_d(corpora, out_dir):
    print("[d] construction sensitivity", file=sys.stderr)
    M = corpora["yubios_2286"]["M"]
    specs = [
        ("knn_k8", dict(graph="knn", k=8), 50),
        ("knn_k16", dict(graph="knn", k=16), 25),
        ("thresh_tau0.35_cap20000", dict(graph="thresh", tau=0.35, edge_cap=20000), 25),
        ("band_b1_cap20000", dict(graph="band", band=1, edge_cap=20000), 10),
    ]
    out = {"stage": "d", "seed": SEED, "constructions": {}}
    for name, kw, ns in specs:
        t0 = time.time()
        real, gsamples, arrays, edges = hodge_with_graph_null(
            M, nsamp=ns, seed=SEED, betti=True, **kw)
        entry = {
            "params": kw, "graph": real["graph"],
            "rho_grad": real["rho_grad"], "rho_curl": real["rho_curl"],
            "rho_harm": real["rho_harm"], "betti": real["betti"],
            "orthogonality": real["orthogonality"],
            "degree_rewire_null": {
                "rho_grad": zsum(real["rho_grad"], [s["rho_grad"] for s in gsamples]),
                "rho_curl": zsum(real["rho_curl"], [s["rho_curl"] for s in gsamples]),
                "rho_harm": zsum(real["rho_harm"], [s["rho_harm"] for s in gsamples]),
                "beta1": zsum(float(real["betti"]["beta1"]),
                              [s["beta1"] for s in gsamples]),
            },
            "n_null_samples": len(gsamples),
            "p_h3_zero_coverage_lift": harmonic_lift(
                edges, arrays["harm"], arrays["w"], np.flatnonzero(M.sum(1) == 0)),
            "seconds": time.time() - t0,
        }
        out["constructions"][name] = entry
        print(f"    {name}: rho_g={entry['rho_grad']:.6f} rho_c={entry['rho_curl']:.6f} "
              f"rho_h={entry['rho_harm']:.6f} b1={entry['betti']['beta1']} "
              f"z_h={entry['degree_rewire_null']['rho_harm']['z']}", file=sys.stderr)
    with open(f"{out_dir}/D-construction-sensitivity.json", "w") as fh:
        json.dump(out, fh, indent=2)
    return out


def main(argv=None):
    global MASTER, CYCLE18, L142, SSG385_DIR
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--stage", default="all", choices=["a", "b", "c", "d", "all"])
    ap.add_argument("--out-dir", default=os.path.join(BUNDLE, "results"),
                    help="where result JSON is written (default: <bundle>/results)")
    ap.add_argument("--master", default=MASTER,
                    help="2286x9 master coverage matrix (default: <bundle>/data/real/...)")
    ap.add_argument("--cycle18", default=CYCLE18,
                    help="EXTERNAL, not shipped: 1391x9 cycle-18 coverage JSON")
    ap.add_argument("--l142", default=L142,
                    help="EXTERNAL, not shipped: l142_compute.py for the CIS corpus")
    ap.add_argument("--ssg-dir", default=SSG385_DIR,
                    help="EXTERNAL, not shipped: SCAP SSG rules directory (*.yml)")
    ap.add_argument("--nsamp", type=int, default=200)
    a = ap.parse_args(argv)
    MASTER, CYCLE18, L142, SSG385_DIR = a.master, a.cycle18, a.l142, a.ssg_dir
    os.makedirs(a.out_dir, exist_ok=True)

    t0 = time.time()
    corpora, failures = load_all_corpora()
    manifest = {"seed": SEED, "python": sys.version, "numpy": np.__version__,
                "corpora": {k: {"N": v["N"], "source": v["source"],
                                "colsums": v["colsums"],
                                "n_zero_rows": v["n_zero_rows"]}
                            for k, v in corpora.items()},
                "load_failures": failures}
    with open(f"{a.out_dir}/manifest.json", "w") as fh:
        json.dump(manifest, fh, indent=2)

    if a.stage in ("a", "all"):
        stage_a(corpora, a.out_dir, nsamp=a.nsamp)
    if a.stage in ("b", "all"):
        stage_b(corpora, a.out_dir)
    if a.stage in ("c", "all"):
        stage_c(corpora, a.out_dir)
    if a.stage in ("d", "all"):
        stage_d(corpora, a.out_dir)
    print(f"done in {time.time()-t0:.1f}s -> {a.out_dir}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
