#!/usr/bin/env python3.12
"""
fold_ladder_experiment.py — fold-aggregated detection (paper section 5,
"Fold-aggregated detection", Empirical Result 2).

Empirical Result 1 clause (iii) records that at N = 128 the per-cell mean
dV2z is NOT ordered in the planted amplitude s: each cell sits at the power
floor and Monte-Carlo error swamps the trend.  This script tests whether the
trend is recoverable at the FAMILY level by aggregating a constant-ratio
amplitude ladder ("algebraic fold") instead of reading each cell alone.

Design
------
ladder            s = 0.25, 0.5, 1.0, 2.0     (constant ratio 2, i.e. equally
                  spaced in log2 s: -2, -1, 0, +1)
corpus            N = 128, d = 9, m = 2 modes, base rate 0.5, planted S^2 curve
                  from the instrument (skills/curved-corpus-create)
per-cell statistic  dV2z against that corpus's own fixed-margin curveball
                  ensemble, `--reps` replicates (default 30)
trials            `-T` independent trials (default 30)

  paired    one generator seed per TRIAL, reused at every rung of the ladder,
            so the four corpora of a trial share their Bernoulli draw stream
            and differ only in amplitude.  This is the variance reduction:
            the common seed cancels in the within-trial trend.
  unpaired  a fresh generator seed at every (trial, rung).

fold-slope statistic
            within each trial, regress the four z values on log2 s and keep the
            OLS slope; across trials report t = mean(slope) / SEM(slope).

null ladder
            the identical procedure with s = 0 at all four rungs.  Its 95%
            quantile of the slope is the empirical critical value: fold-slope
            FPR is controlled by THAT quantile, not by Gaussian theory (the
            per-cell z is itself over-dispersed, sd 1.32 at s = 0).

Seeds.  Master seed 20260812.  paired generator seed = MASTER + trial;
unpaired = MASTER + 10000 + trial*L + rung; null-ladder generator =
MASTER + 20000 + trial; curveball RNG = MASTER + 500000 + trial*L + rung
(and + 700000 for the null ladder).  Every seed is explicit; no global RNG.

All paths are resolved relative to THIS FILE, so the script runs from anywhere.
Runtime ~2-4 min single core at the defaults.

    python3.12 scripts/fold_ladder_experiment.py
    python3.12 scripts/fold_ladder_experiment.py -T 30 --reps 30 \
        --out results/fold-ladder-experiment.json
    python3.12 scripts/fold_ladder_experiment.py -T 5 --reps 10   # smoke run
"""

import argparse
import importlib.util
import json
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

MASTER_SEED = 20260812
LADDER = (0.25, 0.5, 1.0, 2.0)
DETECT_Z = 1.645


def load_skill():
    """Import the instrument (skills/curved-corpus-create) by relative path."""
    path = os.path.join(ROOT, "skills", "curved-corpus-create",
                        "scripts", "create_corpus.py")
    spec = importlib.util.spec_from_file_location("create_corpus", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def cell_z(cc, n, d, s, gen_seed, null_seed, reps, modes, base_rate):
    """dV2z of one planted corpus against its own curveball ensemble."""
    c = cc.generate(kind="planted", n=n, d=d, amplitude=s, modes=modes,
                    base_rate=base_rate, seed=gen_seed)
    x = c["matrix"] if isinstance(c, dict) else c
    m = cc.measure(np.asarray(x), reps=reps, seed=null_seed, nulls=("curveball",))
    return float(m["dV2z"])


def slope(zs, logs):
    """OLS slope of z on log2 s."""
    lg = np.asarray(logs, dtype=float)
    zz = np.asarray(zs, dtype=float)
    return float(((lg - lg.mean()) * (zz - zz.mean())).sum() /
                 ((lg - lg.mean()) ** 2).sum())


def run_design(cc, args, ladder, logs, gen_seed_fn, null_base, label):
    L = len(ladder)
    Z = np.zeros((args.T, L))
    for t in range(args.T):
        for j, s in enumerate(ladder):
            Z[t, j] = cell_z(cc, args.N, args.d, s, gen_seed_fn(t, j),
                             null_base + t * L + j, args.reps,
                             args.modes, args.base_rate)
        if args.verbose:
            print("    %-8s trial %2d/%d  z = %s" %
                  (label, t + 1, args.T, np.round(Z[t], 2).tolist()))
    slopes = np.array([slope(Z[t], logs) for t in range(args.T)])
    mono = float(np.mean([bool(np.all(np.diff(Z[t]) > 0)) for t in range(args.T)]))
    return Z, slopes, mono


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-T", "--trials", dest="T", type=int, default=30)
    ap.add_argument("-N", "--n", dest="N", type=int, default=128)
    ap.add_argument("-d", "--d", dest="d", type=int, default=9)
    ap.add_argument("--reps", type=int, default=30,
                    help="curveball replicates per cell (default 30)")
    ap.add_argument("--modes", type=int, default=2)
    ap.add_argument("--base-rate", type=float, default=0.5)
    ap.add_argument("--ladder", default=",".join(str(s) for s in LADDER),
                    help="constant-ratio amplitude ladder (default 0.25,0.5,1.0,2.0)")
    ap.add_argument("--seed", type=int, default=MASTER_SEED)
    ap.add_argument("--out", default=None, help="optional JSON output path")
    ap.add_argument("--verbose", action="store_true")
    a = ap.parse_args(argv)

    ladder = tuple(float(x) for x in a.ladder.split(","))
    logs = np.log2(np.asarray(ladder))
    L = len(ladder)
    cc = load_skill()
    t0 = time.time()

    print("fold ladder: s = %s   (log2 s = %s)" % (list(ladder), logs.tolist()))
    print("N = %d  d = %d  modes = %d  trials = %d  curveball reps = %d  seed = %d\n"
          % (a.N, a.d, a.modes, a.T, a.reps, a.seed))

    Zp, sp, mp = run_design(cc, a, ladder, logs,
                            lambda t, j: a.seed + t, a.seed + 500000, "paired")
    Zu, su, mu = run_design(cc, a, ladder, logs,
                            lambda t, j: a.seed + 10000 + t * L + j,
                            a.seed + 600000, "unpaired")

    # null ladder: s = 0 at every rung, paired-style
    Zn = np.zeros((a.T, L))
    for t in range(a.T):
        for j in range(L):
            Zn[t, j] = cell_z(cc, a.N, a.d, 0.0, a.seed + 20000 + t,
                              a.seed + 700000 + t * L + j, a.reps,
                              a.modes, a.base_rate)
    sn = np.array([slope(Zn[t], logs) for t in range(a.T)])
    q95 = float(np.quantile(sn, 0.95))

    def tstat(v):
        return float(v.mean() / (v.std(ddof=1) / np.sqrt(len(v))))

    out = {
        "ladder": list(ladder), "N": a.N, "d": a.d, "reps": a.reps, "T": a.T,
        "paired_meanz": [float(x) for x in Zp.mean(axis=0)],
        "unpaired_meanz": [float(x) for x in Zu.mean(axis=0)],
        "paired_power": [float((Zp[:, j] > DETECT_Z).mean()) for j in range(L)],
        "unpaired_power": [float((Zu[:, j] > DETECT_Z).mean()) for j in range(L)],
        "paired_mono": mp, "unpaired_mono": mu,
        "paired_slope_mean": float(sp.mean()), "unpaired_slope_mean": float(su.mean()),
        "paired_slope_t": tstat(sp), "unpaired_slope_t": tstat(su),
        "null_slope_mean": float(sn.mean()), "null_slope_q95": q95,
        "paired_slope_power": float((sp > q95).mean()),
        "unpaired_slope_power": float((su > q95).mean()),
        "variance_reduction_paired_vs_unpaired": float(su.var(ddof=1) / sp.var(ddof=1)),
        "seed": a.seed,
    }

    print("\nper-cell mean z   paired   %s" % np.round(out["paired_meanz"], 3).tolist())
    print("per-cell mean z   unpaired %s" % np.round(out["unpaired_meanz"], 3).tolist())
    print("per-cell power    paired   %s" % out["paired_power"])
    print("per-cell power    unpaired %s" % out["unpaired_power"])
    print("monotone-trial fraction    paired %.3f   unpaired %.3f" % (mp, mu))
    print("fold-slope t               paired %.2f   unpaired %.2f"
          % (out["paired_slope_t"], out["unpaired_slope_t"]))
    print("slope variance reduction (unpaired/paired): %.2fx"
          % out["variance_reduction_paired_vs_unpaired"])
    print("null ladder (s = 0): slope mean %+.4f   95%% quantile %.4f"
          % (out["null_slope_mean"], q95))
    print("fold-slope power vs null quantile: paired %.2f   unpaired %.2f"
          % (out["paired_slope_power"], out["unpaired_slope_power"]))
    print("\nelapsed %.1f s" % (time.time() - t0))

    if a.out:
        with open(a.out, "w") as fh:
            json.dump(out, fh, indent=1)
        print("written: %s" % a.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
