"""
common.py — shared primitives for the wave-2 dimension-ladder study.

Everything here is deterministic given an explicit numpy Generator seed.
No global RNG use anywhere.

Definitions (fixed once, used everywhere):

  V2(X)  = (lam1 + lam2) / sum(lam)  of the CORRELATION matrix of X,
           computed after dropping zero-variance columns.
           This is the program's headline observable ("PC1+PC2").
  r_eff  = 2 / V2   (exact effective rank for a flat top-r spectrum)

Nulls:
  curveball : binary, preserves BOTH row and column sums (max-entropy given marginals)
  colperm   : independent per-column permutation (destroys row structure, keeps col marginals)
  iid       : Bernoulli with matched column marginals
  For continuous matrices only `colperm` / `iid-gaussian-marginal-matched` are meaningful.

Sphere pipeline (paper protocol, reproduced):
  z-score columns -> PCA top-2 scores -> scale by RMS radius -> inverse stereographic
  lift from the SOUTH pole onto the unit S^2 -> real spherical harmonics L=3 (16 fns)
  -> closed-form ridge (lambda = 1e-3) -> predictions renormalised to S^2
  -> chordal residual ||p - q||_2 in [0, 2].

  IMPORTANT (documented degeneracy): the L=1 block of the real SH basis is exactly
  linear in (x, y, z), so the paper's in-sample self-fit can reproduce every point
  by construction. We therefore ALSO provide a non-degenerate variant:
  `sphere_fit_cv` uses only the L=2 and L=3 blocks (12 functions) with 5-fold
  cross-validation, so the identity map is not in the span.

Y_3^3 constant: complex |K| = sqrt(35/(64 pi)) ~= 0.417223,
                real-orthonormal    sqrt(70/(64 pi)) ~= 0.590044.
The published sqrt(245/(64 pi)) ~= 1.103899 is wrong by a factor sqrt(7);
`sh_constants()` returns all three so the correction is machine-checkable.
"""

import json
import math
import os
import time

import numpy as np

PHI_GOLDEN = (1.0 + math.sqrt(5.0)) / 2.0
RIDGE_LAMBDA = 1e-3


# --------------------------------------------------------------------------
# V2 / spectrum
# --------------------------------------------------------------------------
def corr_spectrum(X):
    """Eigenvalues (descending) of the correlation matrix of X, zero-variance
    columns dropped. Returns (eigvals, n_kept, n_dropped)."""
    X = np.asarray(X, dtype=float)
    sd = X.std(axis=0)
    keep = sd > 1e-12
    n_dropped = int((~keep).sum())
    Xk = X[:, keep]
    if Xk.shape[1] == 0:
        return np.array([]), 0, n_dropped
    if Xk.shape[1] == 1:
        return np.array([1.0]), 1, n_dropped
    C = np.corrcoef(Xk, rowvar=False)
    C = np.nan_to_num(C, nan=0.0)
    C = 0.5 * (C + C.T)
    ev = np.linalg.eigvalsh(C)[::-1]
    return ev, int(keep.sum()), n_dropped


def v2(X):
    """Top-2 eigenvalue share of the correlation matrix."""
    ev, k, _ = corr_spectrum(X)
    if k == 0:
        return float("nan")
    if k == 1:
        return 1.0
    tot = ev.sum()
    if tot <= 0:
        return float("nan")
    return float((ev[0] + ev[1]) / tot)


def v2_full(X):
    ev, k, drop = corr_spectrum(X)
    if k == 0:
        return dict(V2=float("nan"), r_eff=float("nan"), eigs=[], d_eff=0, d_dropped=drop)
    val = 1.0 if k == 1 else float((ev[0] + ev[1]) / ev.sum())
    return dict(
        V2=val,
        r_eff=(2.0 / val if val > 0 else float("inf")),
        eigs=[float(e) for e in ev[: min(len(ev), 12)]],
        d_eff=k,
        d_dropped=drop,
    )


# --------------------------------------------------------------------------
# Nulls
# --------------------------------------------------------------------------
def curveball(X, rng, n_trades=None):
    """Curveball trade algorithm (Strona et al. 2014): uniform sample from the
    ensemble of binary matrices with the SAME row and column sums."""
    B = np.asarray(X, dtype=bool).copy()
    N = B.shape[0]
    if N < 2:
        return B.astype(float)
    if n_trades is None:
        n_trades = 5 * N
    idx = np.arange(B.shape[1])
    for _ in range(n_trades):
        i, j = rng.integers(0, N, size=2)
        if i == j:
            continue
        a, b = B[i], B[j]
        only_a = idx[a & ~b]
        only_b = idx[b & ~a]
        na, nb = len(only_a), len(only_b)
        if na == 0 or nb == 0:
            continue
        pool = np.concatenate([only_a, only_b])
        rng.shuffle(pool)
        newa, newb = pool[:na], pool[na:]
        a[only_a] = False
        a[only_b] = False
        b[only_a] = False
        b[only_b] = False
        a[newa] = True
        b[newb] = True
    return B.astype(float)


def colperm(X, rng):
    """Independent per-column permutation: keeps column marginals, destroys rows."""
    Y = np.asarray(X, dtype=float).copy()
    for c in range(Y.shape[1]):
        Y[:, c] = rng.permutation(Y[:, c])
    return Y


def iid_bernoulli(X, rng):
    p = np.asarray(X, dtype=float).mean(axis=0)
    return (rng.random(X.shape) < p[None, :]).astype(float)


def null_v2(X, kind, reps, seed, n_trades=None):
    """Null distribution of V2. Returns dict(mean, std, reps, values...)."""
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(reps):
        if kind == "curveball":
            Y = curveball(X, rng, n_trades=n_trades)
        elif kind == "colperm":
            Y = colperm(X, rng)
        elif kind == "iid":
            Y = iid_bernoulli(X, rng)
        else:
            raise ValueError(kind)
        vals.append(v2(Y))
    vals = np.asarray(vals, dtype=float)
    good = vals[np.isfinite(vals)]
    return dict(
        kind=kind,
        reps=int(reps),
        mean=float(good.mean()) if good.size else float("nan"),
        std=float(good.std(ddof=1)) if good.size > 1 else float("nan"),
        seed=int(seed),
        values=[float(v) for v in vals],
    )


def zscore_vs_null(value, null):
    if not np.isfinite(null["std"]) or null["std"] <= 0:
        return float("nan")
    return float((value - null["mean"]) / null["std"])


# --------------------------------------------------------------------------
# Spherical harmonics (real, L = 0..3, 16 functions)
# --------------------------------------------------------------------------
def sh_constants():
    """The Y_3^3 normalisation constants, for the record."""
    return dict(
        complex_correct=math.sqrt(35.0 / (64.0 * math.pi)),
        real_orthonormal_correct=math.sqrt(70.0 / (64.0 * math.pi)),
        published_wrong=math.sqrt(245.0 / (64.0 * math.pi)),
        ratio_wrong_over_complex=math.sqrt(245.0 / 35.0),
    )


def real_sh_L3(theta, phi):
    """16 real orthonormal spherical harmonics, L = 0,1,2,3.
    Column order: (0,0),(1,-1),(1,0),(1,1),(2,-2)...(2,2),(3,-3)...(3,3)."""
    theta = np.asarray(theta, dtype=float)
    phi = np.asarray(phi, dtype=float)
    st, ct = np.sin(theta), np.cos(theta)
    P = math.pi
    cols = []
    cols.append(np.full_like(theta, 0.5 * math.sqrt(1.0 / P)))                       # 0,0
    c = math.sqrt(3.0 / (4.0 * P))
    cols += [c * st * np.sin(phi), c * ct, c * st * np.cos(phi)]                      # 1,-1..1
    c2a = 0.5 * math.sqrt(15.0 / P)
    c2b = 0.25 * math.sqrt(5.0 / P)
    c2c = 0.25 * math.sqrt(15.0 / P)
    cols += [
        c2a * st * st * np.sin(phi) * np.cos(phi),                                    # 2,-2
        c2a * st * ct * np.sin(phi),                                                  # 2,-1
        c2b * (3.0 * ct * ct - 1.0),                                                  # 2, 0
        c2a * st * ct * np.cos(phi),                                                  # 2, 1
        c2c * st * st * np.cos(2.0 * phi),                                            # 2, 2
    ]
    k33 = math.sqrt(70.0 / (64.0 * P))          # CORRECTED real Y_3^3 constant
    k32 = math.sqrt(105.0 / (16.0 * P))
    k31 = math.sqrt(21.0 / (32.0 * P))
    k30 = math.sqrt(7.0 / (16.0 * P))
    cols += [
        k33 * st**3 * np.sin(3.0 * phi),                                              # 3,-3
        k32 * st * st * ct * np.sin(2.0 * phi),                                       # 3,-2
        k31 * st * (5.0 * ct * ct - 1.0) * np.sin(phi),                               # 3,-1
        k30 * (5.0 * ct**3 - 3.0 * ct),                                               # 3, 0
        k31 * st * (5.0 * ct * ct - 1.0) * np.cos(phi),                               # 3, 1
        k32 * st * st * ct * np.cos(2.0 * phi),                                       # 3, 2
        k33 * st**3 * np.cos(3.0 * phi),                                              # 3, 3
    ]
    return np.stack(cols, axis=1)


SH_BLOCK_L = np.array([0] + [1] * 3 + [2] * 5 + [3] * 7)


# --------------------------------------------------------------------------
# Embedding: binary matrix -> S^2 points (paper stack)
# --------------------------------------------------------------------------
def pca_scores(X, k=2):
    X = np.asarray(X, dtype=float)
    sd = X.std(axis=0)
    keep = sd > 1e-12
    Z = (X[:, keep] - X[:, keep].mean(axis=0)) / sd[keep]
    U, S, Vt = np.linalg.svd(Z, full_matrices=False)
    k = min(k, U.shape[1])
    return U[:, :k] * S[:k]


def stereographic_lift(scores2):
    """Inverse stereographic projection from the SOUTH pole onto the unit sphere.
    Planar scores are first rescaled so the RMS radius is 1 (scale-fixing choice,
    documented; PCA scores have no intrinsic units)."""
    u = np.asarray(scores2, dtype=float)
    if u.shape[1] == 1:
        u = np.column_stack([u, np.zeros(len(u))])
    rms = math.sqrt(float((u ** 2).sum(axis=1).mean())) or 1.0
    u = u / rms
    r2 = (u ** 2).sum(axis=1)
    denom = 1.0 + r2
    P = np.column_stack([2.0 * u[:, 0] / denom, 2.0 * u[:, 1] / denom, (r2 - 1.0) / denom])
    P /= np.linalg.norm(P, axis=1, keepdims=True)
    return P


def sphere_angles(P):
    theta = np.arccos(np.clip(P[:, 2], -1.0, 1.0))
    phi = np.arctan2(P[:, 1], P[:, 0])
    return theta, phi


def fibonacci_sphere(N):
    """z_i = 1 - (2i+1)/N, phi_i = 2*pi*i/phi_golden (paper operationalisation)."""
    i = np.arange(N)
    z = 1.0 - (2.0 * i + 1.0) / N
    phi = 2.0 * math.pi * i / PHI_GOLDEN
    theta = np.arccos(np.clip(z, -1.0, 1.0))
    return theta, np.mod(phi, 2.0 * math.pi)


def ridge_fit(B, Y, lam=RIDGE_LAMBDA):
    G = B.T @ B + lam * np.eye(B.shape[1])
    return np.linalg.solve(G, B.T @ Y)


def _normalize_rows(Q):
    n = np.linalg.norm(Q, axis=1, keepdims=True)
    n[n < 1e-12] = 1.0
    return Q / n


def sphere_fit_paper(P):
    """In-sample self-fit exactly as specified in the papers: 16 real SH at each
    item's own S^2 point, ridge lambda=1e-3, chordal residual in [0,2]."""
    theta, phi = sphere_angles(P)
    B = real_sh_L3(theta, phi)
    W = ridge_fit(B, P)
    Q = _normalize_rows(B @ W)
    res = np.linalg.norm(P - Q, axis=1)
    ss_res = float((np.linalg.norm(P - Q, axis=1) ** 2).sum())
    ss_tot = float((np.linalg.norm(P - P.mean(axis=0), axis=1) ** 2).sum())
    return dict(
        median_chordal_residual=float(np.median(res)),
        max_chordal_residual=float(res.max()),
        R2=float(1.0 - ss_res / ss_tot) if ss_tot > 0 else float("nan"),
    )


def sphere_fit_cv(P, folds=5, seed=0, use_blocks=(2, 3)):
    """Non-degenerate variant: L=2,3 only (12 functions, identity NOT in span),
    5-fold cross-validated, same ridge and chordal residual convention."""
    theta, phi = sphere_angles(P)
    B = real_sh_L3(theta, phi)
    mask = np.isin(SH_BLOCK_L, np.asarray(use_blocks))
    B = B[:, mask]
    N = len(P)
    rng = np.random.default_rng(seed)
    order = rng.permutation(N)
    fold_id = np.zeros(N, dtype=int)
    fold_id[order] = np.arange(N) % folds
    Q = np.zeros_like(P)
    for f in range(folds):
        tr, te = fold_id != f, fold_id == f
        if tr.sum() < B.shape[1] + 2 or te.sum() == 0:
            Q[te] = P[tr].mean(axis=0) if tr.sum() else 0.0
            continue
        W = ridge_fit(B[tr], P[tr])
        Q[te] = B[te] @ W
    Q = _normalize_rows(Q)
    res = np.linalg.norm(P - Q, axis=1)
    ss_res = float((res ** 2).sum())
    ss_tot = float((np.linalg.norm(P - P.mean(axis=0), axis=1) ** 2).sum())
    return dict(
        R2_cv=float(1.0 - ss_res / ss_tot) if ss_tot > 0 else float("nan"),
        median_chordal_residual_cv=float(np.median(res)),
    )


def embedding_recovery(P_hat, P_true):
    """Mean squared canonical correlation between recovered and true S^2 points.
    1.0 = the 3-D recovered configuration spans the same directions as truth."""
    A = P_hat - P_hat.mean(axis=0)
    Bm = P_true - P_true.mean(axis=0)
    qa, _ = np.linalg.qr(A)
    qb, _ = np.linalg.qr(Bm)
    s = np.linalg.svd(qa.T @ qb, compute_uv=False)
    s = np.clip(s, 0, 1)
    return float((s ** 2).mean())


# --------------------------------------------------------------------------
# io
# --------------------------------------------------------------------------
def load_real_matrix(path):
    with open(path) as fh:
        d = json.load(fh)
    X = np.array([r["covered"] for r in d["rows"]], dtype=float)
    return X, d["primitives"], d


def ensure_dir(p):
    os.makedirs(p, exist_ok=True)
    return p


def now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def dump_json(path, obj):
    ensure_dir(os.path.dirname(path))
    with open(path, "w") as fh:
        json.dump(obj, fh, indent=2)
    return path


# --------------------------------------------------------------------------
# fast curveball (bitmask implementation, identical ensemble, ~10x faster)
# --------------------------------------------------------------------------
import random as _random


def curveball_fast(X, seed, n_trades=None):
    """Curveball trades on integer bitmasks. Preserves row AND column sums.
    Equivalent ensemble to `curveball`, used for the large null sweeps."""
    Xb = np.asarray(X, dtype=np.uint8)
    N, d = Xb.shape
    pow2 = (1 << np.arange(d, dtype=object))
    rows = [int(sum(int(b) * int(p) for b, p in zip(r, pow2))) for r in Xb]
    if n_trades is None:
        n_trades = 4 * N
    rnd = _random.Random(int(seed))
    ri = rnd.randrange
    for _ in range(n_trades):
        i = ri(N)
        j = ri(N)
        if i == j:
            continue
        a = rows[i]
        b = rows[j]
        oa = a & ~b
        ob = b & ~a
        if oa == 0 or ob == 0:
            continue
        common = a & b
        pool = []
        m = oa | ob
        while m:
            low = m & -m
            pool.append(low)
            m ^= low
        na = bin(oa).count("1")
        rnd.shuffle(pool)
        newa = 0
        for k in range(na):
            newa |= pool[k]
        newb = 0
        for k in range(na, len(pool)):
            newb |= pool[k]
        rows[i] = common | newa
        rows[j] = common | newb
    out = np.zeros((N, d), dtype=np.uint8)
    for r, v in enumerate(rows):
        k = 0
        while v:
            if v & 1:
                out[r, k] = 1
            v >>= 1
            k += 1
    return out.astype(float)


def swap_chain_null(X, seed, n_swaps_mult=200):
    """INDEPENDENT implementation of the same fixed-margins ensemble:
    classic checkerboard 2x2 swap chain (Connor & Simberloff). Used only to
    cross-validate `curveball_fast`; slower, different proposal mechanism."""
    B = np.asarray(X, dtype=np.uint8).copy()
    N, d = B.shape
    rnd = _random.Random(int(seed))
    n = n_swaps_mult * N
    for _ in range(n):
        i, j = rnd.randrange(N), rnd.randrange(N)
        k, l = rnd.randrange(d), rnd.randrange(d)
        if i == j or k == l:
            continue
        if B[i, k] == 1 and B[j, l] == 1 and B[i, l] == 0 and B[j, k] == 0:
            B[i, k] = B[j, l] = 0
            B[i, l] = B[j, k] = 1
        elif B[i, l] == 1 and B[j, k] == 1 and B[i, k] == 0 and B[j, l] == 0:
            B[i, l] = B[j, k] = 0
            B[i, k] = B[j, l] = 1
    return B.astype(float)
