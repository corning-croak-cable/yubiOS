#!/usr/bin/env python3.12
"""
null_models.py — null ensembles for binary coverage matrices, plus a generic
"null distribution of ANY statistic" driver with z-scores.

Nulls implemented
-----------------
curveball   : Strona et al. (2014) curveball / trade algorithm. Preserves BOTH
              row sums and column sums exactly. This is the maximum-entropy
              matched-marginal ensemble used in D-big-picture.md.
colperm     : independent permutation of each column. Preserves column sums
              exactly, destroys row-sum structure (row sums become
              Poisson-binomial).
bernoulli   : iid Bernoulli with column-matched probabilities p_a = colsum_a/N.
              Preserves column sums only in expectation.
rowperm     : permutation of whole rows (a control that preserves everything;
              V2 is invariant under it, so it is a pipeline sanity check).
degree_rewire (graph null): double-edge swap on an existing edge list,
              preserving every node degree exactly. This is the Kahle-warning
              null for Hodge quantities: same degree sequence, same |E|, same
              M -- only the wiring is randomised.

Marchenko-Pastur baseline
-------------------------
mp_baseline(N, d) returns the MP edges lambda_+- = (1 +- sqrt(q))^2 with
q = d/N, and the MP-predicted top-2 eigenvalue share obtained by integrating
the MP density (i.e. what V2 would be for a pure-noise matrix of this shape).

CLI
---
    python3.12 null_models.py --input per_row_coverage_v3.json \
        --stat V2 --null curveball --nsamp 200 --seed 20260812 \
        --out results/v2_nulls.json
"""

from __future__ import annotations

import argparse
import json
import sys

import numpy as np


# --------------------------------------------------------------------------
# statistics
# --------------------------------------------------------------------------


def stat_V2(M: np.ndarray) -> float:
    """Top-2 eigenvalue share of the d x d CORRELATION matrix (the published V2)."""
    X = M.astype(np.float64)
    sd = X.std(0)
    if np.any(sd == 0):
        # degenerate column: fall back to covariance-based share, reported as-is
        Xc = X - X.mean(0)
        C = Xc.T @ Xc
    else:
        C = np.corrcoef(X, rowvar=False)
    ev = np.sort(np.linalg.eigvalsh(C))[::-1]
    tot = ev.sum()
    if tot <= 0:
        return 0.0
    return float((ev[0] + ev[1]) / tot)


def stat_V2_cov(M: np.ndarray) -> float:
    """Top-2 share of the covariance matrix (the variant used by some cycles)."""
    X = M.astype(np.float64)
    Xc = X - X.mean(0)
    C = Xc.T @ Xc / max(len(X) - 1, 1)
    ev = np.sort(np.linalg.eigvalsh(C))[::-1]
    tot = ev.sum()
    return float((ev[0] + ev[1]) / tot) if tot > 0 else 0.0


STATS = {"V2": stat_V2, "V2_cov": stat_V2_cov}


# --------------------------------------------------------------------------
# curveball
# --------------------------------------------------------------------------


def curveball(M: np.ndarray, n_trades: int | None = None, rng=None) -> np.ndarray:
    """
    Curveball / trade randomisation preserving row AND column sums exactly.
    Strona, Nappo, Boccacci, Fattorini, San-Miguel-Ayanz, Nat. Commun. 5:4114 (2014).
    """
    rng = rng or np.random.default_rng()
    N, d = M.shape
    sets = [set(np.flatnonzero(M[i]).tolist()) for i in range(N)]
    if n_trades is None:
        n_trades = 5 * N
    for _ in range(n_trades):
        a, b = rng.integers(0, N, size=2)
        if a == b:
            continue
        A, B = sets[a], sets[b]
        shared = A & B
        ex_a = list(A - shared)
        ex_b = list(B - shared)
        if not ex_a or not ex_b:
            continue
        pool = ex_a + ex_b
        rng.shuffle(pool)
        na = len(ex_a)
        newA = shared | set(pool[:na])
        newB = shared | set(pool[na:])
        sets[a], sets[b] = newA, newB
    out = np.zeros_like(M)
    for i, s in enumerate(sets):
        if s:
            out[i, list(s)] = 1
    return out


def col_permute(M: np.ndarray, rng=None) -> np.ndarray:
    rng = rng or np.random.default_rng()
    out = M.copy()
    for a in range(M.shape[1]):
        out[:, a] = rng.permutation(out[:, a])
    return out


def bernoulli_null(M: np.ndarray, rng=None) -> np.ndarray:
    rng = rng or np.random.default_rng()
    p = M.mean(0)
    return (rng.random(M.shape) < p[None, :]).astype(M.dtype)


def row_permute(M: np.ndarray, rng=None) -> np.ndarray:
    rng = rng or np.random.default_rng()
    return M[rng.permutation(len(M))]


MATRIX_NULLS = {
    "curveball": curveball,
    "colperm": col_permute,
    "bernoulli": bernoulli_null,
    "rowperm": row_permute,
}


# --------------------------------------------------------------------------
# graph null (degree-preserving rewiring) -- the Kahle-warning null
# --------------------------------------------------------------------------


def degree_rewire(edges: np.ndarray, n_swaps_per_edge: int = 10, rng=None,
                  max_tries_factor: int = 20) -> np.ndarray:
    """Double-edge swap preserving every node degree exactly (simple graph)."""
    rng = rng or np.random.default_rng()
    E = edges.copy()
    eset = set(map(tuple, E.tolist()))
    m = len(E)
    target = n_swaps_per_edge * m
    tries = 0
    done = 0
    while done < target and tries < max_tries_factor * target:
        tries += 1
        i1, i2 = rng.integers(0, m, size=2)
        if i1 == i2:
            continue
        a, b = E[i1]
        c, d = E[i2]
        if len({int(a), int(b), int(c), int(d)}) < 4:
            continue
        if rng.random() < 0.5:
            n1 = (min(int(a), int(c)), max(int(a), int(c)))
            n2 = (min(int(b), int(d)), max(int(b), int(d)))
        else:
            n1 = (min(int(a), int(d)), max(int(a), int(d)))
            n2 = (min(int(b), int(c)), max(int(b), int(c)))
        if n1 in eset or n2 in eset:
            continue
        eset.discard((int(a), int(b)))
        eset.discard((int(c), int(d)))
        eset.add(n1)
        eset.add(n2)
        E[i1] = n1
        E[i2] = n2
        done += 1
    return np.array(sorted(eset), dtype=np.int64), {"swaps_done": done,
                                                    "swaps_target": target,
                                                    "tries": tries}


# --------------------------------------------------------------------------
# Marchenko-Pastur baseline
# --------------------------------------------------------------------------


def mp_baseline(N: int, d: int, ngrid: int = 200000) -> dict:
    """MP edges and the MP-predicted top-2 eigenvalue share for an N x d matrix."""
    q = d / N
    lm = (1 - np.sqrt(q)) ** 2
    lp = (1 + np.sqrt(q)) ** 2
    x = np.linspace(lm, lp, ngrid)
    dens = np.sqrt(np.maximum((lp - x) * (x - lm), 0)) / (2 * np.pi * q * x)
    dens /= np.trapezoid(dens, x)
    # top-2 share for d eigenvalues drawn from MP: use the upper 2/d quantile mass
    cdf = np.concatenate([[0.0], np.cumsum((dens[1:] + dens[:-1]) / 2 * np.diff(x))])
    cdf /= cdf[-1]
    frac = 2.0 / d
    idx = np.searchsorted(cdf, 1 - frac)
    xt = x[idx]
    mass_top = np.trapezoid(dens[idx:] * x[idx:], x[idx:])
    mass_all = np.trapezoid(dens * x, x)
    return {
        "q": q,
        "lambda_minus": float(lm),
        "lambda_plus": float(lp),
        "mp_top2_share_pred": float(mass_top / mass_all),
        "cut_eigenvalue": float(xt),
    }


# --------------------------------------------------------------------------
# driver
# --------------------------------------------------------------------------


def null_distribution(M: np.ndarray, statfn, null: str = "curveball",
                      nsamp: int = 200, seed: int = 20260812,
                      n_trades: int | None = None, progress: bool = False) -> dict:
    """Null distribution of ANY statistic fn(M)->float (or ->dict of floats)."""
    rng = np.random.default_rng(seed)
    gen = MATRIX_NULLS[null]
    real = statfn(M)
    multi = isinstance(real, dict)
    samples = []
    for b in range(nsamp):
        if null == "curveball":
            Mb = gen(M, n_trades=n_trades, rng=rng)
        else:
            Mb = gen(M, rng=rng)
        samples.append(statfn(Mb))
        if progress and (b + 1) % 25 == 0:
            print(f"  {null}: {b+1}/{nsamp}", file=sys.stderr, flush=True)

    def summarize(realv, vals):
        vals = np.asarray([v for v in vals if v is not None], dtype=float)
        if len(vals) == 0 or realv is None:
            return {"real": realv, "null_mean": None, "null_sd": None, "z": None,
                    "n_samples": 0}
        mu, sd = float(vals.mean()), float(vals.std(ddof=1))
        return {
            "real": float(realv),
            "null_mean": mu,
            "null_sd": sd,
            "z": float((realv - mu) / sd) if sd > 0 else None,
            "null_min": float(vals.min()),
            "null_max": float(vals.max()),
            "null_p2.5": float(np.percentile(vals, 2.5)),
            "null_p97.5": float(np.percentile(vals, 97.5)),
            "n_samples": int(len(vals)),
            "p_two_sided_empirical": float(
                (np.sum(np.abs(vals - mu) >= abs(realv - mu)) + 1) / (len(vals) + 1)),
        }

    if multi:
        return {k: summarize(real[k], [s[k] for s in samples]) for k in real}
    return summarize(real, samples)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--stat", default="V2", choices=list(STATS))
    ap.add_argument("--null", default="curveball", choices=list(MATRIX_NULLS))
    ap.add_argument("--nsamp", type=int, default=200)
    ap.add_argument("--seed", type=int, default=20260812)
    a = ap.parse_args(argv)

    sys.path.insert(0, __file__.rsplit("/", 1)[0])
    from hodge_decompose import load_coverage_json

    M, meta, prim = load_coverage_json(a.input)
    res = null_distribution(M, STATS[a.stat], null=a.null, nsamp=a.nsamp,
                            seed=a.seed, progress=True)
    res = {"stat": a.stat, "null": a.null, "seed": a.seed, "nsamp": a.nsamp,
           "shape": list(M.shape), "result": res,
           "mp_baseline": mp_baseline(*M.shape)}
    with open(a.out, "w") as fh:
        json.dump(res, fh, indent=2)
    print(json.dumps(res, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
