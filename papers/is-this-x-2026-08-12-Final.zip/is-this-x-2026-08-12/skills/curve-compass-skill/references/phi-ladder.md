# The Phi ladder and its provenance

Source: `is-this-x-2026-08-12.md` sec. 7 (D3) and the evidence bundle
`tests/T3-results.json`, corpus `skills79`, block `potential_test`.

`Phi(k) = d_pre(k)` is the chordal ladder distance to the ideal pole at coverage
count k. It takes exactly one value per k in all three corpora (refs, skills79,
docs21) -- that exchangeability is the empirical content; the gradient property
`delta(k) = Phi(k) - Phi(k+1)` follows from the definition and is an identity
(paper Table 13), not a discovered conservation law.

| k | Phi(k) | delta(k)=Phi(k)-Phi(k+1) | C(9,k) | F_T(k) at T=0.04 | F_T(k) at T=1 |
|---:|---:|---:|---:|---:|---:|
| 0 | 2.0000 | 0.0242 | 1 | +2.0000 | +2.0000 |
| 1 | 1.9758 | 0.0678 | 9 | +1.8879 | -0.2214 |
| 2 | 1.9080 | 0.0989 | 36 | +1.7647 | -1.6755 |
| 3 | 1.8091 | 0.1158 | 84 | +1.6319 | -2.6217 |
| 4 | 1.6933 | 0.1206 | 126 | +1.4998 | -3.1430 |
| 5 | 1.5727 | 0.1175 | 126 | +1.3792 | -3.2636 |
| 6 | 1.4552 | 0.1098 | 84 | +1.2780 | -2.9756 |
| 7 | 1.3454 | 0.1003 | 36 | +1.2021 | -2.2381 |
| 8 | 1.2451 | 0.0904 | 9 | +1.1572 | -0.9521 |
| 9 | 1.1547 | -- | 1 | +1.1547 | +1.1547 |

`d_post(k) - Phi(k+1) = 0` exactly for k = 0..7 (max absolute residual 0.0).

**Terminal sentinel.** `T3-results.json` records `Phi(9) = 0.0`; that is a
bookkeeping sentinel, not a distance. The ladder continuation is
`terminal_sentinel.d_post_at_k8 = 1.1547`, and that is the value used here.
Substituting the sentinel plants a 1.245-deep artificial well at k = 9, which
swamps the entropy term T log C(9,k) at every T in the swept range and destroys
the crossover entirely.

delta(k) is maximal mid-lattice (0.1206 at k = 4, 0.1175 at k = 5), which is
both why the refs cycle-2 Delta peak was predictable in advance from the initial
k-histogram and why pi_T is broadened past the binomial at large T.

## Stationary distribution at selected temperatures

| k | pi_T (T=0.01) | pi_T (T=0.0411=T_x) | pi_T (T=0.05) | pi_T (T=1) | pi_T (T->inf) |
|---:|---:|---:|---:|---:|---:|
| 0 | 0.000000 | 0.000000 | 0.000000 | 0.001331 | 0.001953 |
| 1 | 0.000000 | 0.000000 | 0.000000 | 0.012272 | 0.017578 |
| 2 | 0.000000 | 0.000000 | 0.000003 | 0.052531 | 0.070312 |
| 3 | 0.000000 | 0.000004 | 0.000050 | 0.135315 | 0.164062 |
| 4 | 0.000000 | 0.000108 | 0.000753 | 0.227892 | 0.246094 |
| 5 | 0.000000 | 0.002022 | 0.008405 | 0.257101 | 0.246094 |
| 6 | 0.000000 | 0.023446 | 0.058756 | 0.192771 | 0.164062 |
| 7 | 0.000000 | 0.144914 | 0.226354 | 0.092204 | 0.070312 |
| 8 | 0.001066 | 0.414755 | 0.420652 | 0.025483 | 0.017578 |
| 9 | 0.998934 | 0.414750 | 0.285026 | 0.003099 | 0.001953 |

## Fitted per-k flip rate from the historical log (D5)

`p_hat(k) = 0.444, 0.463, 0.450, 0.343, 0.271, 0.367, 0.479, 0.536, 1.000` for
k = 0..8 -- U-shaped with its minimum at k = 4, exactly where the per-flip payoff
delta(k) is maximal: flips are least likely where they are worth most. k and
cycle index are entangled, `p_hat(8) = 1.000` is a boundary estimate, and the
nine rates are fitted on the same jump histogram used to score the trajectories
with no held-out check. Reported, not relied on: the compass chain does not use
p_hat -- its rates come from Phi and T alone.
