# Worked runs (recorded 2026-08-12, seed 20260812, python3.12 + numpy)

All output below is verbatim from `scripts/curve_compass.py`. Regenerate with the
commands shown; every subcommand is deterministic under its seed.

## `--selftest`

```
[PASS] 1 stationary distribution: TV(signed)=0.00296, TV(atom)=0.00120 (both < 0.02); <k>=4.7644 vs exact 4.7542
[PASS] 2 detailed balance: max |z(J)| = 0.009 at k=7 (3-sigma binomial band); all fluxes consistent with zero
[PASS] 3 convergence: split-Rhat=1.00008 (<1.01), ESS=42906 (>1000), tau_int=11.19
[PASS] 4 T->0 absorption: T=0.01: mass at k=9 = 0.99903 (>=0.99), backward rate = 4.79e-04/step (<1e-3), net-flux z = 0.00 (<=3, still reversible); T=0.001: backward transitions = 0, mass at k=9 = 1.00000 -> monotone ascent absorbing at k=9, matching historical k_inf = 9, f_back = 0/598
[PASS] 5 T->inf entropy limit: TV(empirical, Binomial(9,1/2)) = 0.00146 (<0.05); <k>=4.4999 vs 4.5
[PASS] 6 fluctuation peak: Var[k] peaks at T=1.78743 (Var=2.254301), interior to [0.005,2.0] and above the T->inf binomial asymptote 2.25 by 0.19% (shallow but real); heat capacity C(T)=Var[Phi]/T^2 peaks at T=0.03830 (C=3.4565), interior and within 50% of the crossover T_x=0.04114
[PASS] 7 quantization: max |dk| = 1; 59199+72443 config-level moves, 0 violations of (|dk|=1 and Hamming=1)
[PASS] 8 determinism: identical trajectories under seed 606 (bitwise), different under 607

GREEN -- all 8 assertions pass
```

## `sweep --Tmin 0.005 --Tmax 2.0 --nT 25 --chains 8 --steps 40000 --seed 20260812`

```
# sweep  T in [0.005, 2.0] x 25 (log spacing), proposal=signed, chains=8, steps=40000
      T     argmax pi   <k> MC +/- MCse    <k> exact   Var MC   Var exact   chi=d<k>/dT      C(T)   acc     Rhat      ESS   mark
   0.0050       9     9.0000+/-nan     9.0000   0.0000    0.0000       -0.005    0.0000  0.000      nan      nan  
   0.0064       9     9.0000+/-nan     9.0000   0.0000    0.0000       -0.038    0.0014  0.000      nan      nan  
   0.0082       9     8.9998+/-0.0001     8.9998   0.0002    0.0002       -0.343    0.0186  0.000   1.0001    61115  
   0.0106       9     8.9980+/-0.0002     8.9983   0.0020    0.0017       -1.799    0.1271  0.002   1.0002    52606  
   0.0136       9     8.9886+/-0.0004     8.9886   0.0113    0.0114       -6.090    0.5051  0.012   1.0001    58822  
   0.0174       9     8.9517+/-0.0009     8.9510   0.0474    0.0478      -14.267    1.2944  0.049   1.0001    54124  
   0.0224       9     8.8527+/-0.0017     8.8519   0.1385    0.1390      -24.482    2.3173  0.141   1.0000    49237  
   0.0287       9     8.6627+/-0.0026     8.6607   0.2990    0.2999      -32.516    3.1293  0.302   1.0002    45510  
   0.0368       9     8.3673+/-0.0036     8.3714   0.5183    0.5182      -35.430    3.4510  0.503   1.0001    40645  CHI-PEAK,C-PEAK
   0.0473       8     7.9956+/-0.0051     8.0029   0.7763    0.7694      -33.473    3.3206  0.576   1.0003    30066  T_x
   0.0607       8     7.5867+/-0.0064     7.5851   1.0467    1.0335      -28.620    2.9082  0.619   1.0003    25264  
   0.0779       7     7.1473+/-0.0079     7.1485   1.3031    1.2960      -22.745    2.3681  0.670   1.0003    21100  
   0.1000       7     6.7350+/-0.0093     6.7203   1.5362    1.5422      -17.039    1.8081  0.683   1.0002    17722  
   0.1284       7     6.3007+/-0.0102     6.3225   1.7573    1.7561      -12.122    1.3010  0.719   1.0004    16858  
   0.1648       6     5.9733+/-0.0109     5.9704   1.9310    1.9259       -8.243    0.8888  0.718   1.0004    16276  
   0.2115       6     5.6556+/-0.0121     5.6710   2.0427    2.0492       -5.403    0.5827  0.725   1.0006    13961  
   0.2714       6     5.4103+/-0.0127     5.4243   2.1805    2.1323       -3.444    0.3709  0.743   1.0003    13597  
   0.3484       5     5.2271+/-0.0131     5.2254   2.2149    2.1851       -2.154    0.2314  0.739   1.0005    12976  
   0.4472       5     5.0506+/-0.0129     5.0672   2.2392    2.2170       -1.330    0.1426  0.740   1.0005    13533  
   0.5740       5     4.9311+/-0.0126     4.9426   2.2439    2.2355       -0.815    0.0872  0.739   1.0010    14101  
   0.7368       5     4.8265+/-0.0129     4.8450   2.2644    2.2457       -0.497    0.0531  0.739   1.0004    13513  
   0.9457       5     4.7746+/-0.0125     4.7688   2.2403    2.2509       -0.302    0.0323  0.743   1.0005    14444  
   1.2139       5     4.7246+/-0.0129     4.7093   2.2516    2.2533       -0.184    0.0196  0.744   1.0008    13538  
   1.5582       5     4.6562+/-0.0128     4.6630   2.2494    2.2542       -0.111    0.0119  0.747   1.0005    13782  
   2.0000       5     4.6455+/-0.0130     4.6269   2.2783    2.2543       -0.082    0.0072  0.747   1.0007    13426  VAR-PEAK

crossover T_x (argmax pi_T leaves k=9)  = 0.041143
  below T_x the energy term wins: pi_T peaks at k=9, the historical absorbing endpoint
  above T_x the entropy term wins: pi_T peaks in the interior (-> k=5, then binomial 4.5)
heat-capacity peak  C(T)=Var_pi[Phi]/T^2 max at T = 0.038304, C = 3.4565 (interior: YES)
susceptibility peak |chi(T)|=|d<k>/dT| max at T = 0.0368, chi = -35.430
fluctuation peak    Var[k] max at T = 1.787431 (exact, refined grid), Var = 2.254301 (interior: YES)
  on the swept grid: exact argmax at T=2.0000, MC argmax at T=2.0000
  NOTE Var[k] is a SHALLOW peak: 2.254301 against the T->inf binomial asymptote 2.250000 (+0.19%). It is real -- the ladder's delta(k) is largest mid-lattice, which
  broadens pi_T past binomial -- but C(T) and |chi(T)| are the sharp crossover diagnostics.
-> /var/workspace/session/subagent/skill/run/sweep.json
```

## `balance --T 1.0 --chains 8 --steps 200000 --seed 20260812`

```
# balance  T=1.0  proposal=signed  chains=8  steps=200000  seed=20260812
  k   c(k->k+1)   c(k+1->k)       J        3sigma band     z      ok
  0         530         530        0   +/-     97.7   +0.00   yes
  1        4811        4810        1   +/-    294.3   +0.01   yes
  2       20892       20890        2   +/-    613.2   +0.01   yes
  3       54457       54454        3   +/-    990.0   +0.01   yes
  4       91581       91579        2   +/-   1283.9   +0.00   yes
  5       76723       76725       -2   +/-   1175.2   -0.01   yes
  6       36592       36592        0   +/-    811.6   +0.00   yes
  7       10253       10254       -1   +/-    429.6   -0.01   yes
  8        1281        1281        0   +/-    151.8   +0.00   yes
max |z(J)| = 0.010   ->  DETAILED BALANCE NOT REJECTED
TV(empirical occupancy, exact pi_T) = 0.00227
chi-square (occupancy vs pi_T, 9 df) = 34.20  on 800000 samples
historical contrast: log flux J_hist(k) = [1, 4, 4, 8, 27, 56] forward, all-zero backward, 0/598
-> /var/workspace/session/subagent/skill/run/balance.json
```

## `history --Tzero 0.01 --chains 8 --steps 60000 --seed 20260812`

```
# history  source: is-this-x-2026-08-12 sec.7 (D1,D2); tests/T3-results.json
transitions re-measured        : 1178
  stay (all at absorbing k=9)  : 580
  advance +1                   : 423
  advance +2..+4               : 175 (14.9%)
  regress                      : 0
f_back = 0/598 = 0.000000
absorbing state k_inf          : 9
telescoping residual r         : 0.0

VERDICT: maximally irreversible.  T(k+1->k)=0 for every k, so no positive pi
  makes the chain reversible; the unique stationary distribution is delta_{k=9}.
  Kolmogorov's cycle criterion is VACUOUS (no backward edge -> DAG plus self-loops).
  Rule of three: backward rate < 0.0050 at 95%, entropy production
  >= 423 x ln(1/0.0050) = 2240 nats per sweep of the log.
  There is no equilibrium ensemble, hence no free energy, hence no Ginzburg-Landau
  reading is available in principle (paper sec.7 D2, sec.8).

FORMAL STATEMENT: the historical log is the T->0 limit of the compass dynamics.
  As T->0 the Metropolis factor exp(-[Phi(k+1)-Phi(k)]/T) -> 1 for every downhill
  (coverage-increasing) move, since Phi is strictly decreasing on k=0..9, while the
  uphill factor exp(-delta(k)/T) -> 0.  The chain degenerates to monotone ascent
  absorbing at k=9 -- exactly the measured log.  Checked numerically below.

T->0 check  (simulated at T=0.01, chains=8, steps=60000):
  mass at k=9 (post-burn-in)   : 0.998979   (exact pi_T: 0.998934)
  backward accepted transitions: 130   forward: 130
  backward RATE                : 5.417e-04 per step  (analytic bound 9*exp(-delta(8)/T) = 1.067e-03)
  net flux sum_k J(k)          : 0  (zero within noise: the compass
                                  chain stays REVERSIBLE at every T>0; what vanishes as
                                  T->0 is the backward RATE, not the balance)
  max |dk| over accepted moves : 1
  <k> = 8.998979  (historical endpoint: k_inf = 9)
  deeper limit T=0.001      : backward transitions = 0, mass at k=9 = 1.000000  -> monotone ascent, absorbing
  T->0 limit reproduces the historical endpoint: YES
-> /var/workspace/session/subagent/skill/run/history.json
```

## `simulate --T 0.05 --chains 8 --steps 60000 --seed 7`

```
# simulate  T=0.05  proposal=signed  chains=8  steps=60000  seed=7
burn-in discarded 30000 (detector suggests 0)
<k>            = 7.9132 +/- 0.0043 (MCse)   analytic 7.9127
Var[k]         = 0.8239                    analytic 0.8278
acceptance     = 0.5795
tau_int        = 5.486   (post-burn-in length/tau = 5468.1 per chain)
split-Rhat     = 1.00023   ESS = 43744
TV(empirical, exact pi_T) = 0.00163
max |dk| over accepted moves = 1 (quantization: must be 1)
  k :  empirical    exact pi_T
  0 :   0.00000     0.00000
  1 :   0.00000     0.00000
  2 :   0.00000     0.00000
  3 :   0.00005     0.00005
  4 :   0.00082     0.00075
  5 :   0.00814     0.00841
  6 :   0.05782     0.05876
  7 :   0.22791     0.22635
  8 :   0.42057     0.42065
  9 :   0.28470     0.28503
```
