# Worked calibration example — curved-corpus-create v1.0.0

All numbers below are real output from `scripts/create_corpus.py`, run
2026-08-12 on Python 3.12 / numpy 2.5.1, single core. Every command is
reproducible verbatim: seeds are given and the script is deterministic under
`numpy.random.default_rng`.

Design under test: **N = 200, d = 9, base_rate = 0.5, modes = 2** (planted
channels: Y₃³ and Y₃⁻³), Y₃³ constant `K = √(70/(64π)) = 0.5900435`.

---

## Step 1 — build the standard candle

```bash
python3 scripts/create_corpus.py generate \
    --kind planted -N 200 -d 9 --amplitude 1.5 --modes 2 --seed 11 \
    --out /tmp/cc/planted.json
```

Generative truth carried in the file: `kind=planted, N=200, d=9,
amplitude=1.5, modes=2, base_rate=0.5, seed=11, legacy_k=false,
K_Y33=0.5900435...`.

## Step 2 — measure it against all three nulls

```bash
python3 scripts/create_corpus.py measure --matrix /tmp/cc/planted.json \
    --reps 200 --seed 3
```

**Spectral / marginal block**

| quantity | value |
|---|---|
| V₂ | **0.44768973** |
| eigenvalues (9) | 2.1952, 1.8543, 0.9503, 0.8178, 0.7794, 0.7197, 0.6677, 0.5727, 0.4881 |
| r_eff (participation ratio) | 6.8370 |
| Shannon effective rank | 7.8446 |
| mean off-diagonal ρ̄ | −0.02478 |
| row-mass mean ± sd | 4.625 ± 1.3395 |
| Otsu bimodality | 0.69758 |
| column marginals | 0.450, 0.555, 0.500, 0.525, 0.505, 0.480, 0.515, 0.570, 0.525 |

**Curve-fit block** (PCA→stereographic→ridge SH, L=3, λ=1e-3)

| quantity | value |
|---|---|
| PC1+PC2 | 0.44744 (gate_pass = true, threshold 0.40) |
| design numerical rank | **16 / 16** |
| design condition number | **1.0057** |
| sphere-fit R² | 0.43298 |
| chordal residual mean | 0.55094 |
| chordal residual p95 | 1.26155 |
| Y₃³ probe | 0.010951 |

The rank/condition pair is the honest companion to the gate: rank 16 of 16 and
condition 1.006 means the SH design is fully identified here — unlike the
regime's 7-D and 384-D series, where `PC1+PC2 = 1.0000` reflects a rank
collapse rather than a fit.

**Null block** (200 draws each)

| null | V₂ mean | V₂ sd | ΔV2 | **ΔV2z** |
|---|---:|---:|---:|---:|
| curveball (row **and** column sums preserved) | 0.28640 | 0.00913 | +0.16129 | **+17.673** |
| column-permutation | 0.28398 | 0.00918 | +0.16371 | +17.815 |
| iid, matched column marginals | 0.28428 | 0.00901 | +0.16341 | +18.134 |

All three agree here **because the planted corpus has near-uniform row mass**
(4.625 ± 1.34 out of 9). On a corpus with U-shaped row mass they diverge
sharply, and only the curveball value is admissible — this is exactly the case
of yubiOS, which scores V₂ = 0.7235 against a **corrected** curveball null of
**0.7089 ± 0.0014** (ΔV₂ = +0.0144, z = +12.3) while the iid/column-permutation
nulls sit near 0.2399. The earlier figure for that same null — 0.8005, z = −45.8
— was **retracted**: it came from an under-mixed fixed-margin sampler and was not
reproduced by either of two independent provably-uniform samplers (uniformity
χ² p = 0.364 and p = 0.506 on the exhaustive 120-matrix fibre). yubiOS sits
*above* its fixed-margin null, not below. See `results/A2-curveball-audit.json`,
`results/validation.json`, `results/finite_size.json`.

## Step 3 — the matched null must stay quiet

```bash
python3 scripts/create_corpus.py generate --kind null -N 200 -d 9 --seed 12 \
    --out /tmp/cc/null.json
python3 scripts/create_corpus.py measure --matrix /tmp/cc/null.json --reps 80
```

| quantity | value |
|---|---|
| V₂ | 0.28497 |
| ΔV2z (curveball) | **−0.116** |
| r_eff | 8.6558 |
| Otsu bimodality | 0.67380 |

`V₂ = 0.285 ≈ 2/9 + finite-size`. The regime's published `V_floor = 0.222` is
`2/D` and nothing more.

## Step 4 — the calibration pack

```bash
python3 scripts/create_corpus.py calibrate -N 200 -d 9 --modes 2 \
    --amplitudes 0,0.25,0.5,0.75,1.0,1.5,2.0 --trials 8 --reps 60 --seed 0 \
    --out calibration.json
```

**Signal-recovery curve** (8 independent corpora per amplitude; 60 curveball
draws each)

| amplitude | ΔV2z mean | ΔV2z sd | V₂ mean | sphere R² mean | power @ \|z\|>3 |
|---:|---:|---:|---:|---:|---:|
| 0.00 | +0.181 | 0.849 | 0.2863 | 0.4848 | 0.00 |
| 0.25 | +0.101 | 1.124 | 0.2858 | 0.4799 | 0.00 |
| 0.50 | +1.495 | 1.248 | 0.2978 | 0.4872 | 0.12 |
| 0.75 | +5.490 | 1.153 | 0.3327 | 0.4957 | **1.00** |
| 1.00 | +10.282 | 1.733 | 0.3767 | 0.4752 | 1.00 |
| 1.50 | +19.344 | 2.289 | 0.4688 | 0.4757 | 1.00 |
| 2.00 | +28.008 | 3.107 | 0.5416 | 0.4689 | 1.00 |

**False-positive block** (8 null corpora)

| quantity | value |
|---|---|
| ΔV2z mean | −0.0487 |
| ΔV2z sd | 1.1807 |
| max \|ΔV2z\| | 2.2609 |
| FPR at \|z\| > 3 | **0.000** |
| FPR at \|z\| > 2 | 0.125 |

**Detection threshold: amplitude 0.75** (smallest swept amplitude with power
≥ 0.8, in fact 1.00).

Three things this pack establishes that no measurement skill can assert on its
own:

1. **ΔV2z is close to linear in amplitude** above threshold (5.49 → 10.28 →
   19.34 → 28.01 for 0.75 → 1.0 → 1.5 → 2.0), so the statistic is usable as an
   effect-size scale, not merely a detector.
2. **ΔV2z is well calibrated under the null**: the observed null sd is 1.18
   against a nominal 1.0, and no null trial crossed |z| = 3. The nominal α at
   z = 3 is not badly optimistic at these N.
3. **Sphere-fit R² carries no signal at all**: 0.4848 at amplitude 0, 0.4689 at
   amplitude 2.0 — flat, and non-monotone within noise, while ΔV2z sweeps 0 to
   28. **The SH curve-fit R² is not a detection statistic at N = 200.** This is
   the single most useful finding in the pack, and it is invisible without a
   planted signal to sweep. Any prior claim in the regime that rested on an R²
   or residual improvement needs this check re-run at its own N and d.

## Step 5 — IS-THIS-X placement

```bash
python3 scripts/create_corpus.py place --matrix /tmp/cc/planted.json \
    --trials 12 --reps 60 --seed 6
```

Observed sufficient-statistic vector:

```
V2               = 0.447690
dV2z             = 20.6220
r_eff            = 6.83703
otsu_bimodality  = 0.697584
col_marginal_mean= 0.513889
col_marginal_sd  = 0.0343008
```

Reference families regenerated at the observed (N = 200, d = 9, density
0.5139), 12 trials each, seed 6:

| family | V₂ | ΔV2z | r_eff | Otsu | col mean | col sd |
|---|---:|---:|---:|---:|---:|---:|
| `M0_null` | 0.2849 ± 0.0065 | +0.150 ± 0.734 | 8.6641 ± 0.062 | 0.6720 ± 0.017 | 0.5181 ± 0.0157 | 0.0435 ± 0.0099 |
| `M1_curve_weak` (a=0.5) | 0.2933 ± 0.0119 | +0.975 ± 1.297 | 8.5938 ± 0.097 | 0.6729 ± 0.014 | 0.5052 ± 0.0133 | 0.0306 ± 0.0089 |
| `M1_curve_strong` (a=1.5) | 0.4705 ± 0.0167 | +19.685 ± 2.170 | 6.5150 ± 0.217 | 0.6659 ± 0.022 | 0.5134 ± 0.0066 | 0.0289 ± 0.0076 |
| `M4_mixture` (k=2, sep 1.5) | 0.3600 ± 0.0423 | +8.548 ± 4.467 | 7.5898 ± 0.733 | 0.6694 ± 0.031 | 0.5237 ± 0.0867 | 0.1785 ± 0.0370 |

**Exclusion table** (z per coordinate, order V₂ / ΔV2z / r_eff / Otsu / col mean / col sd)

| class | verdict | max\|z\| | driving coordinate | per-coordinate z |
|---|---|---:|---|---|
| `M0_null` | **excluded** | 27.91 | ΔV2z | 11.43, 27.91, −4.22, 0.76, −0.16, −0.93 |
| `M1_curve_weak` | **excluded** | 15.15 | ΔV2z | 10.52, 15.15, −4.09, 0.73, 0.34, 0.41 |
| `M1_curve_strong` | **not-excluded** | 0.99 | r_eff | −0.97, 0.43, 0.99, 0.95, 0.02, 0.71 |
| `M4_mixture` | **excluded** | 3.89 | col_marginal_sd | 2.07, 2.70, −1.03, 0.84, −0.11, −3.89 |

→ **nearest family: `M1_curve_strong`; surviving classes: [`M1_curve_strong`]**

This is the round-trip that licenses the map: a corpus generated at amplitude
1.5 recovers its own family (max |z| = 0.99), excludes the null at z = 27.9,
excludes the weaker curve at z = 15.2, and excludes the mixture — the last on
column-marginal spread, **not** on V₂, where curve and mixture genuinely overlap
(z = 2.07 on V₂ alone would not have separated them). The mixture family is also
by far the widest (ΔV2z sd 4.47 vs 2.17), which is why it is the class most often
left standing on real data.

The reverse round-trip, same settings on the matched null corpus
(`generate --kind null -N 200 -d 9 --seed 12`):

| class | verdict | max\|z\| | driving coordinate |
|---|---|---:|---|
| `M0_null` | **not-excluded** | 0.49 | col_marginal_sd |
| `M1_curve_weak` | **not-excluded** | 2.42 | col_marginal_sd |
| `M1_curve_strong` | **excluded** | 7.82 | V₂ |
| `M4_mixture` | **excluded** | 3.50 | col_marginal_sd |

→ nearest `M0_null`; surviving [`M0_null`, `M1_curve_weak`]. The null corpus
cannot exclude the weak-curve family — correctly so: at amplitude 0.5 the
calibration pack gives power 0.12, so weak curvature is **not testable** at this
N and the map says so rather than guessing.

A note on reproducibility: `place` derives its per-family seeds with CRC-32, not
Python's builtin `hash()`, which is salted per process (`PYTHONHASHSEED`). An
earlier build used `hash()` and produced a different exclusion table on every
run; the numbers above are stable across processes.

## Step 6 — the corrected Y₃³ constant

```
K         = sqrt(70 /(64 pi)) = 0.590044     <- USE THIS (real orthonormal)
K_complex = sqrt(35 /(64 pi)) = 0.417224     <- complex SH normalization
K_legacy  = sqrt(245/(64 pi)) = 1.103870     <- WRONG
ratio legacy/real    = 1.870829 = sqrt(7/2)  (exact; 245/70 = 3.5)
ratio legacy/complex = 2.645751 = sqrt(7)    (exact; 245/35 = 7)
```

Selftest step 4, on the same seed with and without `--legacy-k`:

- emitted matrices **bit-identical** (`np.array_equal` true)
- V₂ = 0.447690 vs 0.447690, difference < 1e-12
- raw Y₃³ RMS ratio = 1.870829 = √(7/2) exactly

Because the generator standardizes each probe channel before scaling by
`amplitude`, the constant affects only the reported raw probe magnitude. If a
future edit makes `--legacy-k` move V₂, a probe has been left unstandardized —
the selftest will catch it.

Note for anyone reconciling documents: the regime playbook describes the legacy
constant as off "by √7". Both statements are true against different references —
legacy = **√7 × complex** constant `√(35/(64π)) = 0.417224` (245/35 = 7), and
legacy = **√(7/2) × real-orthonormal** constant `√(70/(64π)) = 0.590044`
(245/70 = 3.5). Against the real-orthonormal convention this skill uses, the
exact factor is **√(7/2) ≈ 1.8708**, so published Y₃³ amplitudes under the legacy
constant are inflated by 1.8708×. Cross-checked in `results/validation.json`
(`sh_constants`: complex_correct 0.4172238, real_orthonormal_correct 0.5900436,
published_wrong 1.1038705, ratio_wrong_over_complex 2.6457513).

---

## How another skill cites this pack

> Detection was assessed with `curved-corpus-create` v1.0.0 at the matched
> design (N = 200, d = 9, base rate 0.5, modes = 2, seed 0). The calibrated
> detection threshold is planted amplitude 0.75 (power 1.00 at |ΔV2z| > 3);
> the false-positive rate on matched nulls is 0.000 at |z| > 3 and 0.125 at
> |z| > 2. Sphere-fit R² was flat (0.469–0.496) across the entire amplitude
> sweep and is therefore reported as a diagnostic only, not as evidence.

Regenerate before citing at any other N, d, base rate, or mode count — the
threshold moves with all four.
